<?php
class Df_Autolux_Helper_Data extends Mage_Core_Helper_Abstract {
	const _CLASS = __CLASS__;
}