<?php
/** @var Df_Core_Model_Resource_Setup $this */
$this->startSetup();
Df_Banner_Model_Setup_0_1_1::i($this)->process();
$this->endSetup();