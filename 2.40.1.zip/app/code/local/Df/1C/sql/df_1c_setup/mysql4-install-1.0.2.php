<?php
/** @var Df_Core_Model_Resource_Setup $this */
$this->startSetup();
Df_1C_Model_Setup_1_0_2::i($this)->process();
$this->endSetup();