<?php
/** @var Df_Core_Model_Resource_Setup $this */
$this->startSetup();
Df_Catalog_Model_Setup_1_0_0::s()->process();
$this->endSetup();