<?php
class Df_Catalog_Model_Product_Option_Type_File extends Mage_Catalog_Model_Product_Option_Type_File {
	/**
	 * В родительском методе @see Mage_Catalog_Model_Product_Option_Type_File::getFormattedOptionValue()
	 * поле _formattedOptionValue используется без предварительного объявления.
	 * @var string
	 */
	protected $_formattedOptionValue = null;
}