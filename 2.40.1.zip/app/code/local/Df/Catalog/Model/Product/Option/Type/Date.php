<?php
class Df_Catalog_Model_Product_Option_Type_Date extends Mage_Catalog_Model_Product_Option_Type_Date {
	/**
	 * В родительском методе @see Mage_Catalog_Model_Product_Option_Type_Date::getFormattedOptionValue()
	 * поле _formattedOptionValue используется без предварительного объявления.
	 * @var string
	 */
	protected $_formattedOptionValue = null;
}