<?php
class Df_Catalog_Model_Product_Option_Type_Select extends Mage_Catalog_Model_Product_Option_Type_Select {
	/**
	 * В родительском методе @see Mage_Catalog_Model_Product_Option_Type_Select::getFormattedOptionValue()
	 * поле _formattedOptionValue используется без предварительного объявления.
	 * @var string
	 */
	protected $_formattedOptionValue = null;
}

 