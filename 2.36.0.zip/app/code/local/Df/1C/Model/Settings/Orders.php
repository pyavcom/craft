<?php
class Df_1C_Model_Settings_Orders extends Df_1C_Model_Settings_Cml2 {
	/** @return Df_1C_Model_Settings_Orders */
	public static function s() {static $r; return $r ? $r : $r = new self;}
}