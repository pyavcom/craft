<?php
class Df_1C_Model_Cml2_Session extends Mage_Core_Model_Session_Abstract_Varien {
	/**
	 * @override
	 * @return bool
	 * @see Mage_Core_Model_Session_Abstract_Varien::start():
		if (isset($_SESSION) && !$this->getSkipEmptySessionCheck()) {
			return $this;
		}
	 */
	public function getSkipEmptySessionCheck() {return true;}

	/**
	 * @override
	 * @param string|null $id [optional]
	 * @return Df_1C_Model_Cml2_Session
	 */
	public function setSessionId($id = null) {
		parent::setSessionId($id ? $id : Mage::app()->getRequest()->getCookie(self::NAME));
		return $this;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->start();
		$this->init(__CLASS__);
	}

	const NAME = __CLASS__;

	/** @return Df_1C_Model_Cml2_Session */
	public static function s() {static $r; return $r ? $r : $r = new self;}
}