<?php
class Df_CatalogIndex_Helper_Data extends Mage_Core_Helper_Abstract {}