<?php
interface Df_Admin_Const {
	const CONFIG_SOURCE__KEY__LABEL = 'label';
	const CONFIG_SOURCE__KEY__VALUE = 'value';
	const SESSION__PARAM__USER = 'user';
	const SESSION__PARAM__ACL = 'acl';
	const T_DISABLED = 'disabled';
	const T_ENABLED_FOREVER = 'enabled forever';
	const T_FEATURE_NAME_PATTERN = 'module “%s”';
	const T_TILL_PATTERN = 'до %s';
}