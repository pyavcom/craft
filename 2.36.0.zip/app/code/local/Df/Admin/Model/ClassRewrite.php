<?php
class Df_Admin_Model_ClassRewrite extends Df_Core_Model_Abstract {
	/** @return Df_Admin_Model_ClassInfo_Collection */
	public function getDestinations() {
		if (!isset($this->{__METHOD__})) {
			$this->{__METHOD__} = Df_Admin_Model_ClassInfo_Collection::i();
		}
		return $this->{__METHOD__};
	}

	/**
	 * Для коллекций
	 * @override
	 * @return string
	 */
	public function getId() {
		if (!isset($this->{__METHOD__})) {
			$this->{__METHOD__} = self::makeId($this->getType(), $this->getOrigin()->getId());
		}
		return $this->{__METHOD__};
	}

	/** @return Df_Admin_Model_ClassInfo */
	public function getOrigin() {return $this->cfg(self::P__ORIGIN);}

	/** @return string */
	public function getType() {return $this->getOrigin()->getType();}

	/** @return bool */
	public function isConflict() {return 1 < count($this->getDestinations());}

	/**
	 * @param Df_Admin_Model_ClassInfo $destination
	 * @return bool
	 */
	public function isDestinationActive(Df_Admin_Model_ClassInfo $destination) {
		return $this->getActiveDestinationName() === $destination->getName();
	}

	/** @return string */
	private function getActiveDestinationName() {return $this->getOrigin()->getNameByMf();}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->_prop(self::P__ORIGIN, Df_Admin_Model_ClassInfo::_CLASS);
	}
	const _CLASS = __CLASS__;
	const P__ORIGIN = 'origin';
	/**
	 * @param Df_Admin_Model_ClassInfo $origin
	 * @return Df_Admin_Model_ClassRewrite
	 */
	public static function i(Df_Admin_Model_ClassInfo $origin) {
		return new self(array(self::P__ORIGIN => $origin));
	}
	/**
	 * @param string $type
	 * @param string $classNameMf
	 * @return string
	 */
	public static function makeId($type, $classNameMf) {return implode('_', array($type, $classNameMf));}
}