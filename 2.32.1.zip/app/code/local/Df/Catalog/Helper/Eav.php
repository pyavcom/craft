<?php
class Df_Catalog_Helper_Eav extends Mage_Catalog_Helper_Data {
	/** @return Df_Eav_Model_Entity */
	public function getProductEntity() {
		if (!isset($this->{__METHOD__})) {
			$this->{__METHOD__} = Df_Eav_Model_Entity::i();
			$this->{__METHOD__}->setType('catalog_product');
		}
		return $this->{__METHOD__};
	}

	/** @return Df_Catalog_Helper_Eav */
	public static function s() {static $r; return $r ? $r : $r = new self;}
}