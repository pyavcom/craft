<?php
class Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_System
	extends Df_1C_Model_Cml2_Import_Data_Entity {
	/**
	 * @override
	 * @return string
	 */
	public function getExternalId() {
		return $this->getName();
	}

	/** @return string */
	public function getValue() {
		return $this->getEntityParam('Значение');
	}

	/**
	 * Используется из @see Df_1C_Model_Cml2_Import_Data_Collection_ProductPart_AttributeValues_System::getItemClass()
	 */
	const _CLASS = __CLASS__;
}