<?php
/** @var $this Df_1C_Model_Resource_Setup */
$this->startSetup();
/**
 * Ничего не делаем
 */
$this->endSetup();