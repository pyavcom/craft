<?php
class Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Text
	extends Df_Checkout_Block_Frontend_Ergonomic_Address_Field {
	const _CLASS = __CLASS__;
	/**
	 * @param array(string => mixed) $parameters [optional]
	 * @return Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Text
	 */
	public static function i($parameters) {return df_block(__CLASS__, null, $parameters);}
}