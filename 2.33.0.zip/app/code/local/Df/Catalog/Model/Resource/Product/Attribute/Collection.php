<?php
class Df_Catalog_Model_Resource_Product_Attribute_Collection
	extends Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Attribute_Collection {
	/**
	 * @override
	 * @return Mage_Core_Model_Resource_Db_Collection_Abstract
	 */
	protected function _afterLoadData() {
		$this->translateLabels();
		parent::_afterLoadData();
		return $this;
	}

	/** @return void */
	private function translateLabels() {
		/** @var string[] $labelNames */
		$labelNames = array('store_label', 'frontend_label');
		/** @var string[] $notTranslatedLabels */
		$notTranslatedLabels = array();
		foreach ($this->_data as &$attributeData) {
			/** @var array(string => mixed $attributeData) */
			foreach ($labelNames as $labelName) {
				/** @var string $labelName */
				/** @var string|null $labelValue */
				$labelValue = df_a($attributeData, $labelName);
				if ($labelValue) {
					$attributeData[$labelName] =
						Df_Catalog_Model_Product_Attribute_Translator::s()->translate($labelValue)
					;
				}
			}
		}
	}
}