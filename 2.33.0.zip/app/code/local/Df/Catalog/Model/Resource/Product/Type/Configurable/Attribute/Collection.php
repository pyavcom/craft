<?php
class Df_Catalog_Model_Resource_Product_Type_Configurable_Attribute_Collection
	extends Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Type_Configurable_Attribute_Collection {
	/**
	 * @override
	 * @return Df_Catalog_Model_Resource_Product_Type_Configurable_Attribute_Collection
	 */
	protected function _loadLabels() {
		parent::_loadLabels();
		foreach ($this->_items as $configurableAttribute) {
			/** @var Mage_Catalog_Model_Product_Type_Configurable_Attribute $configurableAttribute */
			/** @var string $label */
			$label = $configurableAttribute->getData('label');
			if ($label) {
				$configurableAttribute->setData(
					'label', Df_Catalog_Model_Product_Attribute_Translator::s()->translate($label
				));
			}
		}
		return $this;
	}
}

 