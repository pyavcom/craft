<?php
class Df_Catalog_Model_Product_Attribute_Translator extends Df_Core_Model_Abstract {
	/**
	 * @override
	 * @return void
	 */
	public function __destruct() {
		if (df_is_it_my_local_pc() && $this->_untranslated) {
//			Mage::log(rm_sprintf(
//				'Добавьте в файл app/locale/ru_DF/Mage_Catalog.csv'
//				. " перевод следующих экранных названий товарных свойств:\r\n%s."
//				, implode("\r\n", array_unique($this->_untranslated))
//			), null, 'rm.translation.log');
		}
		parent::__destruct();
	}

	/**
	 * @param string $label
	 * @return string
	 */
	public function translate($label) {
		if (!isset($this->{__METHOD__}[$label])) {
			/** @var string $result */
			$result = df_mage()->catalogHelper()->__($label);
			if ($result === $label) {
				$result = df_h()->eav()->__($label);
			}
			if (
					df_is_it_my_local_pc()
				&&
					($result === $label)
				&&
					!df_text()->isTranslated($label)
			) {
				$this->_untranslated[]= $label;
			}
			$this->{__METHOD__}[$label] = $result;
		}
		return $this->{__METHOD__}[$label];
	}

	/** @var string[] */
	private $_untranslated = array();

	/** @return Df_Catalog_Model_Product_Attribute_Translator */
	public static function s() {static $r; return $r ? $r : $r = new self;}
}