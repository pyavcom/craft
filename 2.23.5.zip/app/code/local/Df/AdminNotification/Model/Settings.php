<?php
class Df_AdminNotification_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function getFixReminder() {
		return $this->getYesNo('df_tweaks_admin/system_notifications/fix_reminder');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}