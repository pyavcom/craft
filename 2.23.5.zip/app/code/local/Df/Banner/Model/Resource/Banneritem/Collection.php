<?php
class Df_Banner_Model_Resource_Banneritem_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {
	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->_init(Df_Banner_Model_Banneritem::mf(), Df_Banner_Model_Resource_Banneritem::mf());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Banner_Model_Resource_Banneritem_Collection
	 */
	public static function i(array $parameters = array()) {
		return Mage::getResourceModel(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf_r(__CLASS__);} return $result;
	}
}