<?php
class Df_Banner_Helper_Data extends Mage_Core_Helper_Abstract {
	/**
	 * @return Df_Banner_Helper_Image
	 */
	public function image() {
		return Mage::helper(Df_Banner_Helper_Image::mf());
	}
	/**
	 * @return Df_Banner_Helper_Image2
	 */
	public function image2() {
		return Mage::helper(Df_Banner_Helper_Image2::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}