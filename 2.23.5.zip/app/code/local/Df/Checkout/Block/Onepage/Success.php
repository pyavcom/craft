<?php
class Df_Checkout_Block_Onepage_Success extends Mage_Checkout_Block_Onepage_Success {
	/**
	 * @override
	 * @return string
	 */
	public function __() {
		/**
		 * Обратите внимание, что этот метод нельзя записать в одну строку,
		 * потому что функция func_get_args() не может быть параметром другой функции.
		 */
		/** @var mixed[] $args */
		$args = func_get_args();
		return df_helper()->localization()->translation()->translateByParent($args, $this);
	}

	/**
	 * @return string
	 */
	public function getTemplate() {
		if (!isset($this->_templateRm)) {
			/** @var string $result */
			$result = parent::getTemplate();
			if (
					('checkout/success.phtml' === $result)
				&&
					!is_null($this->getPaymentMethod())
				&&
					($this->getPaymentMethod() instanceof Df_Payment_Model_Method_Base)
			) {
				/** @var Df_Payment_Model_Method_Base $paymentMethod */
				$paymentMethod = $this->getPaymentMethod();
				if (!df_empty($paymentMethod->getTemplateSuccess())) {
					$result = $paymentMethod->getTemplateSuccess();
				}
			}
			$this->_templateRm = $result;
		}
		return $this->_templateRm;
	}
	/** @var string */
	private $_templateRm;
	
	/**
	 * @return Df_Sales_Model_Order|null
	 */
	private function getOrder() {
		if (!isset($this->_order) && !$this->_orderIsNull) {
			/** @var Df_Sales_Model_Order|null $result */
			$result =
				0 === $this->getOrderIdRm()
				? null
				: Df_Sales_Model_Order::ld($this->getOrderIdRm())
			;
			if (is_null($result)) {
				$this->_orderIsNull = true;
			}
			else {
				df_assert($result instanceof Df_Sales_Model_Order);
			}
			$this->_order = $result;
		}
		return $this->_order;
	}
	/** @var Df_Sales_Model_Order|null */
	private $_order;
	/** @var bool */
	private $_orderIsNull = false;	
	
	/**
	 * @return int
	 */
	private function getOrderIdRm() {
		return intval(df_mage()->checkout()->sessionSingleton()->getDataUsingMethod('last_order_id'));
	}

	/**
	 * @return Mage_Payment_Model_Method_Abstract|null
	 */
	private function getPaymentMethod() {
		return
			is_null($this->getOrder()) || is_null($this->getOrder()->getPayment())
			? null
			: $this->getOrder()->getPayment()->getMethodInstance()
		;
	}
}