<?php
class Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Dropdown
	extends Df_Checkout_Block_Frontend_Ergonomic_Address_Field {
	/**
	 * @override
	 * @return string
	 */
	public function getType() {
		return sprintf('%s_id', parent::getType());
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getConfigShortKey() {
		return str_replace('_id', '', $this->getType());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}