<?php
abstract class Df_Checkout_Block_Frontend_Address_Element extends Df_Core_Block_Template {
	/**
	 * @return Mage_Checkout_Block_Onepage_Abstract
	 */
	protected function getAddressBlock() {
		/** @var Mage_Checkout_Block_Onepage_Abstract $result */
		$result =
			$this->cfg(self::PARAM__ADDRESS_BLOCK)
		;
		df_assert($result instanceof Mage_Checkout_Block_Onepage_Abstract);
		return $result;
	}

	const PARAM__ADDRESS_BLOCK = 'address_block';
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

}