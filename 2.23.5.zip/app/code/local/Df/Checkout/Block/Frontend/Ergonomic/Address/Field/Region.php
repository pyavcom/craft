<?php
class Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region
	extends Df_Checkout_Block_Frontend_Ergonomic_Address_Field {
	/**
	 * @return Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Dropdown
	 */
	public function getControlDropdown() {
		if (!isset($this->_controlDropdown)) {
			$this->_controlDropdown =
				df_block(
					Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Dropdown::mf()
					,null
					,$this->getData()
				)
			;
		}
		return $this->_controlDropdown;
	}
	/** @var Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Dropdown */
	private $_controlDropdown;		

	/**
	 * @return Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Text
	 */
	public function getControlText() {
		if (!isset($this->_controlText)) {
			$this->_controlText =
				df_block(
					Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Text::mf()
					,null
					,$this->getData()
				)
			;
		}
		return $this->_controlText;
	}
	/** @var Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Text */
	private $_controlText;	

	/**
	 * @override
	 * @return string|null
	 */
	protected function getDefaultTemplate() {
		return self::DEFAULT_TEMPLATE;
	}

	const _CLASS = __CLASS__;
	const DEFAULT_TEMPLATE = 'df/checkout/ergonomic/address/field/region.phtml';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}