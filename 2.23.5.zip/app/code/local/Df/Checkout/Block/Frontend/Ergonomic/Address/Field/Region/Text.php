<?php
class Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Text
	extends Df_Checkout_Block_Frontend_Ergonomic_Address_Field {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}