<?php
class Df_Checkout_Model_Config_Query_Ergonomic_Address_Fields extends Df_Core_Model_Abstract {
	/**
	 * @return Mage_Core_Model_Config_Element
	 */
	public function getNode() {
		if (!isset($this->_node)) {
			$this->_node =
				/**
				 * Обязательно клонируем объект,
				 * потому что Magento кэширует настроечные узлы
				 */
				clone df()->config()->getNodeByKey($this->getPathByAddressType('default'))
			;
			$this->_node
				->extend(
					df()->config()->getNodeByKey($this->getPathByAddressType($this->getAddressType()))
					,$overwrite = true
				)
			;
		}
		return $this->_node;
	}
	/** @var Mage_Core_Model_Config_Element */
	private $_node;	

	/**
	 * @param string $addressType
	 * @return string
	 */
	private function getPathByAddressType($addressType) {
		return df()->config()->implodeKey(array('df/checkout/address', $addressType, 'fields'));
	}

	/**
	 * @return string
	 */
	private function getAddressType() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__ADDRESS_TYPE);
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->addValidator(self::PARAM__ADDRESS_TYPE, new Df_Zf_Validate_String());
	}
	const _CLASS = __CLASS__;
	const PARAM__ADDRESS_TYPE = 'address_type';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Checkout_Model_Config_Query_Ergonomic_Address_Fields
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}