<?php
class Df_Checkout_Model_Filter_Ergonomic_Address
	extends Df_Core_Model_Abstract
	implements Zend_Filter_Interface {
	/**
	 * @override
	 * @param array $value
	 * @return array
	 */
	public function filter($value) {
		/** @var array $result */
		$result = array();
		foreach ($value as $id => $address) {
			/** @var int $id */
			/** @var Mage_Customer_Model_Address $address */
			df_assert($address instanceof Mage_Customer_Model_Address);
			$address->setData('address_type', $this->getAddressType());
			if (true === $address->validate()) {
				$result[$id] = $address;
			}
		}
		df_result_array($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getAddressType() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__ADDRESS_TYPE);
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->addValidator(
				self::PARAM__ADDRESS_TYPE, new Df_Zf_Validate_String()
			)
		;
	}

	const _CLASS = __CLASS__;
	const PARAM__ADDRESS_TYPE = 'address_type';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Checkout_Model_Filter_Ergonomic_Address
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}