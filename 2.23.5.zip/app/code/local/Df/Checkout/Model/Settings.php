<?php
class Df_Checkout_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return Df_Checkout_Model_Settings_Interface
	 */
	public function _interface() {
		return Mage::getSingleton(Df_Checkout_Model_Settings_Interface::mf());
	}
	/**
	 * @return Df_Checkout_Model_Settings_Field_Applicability
	 */
	public function applicabilityBilling() {
		return $this->field()->getApplicabilityByAddressType('billing');
	}
	/**
	 * @return Df_Checkout_Model_Settings_Field_Applicability
	 */
	public function applicabilityShipping() {
		return $this->field()->getApplicabilityByAddressType('shipping');
	}
	/**
	 * @return Df_Checkout_Model_Settings_Field
	 */
	public function field() {
		return Mage::getSingleton(Df_Checkout_Model_Settings_Field::mf());
	}
	/**
	 * @return string
	 */
	public function getTocContent() {
		df_assert($this->getTocEnabled());
		if (!isset($this->_tocContent)) {
			$this->_tocContent = $this->getTocContentPage()->getData('content');
			df_result_string($this->_tocContent);
		}
		return $this->_tocContent;
	}
	/** @var string */
	private $_tocContent;

	/**
	 * @return boolean
	 */
	public function getTocEnabled() {
		return $this->getYesNo('df_checkout/terms_and_conditions/enabled');
	}

	/**
	 * @return Df_Checkout_Model_Settings_OrderComments
	 */
	public function orderComments() {
		return Mage::getSingleton(Df_Checkout_Model_Settings_OrderComments::mf());
	}

	/**
	 * @return Df_Checkout_Model_Settings_Other
	 */
	public function other() {
		return Mage::getSingleton(Df_Checkout_Model_Settings_Other::mf());
	}

	/**
	 * @return Df_Checkout_Model_Settings_Patches
	 */
	public function patches() {
		return Mage::getSingleton(Df_Checkout_Model_Settings_Patches::mf());
	}

	/**
	 * @return Df_Cms_Model_Page
	 */
	private function getTocContentPage() {
		df_assert($this->getTocEnabled());
		if (!isset($this->_tocContentPage)) {
			/**
			 * Обратите внимание, что в данном случае метод load загружает страницу
			 * по её текстовому идентификатору, а не по стандартному числовому
			 */
			$this->_tocContentPage = Df_Cms_Model_Page::ld($this->getTocContentIdentifier());
		}
		return $this->_tocContentPage;
	}
	/** @var Df_Cms_Model_Page */
	private $_tocContentPage;

	/**
	 * Возвращает значение поля «identifier» материала.
	 * В административном интерфейсе поле называется «URL Key»
	 * @return string
	 */
	private function getTocContentIdentifier() {
		return  $this->getString('df_checkout/terms_and_conditions/content');
	}

	const _CLASS = __CLASS__;
	/**
	 * 1 - optional
	 */
	const DEFAULT_APPLICABILITY_CODE = '1';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}