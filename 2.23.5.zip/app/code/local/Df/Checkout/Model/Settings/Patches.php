<?php
class Df_Checkout_Model_Settings_Patches extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function fixSalesConvertOrderToQuote() {
		return $this->getYesNo('df_checkout/patches/fix_sales_convert_order_to_quote');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}