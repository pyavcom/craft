<?php
class Df_Checkout_Model_Settings_OrderComments extends Df_Core_Model_Settings {
	/**
	 * @return string
	 */
	public function getPositionRelativeToTheTerms() {
		return $this->getString('df_checkout/order_comments/position_relative_to_terms');
	}
	/**
	 * @return string
	 */
	public function getTextareaFloat() {
		return $this->getString('df_checkout/order_comments/textarea_float');
	}
	/**
	 * @return int
	 */
	public function getTextareaWidth() {
		return $this->getInteger('df_checkout/order_comments/textarea_width');
	}
	/**
	 * @return boolean
	 */
	public function specifyTextareaHoriziontalShift() {
		return $this->getYesNo('df_checkout/order_comments/specify_textarea_horizontal_shift');
	}
	/**
	 * @return string
	 */
	public function getTextareaHoriziontalShiftDirection() {
		return $this->getString('df_checkout/order_comments/textarea_horizontal_shift_direction');
	}
	/**
	 * @return int
	 */
	public function getTextareaHoriziontalShiftLength() {
		return $this->getInteger('df_checkout/order_comments/textarea_horizontal_shift_length');
	}
	/**
	 * @return int
	 */
	public function getTextareaVisibleRows() {
		return $this->getInteger('df_checkout/order_comments/textarea_rows');
	}
	/**
	 * @return boolean
	 */
	public function isEnabled() {
		return $this->getYesNo('df_checkout/order_comments/enabled');
	}
	/**
	 * @return boolean
	 */
	public function needShowInCustomerAccount() {
		return $this->getYesNo('df_checkout/order_comments/show_in_customer_account');
	}
	/**
	 * @return boolean
	 */
	public function needShowInOrderEmail() {
		return $this->getYesNo('df_checkout/order_comments/show_in_order_email');
	}
	/**
	 * @return boolean
	 */
	public function specifyTextareaPosition() {
		return $this->getYesNo('df_checkout/order_comments/specify_textarea_position');
	}
	/**
	 * @return boolean
	 */
	public function specifyTextareaWidth() {
		return $this->getYesNo('df_checkout/order_comments/specify_textarea_width');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}