<?php
/**
 * @method Df_Checkout_Model_Event_CheckoutTypeOnepage_SaveOrderAfter getEvent()
 */
class Df_Checkout_Model_Handler_SendGeneratedPasswordToTheCustomer extends Df_Core_Model_Handler {
	/**
	 * Метод-обработчик события
	 * @override
	 * @return void
	 */
	public function handle() {
		if (
				df_cfg()->checkout()->_interface()->needShowAllStepsAtOnce()
			&&
				!df_empty($this->getGeneratedPassword())
		) {
 			$this->getMailer()->send();
			/**
			 * Важно!
			 * Удаляем пароль из сессии после отсылки,
			 * чтобы потом система не пыталась создавать клиенту пароль повторно.
			 */
			df_mage()->customer()->sessionSingleton()
				->unsetData(Df_Customer_Const_Session::GENERATED_PASSWORD)
			;
		}
	}

	/**
	 * @return Df_Core_Model_Email_Template_Mailer
	 */
	private function getMailer() {
		if (!isset($this->_mailer)) {
			/** @var Df_Core_Model_Email_Template_Mailer $result */
			$result = Df_Core_Model_Email_Template_Mailer::i();
			$result->addEmailInfo($this->getMailInfo());
			$result->setSender($this->getMailSender());
			$result->setTemplateId($this->getMailTemplateId());
			$result
				->setTemplateParams(
					array(
						'password' => $this->getGeneratedPassword()
						,'email' => $this->getEvent()->getOrder()->getCustomerEmail()
						,'name' => $this->getEvent()->getOrder()->getCustomerName()
					)
				)
			;
			$this->_mailer = $result;
		}
		return $this->_mailer;
	}
	/** @var Df_Core_Model_Email_Template_Mailer */
	private $_mailer;

	/**
	 * @return Df_Core_Model_Email_Info
	 */
	private function getMailInfo() {
		if (!isset($this->_mailInfo)) {
			$this->_mailInfo = Df_Core_Model_Email_Info::i();
			$this->_mailInfo
				->addTo(
					$this->getEvent()->getOrder()->getCustomerEmail()
					,$this->getEvent()->getOrder()->getCustomerName()
				)
			;
		}
		return $this->_mailInfo;
	}
	/** @var Df_Core_Model_Email_Info */
	private $_mailInfo;

	/**
	 * @return string
	 */
	private function getMailSender() {
		/** @var string $result */
		$result = Mage::getStoreConfig(Mage_Sales_Model_Order::XML_PATH_EMAIL_IDENTITY, $this->getStore());
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getMailTemplateId() {
		/** @var string $result */
		$result = Mage::getStoreConfig('df_checkout/email/generated_password', $this->getStore());
		df_result_string($result);
		return $result;
	}

	/**
	 * @return Mage_Core_Model_Store
	 */
	private function getStore() {
		return $this->getEvent()->getOrder()->getStore();
	}

	/**
	 * @return string
	 */
	private function getGeneratedPassword() {
		return
			df_string(
				df_mage()->customer()->sessionSingleton()->getData(
					Df_Customer_Const_Session::GENERATED_PASSWORD
				)
			)
		;
	}

	/**
	 * Класс события (для валидации события)
	 * @override
	 * @return string
	 */
	protected function getEventClass() {
		return Df_Checkout_Model_Event_CheckoutTypeOnepage_SaveOrderAfter::_CLASS;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}