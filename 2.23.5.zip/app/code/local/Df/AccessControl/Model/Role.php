<?php
class Df_AccessControl_Model_Role extends Df_Core_Model_Abstract {
	/**
	 * @return int[]
	 */
	public function getCategoryIds() {
		df_assert($this->isModuleEnabled());
		if (!isset($this->_categoryIds)) {
			$this->_categoryIds =
				df_parse_csv(
					$this->getCategoryIdsAsString()
				)
			;
		}
		return $this->_categoryIds;
	}
	/** @var int[] */
	private $_categoryIds;

	/**
	 * @return int[]
	 */
	public function getCategoryIdsWithAncestors() {
		df_assert($this->isModuleEnabled());
		if (!isset($this->_categoryIdsWithAncestors)) {
			/** @var int[] $result */
			$result = $this->getCategoryIds();
			foreach ($this->getCategories() as $category) {
				/** @var Df_Catalog_Model_Category $category */
				$result =
					array_merge(
						$result
						,$category->getParentIds()
					)
				;
			}
			$this->_categoryIdsWithAncestors = $result;
		}
		return $this->_categoryIdsWithAncestors;
	}
	/** @var int[] */
	private $_categoryIdsWithAncestors;

	/**
	 * @override
	 * @return Df_AccessControl_Model_Resource_Role
	 */
	public function getResource() {
		return parent::getResource();
	}

	/**
	 * @return bool
	 */
	public function isModuleEnabled() {
		if (!isset($this->_moduleEnabled)) {
			$this->_moduleEnabled = !is_null($this->getId());
		}
		return $this->_moduleEnabled;
	}
	/** @var bool */
	private $_moduleEnabled;

	/**
	 * Говорим системе использовать insert, а не update
	 * @param int $roleId
	 * @return Df_AccessControl_Model_Role
	 */
	public function prepareForInsert($roleId) {
		df_param_integer($roleId, 0);
		$this->getResource()->prepareForInsert();
		$this
			->setId($roleId)
			->isObjectNew(true)
		;
		return $this;
	}

	/**
	 * @param int[] $categoryIds
	 * @return Df_AccessControl_Model_Role
	 */
	public function setCategoryIds(array $categoryIds) {
		df_param_array($categoryIds, 0);
		$this->_categoryIds = $categoryIds;
		$this->setDataChanges(true);
		return $this;
	}

	/**
	 * @override
	 * @return Df_Core_Model_Abstract
	 */
	protected function _beforeSave() {
		$this
			->setData(
				self::PARAM__CATEGORIES
				,implode(Df_Core_Const::T_COMMA, $this->getCategoryIds())
			)
		;
		parent::_beforeSave();
	}

	/**
	 * @return Df_Catalog_Model_Resource_Category_Collection
	 */
	private function getCategories() {
		if (!isset($this->_categories)) {
			/** @var Df_Catalog_Model_Resource_Category_Collection $result */
			$result = Df_Catalog_Model_Resource_Category_Collection::i();
			$result
				->setFlag(
					Df_AccessControl_Model_Handler_Catalog_Category_Collection_ExcludeForbiddenCategories
						::DISABLE_PROCESSING
					,true
				)
			;
			$result->addAttributeToSelect('*');
			$result->addIdFilter($this->getCategoryIds());
			$result->addIsActiveFilter();
			$result->addNameToResult();
			df_helper()->catalog()->assert()->categoryCollection($result);
			$this->_categories = $result;
		}
		return $this->_categories;
	}
	/** @var Df_Catalog_Model_Resource_Category_Collection */
	private $_categories;

	/**
	 * @return string
	 */
	private function getCategoryIdsAsString() {
		df_assert($this->isModuleEnabled());
		/** @var string $result */
		$result = $this->cfg(self::PARAM__CATEGORIES, Df_Core_Const::T_EMPTY);
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * Initialize resource
	 */
	protected function _construct() {
		parent::_construct();
		$this->_init(Df_AccessControl_Model_Resource_Role::mf());
	}

	/** @var string */
	protected $_eventPrefix = 'df_access_control_role';
	/** @var string */
	protected $_eventObject = 'role';

	const _CLASS = __CLASS__;
	const PARAM__CATEGORIES = 'categories';
	const PARAM__STORES = 'stores';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_AccessControl_Model_Role
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @param int|string $id
	 * @param string|null $field [optional]
	 * @return Df_AccessControl_Model_Role
	 */
	public static function ld($id, $field = null) {
		return df_load(self::i(), $id, $field);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}