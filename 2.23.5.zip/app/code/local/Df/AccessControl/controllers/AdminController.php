<?php
class Df_AccessControl_AdminController extends Mage_Adminhtml_Controller_Action {
	public function categoriesAction() {
		try {
			/** @var int $roleId */
			$roleId = intval($this->getRequest()->getParam('rid'));
			df_assert_integer($roleId);
			/** @var int $categoryId */
			$categoryId = intval($this->getRequest()->getParam('category'));
			df_assert_integer($categoryId);
			/** @var Df_AccessControl_Block_Admin_Tab_Tree $treeBlock */
			$treeBlock = df_block(Df_AccessControl_Block_Admin_Tab_Tree::mf());
			/** @var array[] $childrenNodes */
			$childrenNodes = $treeBlock->getChildrenNodes($categoryId, $roleId);
			df_assert_array($childrenNodes);
			$this->getResponse()
				->setBody(
					/**
					 * Zend_Json::encode использует json_encode при наличии расширения PHP JSON
					 * и свой внутренний кодировщик при отсутствии расширения PHP JSON.
					 * @see Zend_Json::encode
					 * @link http://stackoverflow.com/questions/4402426/json-encode-json-decode-vs-zend-jsonencode-zend-jsondecode
					 * Обратите внимание,
					 * что расширение PHP JSON не входит в системные требования Magento.
					 * @link http://www.magentocommerce.com/system-requirements
					 * Поэтому использование Zend_Json::encode выглядит более правильным, чем json_encode.
					 */
					Zend_Json::encode($childrenNodes)
				)
			;
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e, true);
		}
	}
}