<?php
class Df_AccessControl_Block_Admin_Tab_Tree	extends Mage_Adminhtml_Block_Catalog_Category_Tree {
	/**
	 * @param int $categoryId
	 * @param int $roleId
	 * @return mixed[][]
	 */
	public function getChildrenNodes($categoryId, $roleId) {
		df_param_integer($categoryId, 0);
		df_param_integer($roleId, 1);
		/** @var mixed[][] $result */
		$result = array();
		/** @var Varien_Data_Tree_Node|null $root */
		$root = $this->getRoot(Df_Catalog_Model_Category::ld($categoryId), 1);
		df_assert($root instanceof Varien_Data_Tree_Node);
		/** @var Varien_Data_Tree $tree */
		$tree = $root->getTree();
		df_assert($tree instanceof Varien_Data_Tree);
		/** @var Varien_Data_Tree_Node|null $node */
		$node = $tree->getNodeById($categoryId);
		if (!is_null($node)) {
			df_assert($node instanceof Varien_Data_Tree_Node);
		}
		if (!is_null($node) && $node->hasChildren()) {
			foreach ($node->getChildren() as $child) {
				/** Varien_Data_Tree_Node $node */
				df_assert($node instanceof Varien_Data_Tree_Node);
				$result[]=
					$this->_getNodeJson($child)
				;
			}
		}
		df_result_array($result);
		return $result;
	}

	/**
	 * @override
	 * @param bool|null $expanded[optional]
	 * @return string
	 */
	public function getLoadTreeUrl($expanded = null) {
		/** @var string $result */
		$result =
			$this
				->getUrl(
					'df_access_control/admin/categories'
					,array(
						'rid' => $this->getRoleId()
					)
				)
		;
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * @override
	 * @param Mage_Catalog_Model_Category|null $parentNodeCategory[optional]
	 * @param int $recursionLevel[optional]
	 * @return Varien_Data_Tree_Node|null
	 */
	public function getRoot($parentNodeCategory = null, $recursionLevel = 3) {
		if (!is_null($parentNodeCategory)) {
			df_assert($parentNodeCategory instanceof Mage_Catalog_Model_Category);
		}
		df_param_integer($recursionLevel, 1);
		/** @var Varien_Data_Tree_Node|null $result */
		$result = parent::getRoot($parentNodeCategory, $recursionLevel);
		if (!is_null($result)) {
			df_assert($result instanceof Varien_Data_Tree_Node);
		}
		return $result;
	}

	/**
	 * @return string
	 */
	public function getSelectedCategoriesAsString() {
		/**
		 * Результат может быть пустой строкой!
		 */
		return implode(Df_Core_Const::T_COMMA, $this->getSelectedCategories());
	}

	/**
	 * @override
	 * @return string|null
	 */
	public function getTemplate() {
		return
			!(
					df_enabled(Df_Core_Feature::ACCESS_CONTROL)
				&&
					df_cfg()->admin()->access_control()->getEnabled()
			)
			? null
			: self::TEMPLATE
		;
	}

	/**
	 * @return bool
	 */
	public function isRootVisible() {
		/** @var bool $result */
		$result =
				!is_null($this->getRoot())
			&&
				$this->getRoot()->getDataUsingMethod('is_visible')
		;
		df_result_boolean($result);
		return $result;
	}

	/**
	 * @return bool
	 */
	public function isTreeEmpty() {
		/** @var bool $result */
		$result =
			!(
					!is_null($this->getRoot())
				&&
					$this->getRoot()->hasChildren()
			)
		;
		df_result_boolean($result);
		return $result;
	}

	/**
	 * Get JSON of a tree node or an associative array
	 * @override
	 * @param Varien_Data_Tree_Node|array $node
	 * @param int $level[optional]
	 * @return mixed[]
	 */
	protected function _getNodeJson($node, $level = 1) {
		if (is_array($node)) {
			$node = new Varien_Data_Tree_Node ($node, 'entity_id', new Varien_Data_Tree);
		}
		df_assert($node instanceof Varien_Data_Tree_Node);
		df_param_integer($level, 1);
		/** @var mixed[] $result */
		$result = parent::_getNodeJson($node, $level);
		/** @var bool $isParent */
		$isParent = $this->_isParentSelectedCategory($node);
		df_assert_boolean($isParent);
		/** @var bool $needBeChecked */
		$needBeChecked =
			in_array(
				$node->getId()
				,$this->getSelectedCategories()
			)
		;
		df_assert_boolean($needBeChecked);
		if ($needBeChecked) {
			$result['checked'] = true;
		}
		if ($isParent || $needBeChecked) {
			$result['expanded'] = true;
		}
		df_result_array($result);
		return $result;
	}

	/**
	 * @return Df_AccessControl_Model_Role
	 */
	private function getRole() {
		if (!isset($this->_role)) {
			$this->_role = df_model(Df_AccessControl_Model_Role::mf());
			/**
			 * Обратите внимание,
			 * что объект Df_AccessControl_Model_Role может отсутствовать в БД.
			 * Видимо, это дефект моего программирования 2011 года.
			 */
			$this->_role->load($this->getRoleId());
		}
		return $this->_role;
	}
	/** @var Df_AccessControl_Model_Role */
	private $_role;

	/**
	 * @return int|null
	 */
	private function getRoleId() {
		/** @var int|null $result */
		$result =
			df_request('rid')
		;
		if (!is_null($result)) {
			df_result_integer($result);
		}
		return $result;
	}

	/**
	 * @return int[]
	 */
	private function getSelectedCategories() {
		if (!isset($this->_selectedCategories)) {
			/** @var int[] $result */
			$result =
					!$this->getRole()->isModuleEnabled()
				?
					array()
				:
					$this->getRole()->getCategoryIds()
			;
			df_result_array($result);
			$this->_selectedCategories = $result;
		}
		return $this->_selectedCategories;
	}
	/** @var int[] */
	private $_selectedCategories;

	const _CLASS = __CLASS__;
	const TEMPLATE = 'df/access_control/tab/tree.phtml';

	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}