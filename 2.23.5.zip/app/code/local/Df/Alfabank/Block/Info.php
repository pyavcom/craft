<?php
class Df_Alfabank_Block_Info extends Df_Payment_Block_Info {
	/**
	 * @return Df_Alfabank_Model_Response_State
	 */
	public function getState() {
		if (!isset($this->_state)) {
			$this->_state =	Df_Alfabank_Model_Response_State::i();
			$this->_state->loadFromPaymentInfo($this->getInfo());
		}
		return $this->_state;
	}
	/** @var Df_Alfabank_Model_Response_State */
	private $_state;

	/**
	 * @override
	 * @return string
	 */
	protected function getDefaultTemplate() {
		return 'df/alfabank/info.phtml';
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}