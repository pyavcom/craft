<?php
/**
 * @method Df_Alfabank_Model_Config_Area_Service getServiceConfig()
 */
class Df_Alfabank_Model_Request_Payment extends Df_Payment_Model_Request_Payment {
	/**
	 * @return string
	 */
	public function getPaymentPageUrl() {
		return df_a($this->getResponseAsArray(), 'formUrl');
	}

	/**
	 * @override
	 * @return array(string => string|int)
	 */
	protected function getParamsInternal() {
		/** @var array(string => string|int) $result */
		$result =
			array(
				'amount' => intval(round(100 * $this->getAmount()->getAsFixedFloat()))
				,'currency' => 810
				,'orderNumber' => $this->getOrder()->getIncrementId()
				,'password' => $this->getServiceConfig()->getRequestPassword()
				,'returnUrl' => $this->getCustomerReturnUrl()
				,'userName' => $this->getServiceConfig()->getShopId()
			)
		;
		return $result;
	}

	/**
	 * @return string
	 */
	private function getCustomerReturnUrl() {
		if (!isset($this->_customerReturnUrl)) {
			$this->_customerReturnUrl =
				Mage::getUrl(
					implode(
						Df_Core_Const::T_URL_PATH_SEPARATOR
						,array($this->getPaymentMethod()->getCode(), 'customerReturn')
					)
					,array(
						'_query' =>
							array(
								Df_Alfabank_Model_Action_CustomerReturn
									::REQUEST_PARAM__ORDER_INCREMENT_ID =>
										$this->getOrder()->getIncrementId()
							)
					)
				)
			;
		}
		return $this->_customerReturnUrl;
	}
	/** @var string */
	private $_customerReturnUrl;

	/**
	 * @return array(string => string)
	 */
	private function getResponseAsArray() {
		if (!isset($this->_responseAsArray)) {
			/** @var array(string => string) $result */
			$result = null;
			try {
				$result = Zend_Json::decode($this->getResponseAsJson());
			}
			catch (Zend_Json_Exception $e) {
				$this->getPaymentMethod()
					->logFailureHighLevel(
						'Платёжный шлюз при регистрации заказа в системе вернул недопустимый ответ: «%s».'
						,$this->getResponseAsJson()
					)
				;
				$this->getPaymentMethod()->logFailureLowLevel($e);
				df_error(self::T__GENERIC_ERROR_MESSAGE);
			}
			df_result_array($result);
			/** @var int $errorCode */
			$errorCode = intval(df_a($result, 'errorCode'));
			if (0 !== $errorCode) {
				df_error(df_a($result, 'errorMessage', self::T__GENERIC_ERROR_MESSAGE));
			}
			$this->getPaymentMethod()->getInfoInstance()
				->setAdditionalInformation(
					Df_Alfabank_Model_Payment::INFO__PAYMENT_EXTERNAL_ID
					,df_a($result, 'orderId')
				)
				->save()
			;
			$this->_responseAsArray = $result;
		}
		return $this->_responseAsArray;
	}
	/** @var array(string => string) */
	private $_responseAsArray;

	/**
	 * @return string
	 */
	private function getResponseAsJson() {
		if (!isset($this->_responseAsJson)) {
			/** @var Zend_Uri_Http $uri */
			$uri = $this->getServiceConfig()->getUriPayment();
			$uri->setQuery($this->getParams());
			/** @var Zend_Http_Client $httpClient */
			$httpClient = new Zend_Http_Client();
			$httpClient
				->setHeaders(array())
				->setUri($uri)
				->setConfig(array('timeout' => 10))
			;
			/** @var Zend_Http_Response $response */
			$response = $httpClient->request(Zend_Http_Client::GET);
			/** @var string $responseAsJson */
			$this->_responseAsJson = $response->getBody();
			if (df_empty($this->_responseAsJson)) {
				df_error(self::T__GENERIC_ERROR_MESSAGE);
			}
		}
		return $this->_responseAsJson;
	}
	/** @var string */
	private $_responseAsJson;

	const _CLASS = __CLASS__;
	const T__GENERIC_ERROR_MESSAGE =
		'Платёжный шлюз Альфа-Банка в настоящее время не отвечает.<br/>Пожалуйста, выберите другой способ оплаты или оформите заказ по телефону.'
	;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}


