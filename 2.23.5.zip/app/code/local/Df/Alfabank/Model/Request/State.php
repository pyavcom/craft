<?php
class Df_Alfabank_Model_Request_State extends Df_Alfabank_Model_Request_Secondary {
	/**
	 * @override
	 * @return string
	 */
	protected function getGenericFailureMessageUniquePart() {
		return 'запросе состояния заказа в системе Альфа-Банка';
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getResponseClassMf() {
		return Df_Alfabank_Model_Response_State::mf();
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getServiceName() {
		return 'getOrderStatus';
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Alfabank_Model_Request_State
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}


