<?php
/**
 * @method Df_Alfabank_Model_Payment getPaymentMethod()
 * @method Df_Alfabank_Model_Response getResponse()
 * @method Df_Alfabank_Model_Config_Area_Service getServiceConfig()
 */
abstract class Df_Alfabank_Model_Request_Secondary extends Df_Payment_Model_Request_Secondary {
	/**
	 * @return string
	 */
	abstract protected function getServiceName();

	/**
	 * @return array(string => string|int|float)
	 */
	protected function getAdditionalParams() {
		return array();
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getPaymentExternalId() {
		/** @var string $result */
		$result =
			$this->getOrderPayment()->getAdditionalInformation(
				Df_Alfabank_Model_Payment::INFO__PAYMENT_EXTERNAL_ID
			)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return array(string => string)
	 */
	protected function getResponseAsArray() {
		if (!isset($this->_responseAsArray)) {
			try {
				$this->_responseAsArray = Zend_Json::decode($this->getResponseAsJson());
			}
			catch (Zend_Json_Exception $e) {
				df_log_exception($e);
				df_error($this->getGenericFailureMessage());
			}
			df_result_array($this->_responseAsArray);
		}
		return $this->_responseAsArray;
	}
	/** @var array(string => string) */
	private $_responseAsArray;

	/**
	 * @return array(string => string|int)
	 */
	private function getParams() {
		/** @var array(string => string|int) $result */
		$result =
			array_merge(
				array(
					'userName' => $this->getServiceConfig()->getShopId()
					,'password' => $this->getServiceConfig()->getRequestPassword()
					,'orderId' => $this->getPaymentExternalId()
				)
				,$this->getAdditionalParams()
			)
		;
		return $result;
	}

	/**
	 * @return string
	 */
	private function getResponseAsJson() {
		if (!isset($this->_responseAsJson)) {
			/** @var Zend_Uri_Http $uri */
			$uri = $this->getServiceConfig()->getUri($this->getServiceName());
			$uri->setQuery($this->getParams());
			/** @var Zend_Http_Client $httpClient */
			$httpClient = new Zend_Http_Client();
			$httpClient
				->setHeaders(array())
				->setUri($uri)
				->setConfig(array('timeout' => 10))
			;
			/** @var Zend_Http_Response $response */
			$response = $httpClient->request(Zend_Http_Client::GET);
			/** @var string $responseAsJson */
			$this->_responseAsJson = $response->getBody();
			if (df_empty($this->_responseAsJson)) {
				df_error($this->getGenericFailureMessage());
			}
		}
		return $this->_responseAsJson;
	}
	/** @var string */
	private $_responseAsJson;
}