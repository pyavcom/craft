<?php
class Df_Alfabank_Model_Response_State extends Df_Alfabank_Model_Response {
	/**
	 * @return int
	 */
	public function getAuthCode() {
		return intval($this->cfg('authCode'));
	}

	/**
	 * @return string
	 */
	public function getCardholderName() {
		return strval($this->cfg('cardholderName'));
	}

	/**
	 * @return string
	 */
	public function getCardNumberMasked() {
		return strval($this->cfg('Pan'));
	}

	/**
	 * @return int
	 */
	public function getCurrencyCode() {
		return intval($this->cfg('currency'));
	}

	/**
	 * @return int
	 */
	public function getDepositAmount() {
		return intval($this->cfg('depositAmount'));
	}

	/**
	 * @override
	 * @return array(int => string)
	 */
	protected function getErrorCodeMap() {
		return
			df_array_merge_assoc(
				parent::getErrorCodeMap()
				,array(
					2 => 'Заказ отклонен по причине ошибки в реквизитах платежа'
				)
			)
		;
	}

	/**
	 * @return string
	 */
	public function getIpAddress() {
		return strval($this->cfg('Ip'));
	}

	/**
	 * @return string
	 */
	public function getOrderIncrementId() {
		return strval($this->cfg('OrderNumber'));
	}

	/**
	 * @return int
	 */
	public function getPaymentStatus() {
		return intval($this->cfg('OrderStatus'));
	}

	/**
	 * @return string
	 */
	public function getPaymentStatusMeaning() {
		return
			df_a(
				array(
					0 => 'Заказ зарегистрирован, но не оплачен'
					,1 => 'Проведена предавторизация суммы заказа'
					,2 => 'Проведена полная авторизация суммы заказа'
					,3 => 'Авторизация отменена'
					,4 => 'По транзакции была проведена операция возврата'
					,5 => 'Инициирована авторизация через ACS банка-эмитента'
					,6 => 'Авторизация отклонена'
				)
				,$this->getPaymentStatus()
				,'Неизвестно'
			)
		;
	}

	/**
	 * @return int
	 */
	public function getPaymentAmount() {
		return intval($this->cfg('Amount'));
	}

	/**
	 * @override
	 * @return array(string => string)
	 */
	public function getReportAsArray() {
		if (!isset($this->_reportAsArray)) {
			$this->_reportAsArray =
				df_clean(
					array(
						'Диагностическое сообщение' => $this->showIfFailed($this->getErrorMessage())
						,'Состояние платежа' => $this->getPaymentStatusMeaning()
						,'Детали сбоя' => $this->showIfFailed($this->getErrorCodeMeaning())
						,'Номер заказа' => $this->getOrderIncrementId()
						,'Имя владельца карты' => $this->getCardholderName()
						,'Номер карты' => $this->getCardNumberMasked()
						,'Размер платежа' => sprintf('%.2f', $this->getPaymentAmount() / 100)
						,'Код валюты' => $this->getCurrencyCode()
						,'Адрес IP плательщика' => $this->getIpAddress()
					)
				)
			;
		}
		return $this->_reportAsArray;
	}
	/** @var array(string => string) */
	private $_reportAsArray;

	/**
	 * @override
	 * @return bool
	 */
	public function isTransactionClosed() {
		// Помечаем транзакцию закрытой,
		// только если деньги с покупателя списаны.
		return (2 === $this->getPaymentStatus());
	}

	/**
	 * @override
	 * @return string
	 */
	public function getTransactionType() {
		return
			$this->isTransactionClosed()
			? Mage_Sales_Model_Order_Payment_Transaction::TYPE_PAYMENT
			: Mage_Sales_Model_Order_Payment_Transaction::TYPE_AUTH
		;
	}

	/**
	 * @override
	 * @return Df_Alfabank_Model_Response_State
	 * @throws Df_Payment_Exception_Response
	 */
	public function throwOnFailure() {
		parent::throwOnFailure();
		if (!in_array($this->getPaymentStatus(), array(1, 2, 5))) {
			$this->throwException('Заказ не был оплачен.');
		}
		return $this;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getKey_ErrorCode() {
		return 'ErrorCode';
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getKey_ErrorMessage() {
		return 'ErrorMessage';
	}

	/**
	 * @return string[]
	 */
	protected function getKeysToSuppress() {
		return array('Состояние платежа');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Alfabank_Model_Response_State
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}