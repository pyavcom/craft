<?php
class Df_Alfabank_TestController extends Mage_Core_Controller_Front_Action {
	/**
	 * @return void
	 */
	public function indexAction() {
		try {
			/** @var array(string => string|int) $params */
			$params =
				array(
					'userName' => 'faceandtable-api'
					,'password' => 'faceandtable'
					,'orderNumber' => rm_uniqid(5)
					,'amount' => 100 * 100
					,'currency' => 810
					,'returnUrl' => Mage::getBaseUrl()
				)
			;
			/** @var Zend_Uri_Http $uri */
			$uri = Zend_Uri::factory('https');
			$uri->setHost('test.paymentgate.ru');
			$uri->setPath('/testpayment/rest/register.do');
			$uri
				->setQuery(
					$params
				)
			;
			/** @var Zend_Http_Client $httpClient */
			$httpClient = new Zend_Http_Client();
			$httpClient
				->setHeaders(
					array(
						//'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
						//,'Accept-Encoding' => 'gzip, deflate'
						//,'Accept-Language' => 'en-US,en;q=0.5'
						//,'Connection' => 'keep-alive'
						//,'Host' => 'test.paymentgate.ru'
						//,'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'
						//,Df_Core_Const::HTTP_HEADER__CONTENT_TYPE => 'application/x-www-form-urlencoded'
					)
				)
				->setUri($uri)
				->setConfig(
					array(
						/**
						 * в секундах
						 */
						'timeout' => 3
					)
				)
				//->setParameterPost($params)
			;
			/** @var Zend_Http_Response $response */
			$response =
				$httpClient->request(
					Zend_Http_Client::GET
				)
			;
			/** @var string $responseAsJson */
			$responseAsJson = $response->getBody();
			Mage::log('response: ' . $responseAsJson);
			/** @var array(string => string) $responseAsArray */
			$responseAsArray =
				/**
				 * Zend_Json::decode использует json_decode при наличии расширения PHP JSON
				 * и свой внутренний кодировщик при отсутствии расширения PHP JSON.
				 * @see Zend_Json::decode
				 * @link http://stackoverflow.com/questions/4402426/json-encode-json-decode-vs-zend-jsonencode-zend-jsondecode
				 * Обратите внимание,
				 * что расширение PHP JSON не входит в системные требования Magento.
				 * @link http://www.magentocommerce.com/system-requirements
				 * Поэтому использование Zend_Json::decode выглядит более правильным, чем json_decode.
				 */
				Zend_Json::decode($responseAsJson)
			;
			$this
				->getResponse()
				->setHeader(
					$name = Df_Core_Const::HTTP_HEADER__CONTENT_TYPE
					,$value = Df_Core_Const::CONTENT_TYPE__TEXT__UTF_8
					,$replace = false
				)
				->setBody(
					print_r($responseAsArray, $return = true)
				)
			;
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e, true);
		}
	}
}