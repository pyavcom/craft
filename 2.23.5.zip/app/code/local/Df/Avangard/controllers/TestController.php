<?php
class Df_Avangard_TestController extends Mage_Core_Controller_Front_Action {
	/**
	 * @return void
	 */
	public function indexAction() {
		try {
			/** @var array(string => string|int) $params */
			$params =
				array(
					'shop_id' => '4326'
					,'shop_passwd' => 'eJkSPfqMfI'
					,'amount' => 100 * 100
					,'order_number' => rm_uniqid(5)
					,'order_description' => 'описание заказа'
					,'language' => 'RU'
					,'back_url' => Mage::getBaseUrl()
					,'client_name' => 'Федюк Дмитрий Сергеевич'
					,'client_address' => 'Москва, Красная Площадь, дом 1'
					,'client_phone' => '+79629197300'
					,'client_email' => 'support@dfediuk.com'
					,'client_ip' => '127.0.0.1'
				)
			;
			/** @var Df_Avangard_Model_RequestDocument $registration */
			$registration = Df_Avangard_Model_RequestDocument::registration($params);
			//Mage::log($registration->getXml());
			/** @var Zend_Uri_Http $uri */
			$uri = Zend_Uri::factory('https');
			$uri->setHost('www.avangard.ru');
			$uri->setPath('/iacq/h2h/reg');
			/** @var Zend_Http_Client $httpClient */
			$httpClient = new Zend_Http_Client();
			$httpClient
				->setHeaders(array())
				->setUri($uri)
				->setConfig(array('timeout' => 3))
				->setParameterPost(array(
					'xml' => $registration->getXml()
				))
			;
			/** @var Zend_Http_Response $response */
			$response = $httpClient->request(Zend_Http_Client::POST);
			/** @var string $responseAsJson */
			$responseAsXml = $response->getBody();
			//Mage::log('response: ' . $responseAsXml);
			/** @var Df_Avangard_Model_Response_Registration $response */
			$response = Df_Avangard_Model_Response_Registration::i($responseAsXml);
			Mage::log($response->getPaymentExternalId());
			$this
				->getResponse()
				->setHeader(
					$name = Df_Core_Const::HTTP_HEADER__CONTENT_TYPE
					,$value = Df_Core_Const::CONTENT_TYPE__XML__WINDOWS_1251
					,$replace = false
				)
				->setBody($responseAsXml)
			;
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e, true);
		}
	}
}