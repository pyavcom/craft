<?php
class Df_Avangard_Model_RequestDocument extends Df_Core_Model_SimpleXml_Generator_Document {
	/**
	 * @override
	 * @return Df_Varien_Simplexml_Element
	 */
	protected function createElement() {
		return parent::createElement()->importArray($this->getRequestParams());
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getTagName() {
		return $this->cfg(self::PARAM__TAG_NAME);
	}

	/**
	 * @return array(string => string)
	 */
	private function getRequestParams() {
		return $this->cfg(self::PARAM__REQUEST_PARAMS);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->addValidator(self::PARAM__REQUEST_PARAMS, new Df_Zf_Validate_Array())
			->addValidator(self::PARAM__TAG_NAME, new Df_Zf_Validate_String())
		;
	}
	const _CLASS = __CLASS__;
	const PARAM__REQUEST_PARAMS = 'request_params';
	const PARAM__TAG_NAME = 'tag_name';
	const TAG__REGISTRATION = 'new_order';
	const TAG__REFUND = 'reverse_order';
	const TAG__STATE = 'get_order_info';
	/**
	 * @static
	 * @param mixed[] $requestParameters
	 * @param string $tagName
	 * @return Df_Avangard_Model_RequestDocument
	 */
	public static function i(array $requestParameters, $tagName) {
		return
			df_model(
				self::mf()
				,array(
					self::PARAM__REQUEST_PARAMS => $requestParameters
					,self::PARAM__TAG_NAME => $tagName
				)
			)
		;
	}

	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

	/**
	 * @static
	 * @param mixed[] $requestParameters
	 * @return Df_Avangard_Model_RequestDocument
	 */
	public static function registration(array $requestParameters) {
		return self::i($requestParameters, self::TAG__REGISTRATION);
	}

	/**
	 * @static
	 * @param mixed[] $requestParameters
	 * @return Df_Avangard_Model_RequestDocument
	 */
	public static function refund(array $requestParameters) {
		return self::i($requestParameters, self::TAG__REFUND);
	}

	/**
	 * @static
	 * @param mixed[] $requestParameters
	 * @return Df_Avangard_Model_RequestDocument
	 */
	public static function state(array $requestParameters) {
		return self::i($requestParameters, self::TAG__STATE);
	}
}