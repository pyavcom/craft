<?php
abstract class Df_Avangard_Model_Response extends Df_Payment_Model_Response {
	/**
	 * @return int
	 */
	public function getRequestExternalId() {
		return intval($this->cfg('id'));
	}

	/**
	 * @return int
	 */
	public function getResponseCode() {
		return intval($this->cfg('response_code'));
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getErrorMessage() {
		return $this->cfg('response_message');
	}

	/**
	 * @override
	 * @return bool
	 */
	protected function isSuccessful() {
		return (0 === $this->getResponseCode());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}