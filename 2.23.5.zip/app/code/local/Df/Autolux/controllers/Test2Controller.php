<?php
class Df_Autolux_Test2Controller extends Mage_Core_Controller_Front_Action {
	/**
	 * @return void
	 */
	public function indexAction() {
		try {
			/** @var Df_Autolux_Model_Request_Rate $api */
			$api = Df_Autolux_Model_Request_Rate::i();
			$this
				->getResponse()
				->setHeader(
					$name = Df_Core_Const::HTTP_HEADER__CONTENT_TYPE
					,$value = Df_Core_Const::CONTENT_TYPE__TEXT__UTF_8
					,$replace = false
				)
				->setBody(
					print_r(
						array(
							'Factor Volume' => $api->getFactorVolume()
							,'Factor Weight' => $api->getFactorWeight()
						)
						,true
					)
				)
			;
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e, false);
			echo $e->getMessage();
		}
	}
}