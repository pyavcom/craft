<?php
abstract class Df_Autolux_Model_Method extends Df_Shipping_Model_Method {
	/**
	 * @abstract
	 * @return bool
	 */
	abstract protected function needDeliverToHome();

	/**
	 * @override
	 * @return float
	 */
	public function getCost() {
		if (!isset($this->_cost)) {
			if (0 === $this->getCostInHryvnias()) {
				$this->throwExceptionCalculateFailure();
			}
			/** @var float $result */
			$result =
				df_helper()->directory()->currency()->convertFromHryvniasToBase(
					$this->getCostInHryvnias()
				)
			;
			df_result_float($result);
			$this->_cost = $result;
		}
		return $this->_cost;
	}
	/** @var float */
	private $_cost;

	/**
	 * @override
	 * @return bool
	 * @throws Exception
	 */
	public function isApplicable() {
		/** @var bool $result */
		$result = parent::isApplicable();
		if ($result) {
			try {
				$this
					->checkCountryOriginIs(Df_Directory_Helper_Country::ISO_2_CODE__UKRAINE)
					->checkCountryDestinationIs(Df_Directory_Helper_Country::ISO_2_CODE__UKRAINE)
					->checkCityOriginIsNotEmpty()
					->checkCityDestinationIsNotEmpty()
				;
				if (df_empty($this->getLocationIdOrigin())) {
					$this->throwExceptionInvalidOrigin();
				}
				if (df_empty($this->getLocationIdDestination())) {
					$this->throwExceptionInvalidDestination();
				}
			}
			catch(Exception $e) {
				if ($this->needDisplayDiagnosticMessages()) {
					throw $e;
				}
				else {
					$result = false;
				}
			}
		}
		df_result_boolean($result);
		return $result;
	}

	/**
	 * @override
	 * @return array
	 */
	protected function getLocations() {
		return Df_Autolux_Model_Request_Locations::s()->getLocations();
	}

	/**
	 * @return Df_Autolux_Model_Request_Rate
	 */
	private function getApi() {
		if (!isset($this->_api)) {
			$this->_api = Df_Autolux_Model_Request_Rate::i($this->getQueryParams());
		}
		return $this->_api;
	}
	/** @var Df_Autolux_Model_Request_Rate */
	private $_api;	

	/**
	 * @return float
	 */
	private function getCostInHryvnias() {
		/** @var float $result */
		$result =
				$this->getCostInsurance();
			+
				$this->getRatePrimary()
		;
		if ($this->needDeliverToHome()) {
			$result += 50;
		}
		if ($this->getRmConfig()->service()->needGetCargoFromTheShopStore()) {
			$result += 50;
		}
		/**
		 * Стоимость отправки оплаты за груз составляет 14 грн. и 1% от суммы.
		 */
		$result += (14 + (0.01 * $result));
		return $result;
	}

	/**
	 * @return float
	 */
	private function getCostInsurance() {
		/** @var float $result */
		$result =
			max(
				1
				,0.01
				*
					df_helper()->directory()->currency()->convertFromBaseToHryvnias(
						$this->getRequest()->getDeclaredValue()
					)
			)
		;
		return $result;
	}

	/**
	 * @return array
	 */
	private function getQueryParams() {
		return
			array(
				'arrival' => $this->getLocationIdDestination()
				,'departure' => $this->getLocationIdOrigin()
			)
		;
	}

	/**
	 * @return float
	 */
	private function getRatePrimary() {
		/** @var float $rateByWeight */
		$rateByWeight =
			max(1, $this->getApi()->getFactorWeight() * $this->getRequest()->getWeightInKilogrammes())
		;
		/** @var float $rateByVolume */
		$rateByVolume =
			max(1, $this->getApi()->getFactorVolume() * $this->getRequest()->getVolumeInCubicMetres())
		;
		/** @var float $result */
		$result = ceil(max($rateByWeight, $rateByVolume));
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}