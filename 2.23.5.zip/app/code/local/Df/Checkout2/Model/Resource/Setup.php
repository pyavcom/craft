<?php
class Df_Checkout2_Model_Resource_Setup extends Df_Core_Model_Resource_Setup_Abstract {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		return 'df_checkout2/setup';
	}
}