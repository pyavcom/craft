<?php
class Df_Chronopay_Helper_Cardholder_Name_Converter_Config extends Mage_Core_Helper_Abstract {
	/**
	 * @return array
	 */
	public function getConversionTable() {
		return
			array(
				"Æ" => "AE"
				, "Ø" => "OE"
				, "Å" => "AA"
			)
		;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}