<?php
class Df_Chronopay_Block_Gate_Response extends Df_Core_Block_Template {
	/**
	 * @return array(string => string)
	 */
	public function getItems() {
		if (!isset($this->_items)) {
			$this->_items =
				array(
					'ChronoPay error code' => $this->getResponse()->getCode()
					,'ChronoPay error message'  => $this->getResponse()->getMessage()
					,'Transaction ID'  => $this->getResponse()->getTransactionId()
					,'ChronoPay extended error code'  => $this->getResponse()->getExtendedCode()
					,'ChronoPay extended error message'  => $this->getResponse()->getExtendedMessage()
				)
			;
		}
		return $this->_items;
	}
	/** @var array(string => string) */
	private $_items;

	/**
	 * @return Df_Chronopay_Model_Gate_Response
	 */
	public function getResponse() {
		return $this->cfg(self::PARAM__RESPONSE);
	}

	const _CLASS = __CLASS__;
	const PARAM__RESPONSE = 'response';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}