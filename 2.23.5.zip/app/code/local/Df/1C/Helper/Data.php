<?php
class Df_1C_Helper_Data extends Mage_Core_Helper_Abstract implements Df_Dataflow_Logger {
	/**
	 * @param int $attributeSetId
	 * @return Df_1C_Helper_Data
	 */
	public function create1CAttributeGroupIfNeeded($attributeSetId) {
		df_param_integer($attributeSetId, 0);
		df_param_between($attributeSetId, 0, 1);
		df_helper()->catalog()->product()
			->addGroupToAttributeSetIfNeeded(
				$attributeSetId
				,Df_1C_Const::PRODUCT_ATTRIBUTE_GROUP_NAME
				,$sortOrder = 2
			)
		;
		return $this;
	}

	/**
	 * @return Df_1C_Helper_Cml2
	 */
	public function cml2() {
		return Mage::helper(Df_1C_Helper_Cml2::mf());
	}

	/**
	 * @param string|float $money
	 * @return string
	 */
	public function formatMoney($money) {
		return sprintf(floatval($money), '.2f');
	}

	/**
	 * @param string|array(string|int => string) $message
	 * @return Df_1C_Helper_Data
	 */
	public function log($message) {
		/** @var bool $needLogging */
		static $needLogging;
		if (!isset($needLogging)) {
			$needLogging = df_cfg()->_1c()->general()->needLogging();
		}
		if ($needLogging) {
			Mage::log($message, null, 'rm.1c.log', true);
		}
		return $this;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}