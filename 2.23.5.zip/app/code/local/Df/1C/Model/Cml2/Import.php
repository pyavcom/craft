<?php
abstract class Df_1C_Model_Cml2_Import extends Df_Core_Model_Abstract {
	/**
	 * @abstract
	 * @return Df_1C_Model_Cml2_Import
	 */
	abstract public function process();

	/**
	 * @return Df_1C_Helper_Cml2_Registry
	 */
	protected function getRegistry() {
		return df_helper()->_1c()->cml2()->registry();
	}

	/**
	 * @return Varien_Simplexml_Element
	 */
	protected function getSimpleXmlElement() {
		return $this->cfg(self::PARAM__SIMPLE_XML);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->validateClass(self::PARAM__SIMPLE_XML, 'Varien_Simplexml_Element');
	}
	const _CLASS = __CLASS__;
	const PARAM__SIMPLE_XML = 'simple_xml';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}