<?php
class Df_1C_Model_Cml2_Action_Catalog_Import extends Df_1C_Model_Cml2_Action_Catalog {
	/**
	 * @override
	 * @return Df_1C_Model_Cml2_Action
	 */
	protected function processInternal() {
		switch($this->getFileRelativePath()) {
			case Df_1C_Model_Cml2_Registry_Import_Files::FILE__IMPORT:
				$this->importCategories();
				$this->importReferenceLists();
				break;
			case Df_1C_Model_Cml2_Registry_Import_Files::FILE__OFFERS:
				$this->importProductsSimple();
				$this->importProductsSimplePartImages();
				$this->importProductsConfigurable();
				$this->importProductsConfigurablePartImages();
				df_helper()->_1c()->log('Начата перестройка расчётных таблиц.');
				df_helper()->index()->reindexEverything();
				df_helper()->_1c()->log('Завершена перестройка расчётных таблиц.');
				break;
			default:
				df_error('Непредусмотренный файл: %s', $this->getFileRelativePath());
				break;
		}
		$this->setResponseBodyAsArrayOfStrings(array('success', Df_Core_Const::T_EMPTY));
		return $this;
	}

	/**
	 * @return Varien_Simplexml_Element
	 */
	protected function getSimpleXmlElement() {
		return $this->getFiles()->getByRelativePath($this->getFileRelativePath());
	}

	/**
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	private function importCategories() {
		df_helper()->_1c()->log('Импорт товарных разделов начат.');
		foreach ($this->getRegistry()->import()->collections()->getCategories() as $category) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Category $category */
			df_assert($category instanceof Df_1C_Model_Cml2_Import_Data_Entity_Category);
			Df_1C_Model_Cml2_Import_Processor_Category::i(
				$this->getRegistry()->import()->getRootCategory(), $category
			)->process();
		}
		df_helper()->_1c()->log('Импорт товарных разделов завершён.');
		return $this;
	}

	/**
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	private function importProductsConfigurable() {
		df_helper()->_1c()->log('Импорт настраиваемых товаров начат.');
		foreach ($this->getRegistry()->import()->collections()->getOffers() as $offer) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer */
			df_assert($offer instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
			Df_1C_Model_Cml2_Import_Processor_Product_Type_Configurable::i($offer)->process();
		}
		df_helper()->_1c()->log('Импорт настраиваемых товаров завершён.');
		return $this;
	}

	/**
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	private function importProductsConfigurablePartImages() {
		foreach ($this->getRegistry()->import()->collections()->getOffers() as $offer) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer */
			df_assert($offer instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
			if ($offer->isTypeConfigurableParent()) {
				Df_1C_Model_Cml2_Import_Processor_Product_Part_Images::i($offer)->process();
			}
		}
		return $this;
	}

	/**
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	private function importProductsSimple() {
		df_helper()->_1c()->log('Импорт простых товаров начат.');
		foreach ($this->getRegistry()->import()->collections()->getOffers() as $offer) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer */
			df_assert($offer instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
			Df_1C_Model_Cml2_Import_Processor_Product_Type_Simple::i($offer)->process();
		}
		df_helper()->_1c()->log('Импорт простых товаров завершён.');
		return $this;
	}

	/**
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	private function importProductsSimplePartImages() {
		foreach ($this->getRegistry()->import()->collections()->getOffers() as $offer) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer */
			df_assert($offer instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
			if ($offer->isTypeSimple()) {
				Df_1C_Model_Cml2_Import_Processor_Product_Part_Images::i($offer)->process();
			}
		}
		return $this;
	}

	/**
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	private function importReferenceLists() {
		df_helper()->_1c()->log('Импорт справочников начат.');
		foreach ($this->getRegistry()->import()->collections()->getAttributes() as $attribute) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Attribute $attribute */
			df_assert($attribute instanceof Df_1C_Model_Cml2_Import_Data_Entity_Attribute);
			/**
			 * Обратываем только свойства, у которых тип значений — «Справочник».
			 */
			if ($attribute instanceof Df_1C_Model_Cml2_Import_Data_Entity_Attribute_ReferenceList) {
				/** @var Df_1C_Model_Cml2_Import_Data_Entity_Attribute_ReferenceList $attribute */
				Df_1C_Model_Cml2_Import_Processor_ReferenceList::i($attribute)->process();
			}
		}
		df_helper()->_1c()->log('Импорт справочников завершён.');
		return $this;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Action_Catalog_Import
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}