<?php
class Df_1C_Model_Cml2_Import_Data_Collection_PriceTypes
	extends Df_1C_Model_Cml2_Import_Data_Collection {
	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_PriceType
	 */
	public function getMain() {
		if (!isset($this->_main)) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_PriceType|null $result */
			$result =
				$this->findByName(
					df_cfg()->_1c()->product()->prices()->getMain()
				)
			;
			if (is_null($result)) {
				df_error(
					'Тип цен «%s», указанный администратором как основной,'
					.' отсутствует в 1С:Управление торговлей.'
					,df_cfg()->_1c()->product()->prices()->getMain()
				);
			}
			df_assert($result instanceof Df_1C_Model_Cml2_Import_Data_Entity_PriceType);
			$this->_main = $result;
		}
		return $this->_main;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Entity_PriceType */
	private $_main;

	/**
	 * @override
	 * @return Varien_Simplexml_Element
	 */
	public function getSimpleXmlElement() {
		return
			$this->getRegistry()->import()->files('catalog')->getByRelativePath(
				Df_1C_Model_Cml2_Registry_Import_Files::FILE__OFFERS
			)
		;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_PriceType::mf();
	}

	/**
	 * @override
	 * @return string[]
	 */
	protected function getItemsXmlPathAsArray() {
		return
			array(
				Df_Core_Const::T_EMPTY
				,'КоммерческаяИнформация'
				,'ПакетПредложений'
				,'ТипыЦен'
				,'ТипЦены'
			)
		;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_PriceTypes
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_PriceTypes
	 */
	public static function s() {
		return Mage::getSingleton(self::mf());
	}
}