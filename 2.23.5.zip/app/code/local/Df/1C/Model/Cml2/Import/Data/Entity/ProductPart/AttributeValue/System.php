<?php
class Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_System
	extends Df_1C_Model_Cml2_Import_Data_Entity {
	/**
	 * @override
	 * @return string
	 */
	public function getExternalId() {
		/** @var string $result */
		$result = $this->getName();
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getValue() {
		/** @var string $result */
		$result = $this->getEntityParam('Значение');
		df_result_string($result);
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}