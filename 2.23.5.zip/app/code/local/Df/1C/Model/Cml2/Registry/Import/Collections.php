<?php
class Df_1C_Model_Cml2_Registry_Import_Collections extends Df_Core_Model_Abstract {
	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Attributes
	 */
	public function getAttributes() {
		if (!isset($this->_attributes)) {
			$this->_attributes =
				Df_1C_Model_Cml2_Import_Data_Collection_Attributes::i(
					array(
						Df_1C_Model_Cml2_Import_Data_Collection_Products::PARAM__SIMPLE_XML =>
							df_helper()->_1c()->cml2()->registry()->import()->files('catalog')
								->getByRelativePath(
									Df_1C_Model_Cml2_Registry_Import_Files::FILE__IMPORT
								)
					)
				)
			;
		}
		return $this->_attributes;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_Attributes */
	private $_attributes;

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Categories
	 */
	public function getCategories() {
		if (!isset($this->_categories)) {
			$this->_categories =
				Df_1C_Model_Cml2_Import_Data_Collection_Categories::i(
					array(
						Df_1C_Model_Cml2_Import_Data_Collection_Categories::PARAM__SIMPLE_XML =>
							df_helper()->_1c()->cml2()->registry()->import()->files('catalog')
								->getByRelativePath(
									Df_1C_Model_Cml2_Registry_Import_Files::FILE__IMPORT
								)
						,Df_1C_Model_Cml2_Import_Data_Collection_Categories::PARAM__XML_PATH_AS_ARRAY =>
							array(
								Df_Core_Const::T_EMPTY
								,'КоммерческаяИнформация'
								,'Классификатор'
								,'Группы'
								,'Группа'
							)
					)
				)
			;
		}
		return $this->_categories;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_Categories */
	private $_categories;

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Offers
	 */
	public function getOffers() {
		if (!isset($this->_offers)) {
			$this->_offers =
				Df_1C_Model_Cml2_Import_Data_Collection_Offers::i(
					array(
						Df_1C_Model_Cml2_Import_Data_Collection_Offers::PARAM__SIMPLE_XML =>
							df_helper()->_1c()->cml2()->registry()->import()->files('catalog')
								->getByRelativePath(
									Df_1C_Model_Cml2_Registry_Import_Files::FILE__OFFERS
								)
					)
				)
			;
		}
		return $this->_offers;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_Offers */
	private $_offers;		


	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Products
	 */
	public function getProducts() {
		if (!isset($this->_products)) {
			$this->_products =
				Df_1C_Model_Cml2_Import_Data_Collection_Products::i(
					array(
						Df_1C_Model_Cml2_Import_Data_Collection_Products::PARAM__SIMPLE_XML =>
							df_helper()->_1c()->cml2()->registry()->import()->files('catalog')
								->getByRelativePath(
									Df_1C_Model_Cml2_Registry_Import_Files::FILE__IMPORT
								)
					)
				)
			;
		}
		return $this->_products;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_Products */
	private $_products;	

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Registry_Import_Collections
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}