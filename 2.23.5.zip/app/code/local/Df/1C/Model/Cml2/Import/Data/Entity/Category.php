<?php
class Df_1C_Model_Cml2_Import_Data_Entity_Category extends Df_1C_Model_Cml2_Import_Data_Entity {
	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Categories
	 */
	public function getChildren() {
		if (!isset($this->_children)) {
			$this->_children =
				Df_1C_Model_Cml2_Import_Data_Collection_Categories::i(
					array(Df_1C_Model_Cml2_Import_Data_Collection_Categories::PARAM__SIMPLE_XML => $this->e())
				)
			;
		}
		return $this->_children;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_Categories */
	private $_children;	

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}