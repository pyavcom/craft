<?php
abstract class Df_1C_Model_Cml2_Import_Processor_Product_Type
	extends Df_1C_Model_Cml2_Import_Processor_Product {
	/**
	 * @abstract
	 * @return float
	 */
	abstract protected function getPrice();

	/**
	 * @abstract
	 * @return string
	 */
	abstract protected function getSku();

	/**
	 * @abstract
	 * @return string
	 */
	abstract protected function getType();

	/**
	 * @abstract
	 * @return int
	 */
	abstract protected function getVisibility();

	/**
	 * @return Df_Dataflow_Model_Importer_Product
	 */
	protected function getImporter() {
		if (!isset($this->_importer)) {
			/** @var string[] $rowAsArray */
			$rowAsArray = array();
			if (!is_null($this->getExistingMagentoProduct())) {
				$rowAsArray = array_merge($rowAsArray, $this->getProductDataUpdateOnly());
			}
			else {
				$rowAsArray = array_merge($rowAsArray, $this->getProductDataNewOnly());
			}
			$rowAsArray = array_merge($rowAsArray, $this->getProductDataNewOrUpdate());
			$this->_importer =
				Df_Dataflow_Model_Importer_Product::i(
					Df_Dataflow_Model_Import_Product_Row::i($rowAsArray)
				)
			;
		}
		return $this->_importer;
	}
	/** @var Df_Dataflow_Model_Importer_Product */
	private $_importer;

	/**
	 * @return array(string => string)
	 */
	protected function getProductDataNewOrUpdateBase() {
		/** @var int[] $categoryIds */
		$categoryIds = $this->getEntityProduct()->getCategoryIds();
		/**
		 * Сохраняем уже имеющиеся привязки товара к разделам
		 * @link http://magento-forum.ru/topic/3432/
		 */
		if (!is_null($this->getExistingMagentoProduct())) {
			$categoryIds =
				array_merge(
					$categoryIds
					,$this->getExistingMagentoProduct()->getCategoryIds()
				)
			;
		}
		/** @var array(string => string) $result */
		$result =
			array(
				Df_Eav_Const::ENTITY_EXTERNAL_ID => $this->getEntityOffer()->getExternalId()
				,'sku' => $this->getSku()
				,Df_Dataflow_Model_Import_Product_Row::FIELD__SKU_NEW => $this->getSkuToImport()
				,'category_ids' => implode(Df_Core_Const::T_COMMA, $categoryIds)
				,'name' =>
						/**
						 * @link http://magento-forum.ru/topic/3655/
						 */
						Df_1C_Model_Config_Source_ProductNameSource::VALUE__NAME_FULL
					===
						df_cfg()->_1c()->product()->name()->getSource()
					? $this->getEntityProduct()->getNameFull()
					: $this->getEntityOffer()->getName()
				/**
				 * Поле является обязательным при импорте нового товара
				 */
				,'price' => $this->getPrice()
				,'product_name' => $this->getEntityOffer()->getName()
				,'description' => $this->getDescription()
				,'short_description' => $this->getDescriptionShort()
				,'qty' => $this->getEntityOffer()->getQuantity()
			)
		;
		if (!df_empty($this->getEntityProduct()->getWeight())) {
			$result['weight'] = $this->getEntityProduct()->getWeight();
		}
		else {
			/** @var float|null $currentWeight */
			$currentWeight = null;
			if (!is_null($this->getExistingMagentoProduct())) {
				$currentWeight =
					$this->getExistingMagentoProduct()->getDataUsingMethod(
						Df_Catalog_Model_Product::PARAM__WEIGHT
					)
				;
			}
			$result['weight'] = df_empty($currentWeight) ? 0.0 : $currentWeight;
		}
		if (!is_null($this->getExistingMagentoProduct())) {
			/** @var Mage_CatalogInventory_Model_Stock_Item|null $stockItem  */
			$stockItem = $this->getExistingMagentoProduct()->getDataUsingMethod('stock_item');
			if (is_null($stockItem)) {
				$stockItem->assignProduct($this->getExistingMagentoProduct());
			}
			$result['is_in_stock'] =
				(intval($stockItem->getMinQty()) < $this->getEntityOffer()->getQuantity())
			;
		}
		else {
			/** @var int $minQty */
			$minQty =
				intval(
					Mage::getStoreConfig(
						Mage_CatalogInventory_Model_Stock_Item::XML_PATH_MIN_QTY
						,df()->state()->getStoreProcessed()
					)
				)
			;
			$result['is_in_stock'] = ($minQty < $this->getEntityOffer()->getQuantity());
		}
		/** @var array(string => string) $tierPrices */
		$tierPrices = $this->getTierPricesInImporterFormat();
		if (!df_empty($tierPrices)) {
			$result = array_merge($result, $tierPrices);
		}
		return $result;
	}

	/**
	 * @return string[]
	 */
	protected function getProductDataUpdateOnly() {
		return array('store' => $this->getExistingMagentoProduct()->getStore()->getCode());
	}

	/**
	 * @return string
	 */
	private function getDescription() {
		return
			$this->getDescriptionAbstract(
				$productField =	Df_Catalog_Model_Product::PARAM__DESCRIPTION
				,$fieldsToUpdate =
					array(
						Df_1C_Model_Config_Source_WhichDescriptionFieldToUpdate::VALUE__DESCRIPTION
						,Df_1C_Model_Config_Source_WhichDescriptionFieldToUpdate::VALUE__BOTH
					)
			)
		;
	}

	/**
	 * @param string $productField
	 * @param string[] $fieldsToUpdate
	 * @return string
	 */
	private function getDescriptionAbstract($productField, array $fieldsToUpdate) {
		df_param_string($productField, 0);
		/** @var string $result */
		$result = df_cfg()->_1c()->product()->description()->getDefault();
		/** @var string|null $currentDescription */
		$currentDescription =
			is_null($this->getExistingMagentoProduct())
			? null
			: $this->getExistingMagentoProduct()->getDataUsingMethod($productField)
		;
		/** @var bool $canUpdateCurrentDescription */
		$canUpdateCurrentDescription =
				!df_cfg()->_1c()->product()->description()->preserveInUnique()
			||
				df_empty($currentDescription)
			||
				($currentDescription === df_cfg()->_1c()->product()->description()->getDefault())
		;
		/**
		 * Обрабатываем случай,
		 * когда в 1С на товарной карточке заполнено поле «Файл описания для сайта»
		 */
		if (
				(Df_Catalog_Model_Product::PARAM__DESCRIPTION === $productField)
			&&
				!df_empty($this->getEntityProduct()->getDescriptionFull())
		) {
			$result =
				$canUpdateCurrentDescription
				? $this->getEntityProduct()->getDescriptionFull()
				: $currentDescription
			;
		}
		else {
			if (
				!in_array(
					df_cfg()->_1c()->product()->description()->whichFieldToUpdate()
					,$fieldsToUpdate
				)
			) {
				if (!df_empty($currentDescription)) {
					$result = $currentDescription;
				}
			}
			else {
				$result =
					$canUpdateCurrentDescription
					? $this->getEntityProduct()->getDescription()
					: $currentDescription
				;
			}
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getDescriptionShort() {
		return
			$this->getDescriptionAbstract(
				$productField =	Df_Catalog_Model_Product::PARAM__SHORT_DESCRIPTION
				,$fieldsToUpdate =
					array(
						Df_1C_Model_Config_Source_WhichDescriptionFieldToUpdate::VALUE__SHORT_DESCRIPTION
						,Df_1C_Model_Config_Source_WhichDescriptionFieldToUpdate::VALUE__BOTH
					)
			)
		;
	}

	/**
	 * @return string[]
	 */
	private function getProductDataNewOnly() {
		/** @var string[] $result */
		$result =
			array(
				'websites' => df()->state()->getStoreProcessed()->getWebsite()->getId()
				,'attribute_set' =>
					$this->getEntityProduct()->getAttributeSet()->getAttributeSetName()
				,'type' => $this->getType()
				,'product_type_id' => $this->getType()
				,'store' => df()->state()->getStoreProcessed()->getCode()
				,'store_id' => df()->state()->getStoreProcessed()->getId()
				,'has_options' => false
				,'meta_title' => null
				,'meta_description' => null
				,'image' => null
				,'small_image' => null
				,'thumbnail' => null
				,'url_key' => null
				,'url_path' => null
				,'image_label' => null
				,'small_image_label'	=> null
				,'thumbnail_label' => null
				,'country_of_manufacture' => null
				,'visibility' => $this->getVisibilityAsString()
				,'tax_class_id' => Mage::helper('tax')->__('None')
				,'meta_keyword' => null
				,'use_config_min_qty' => true
				,'is_qty_decimal' => null
				,'use_config_backorders' => true
				,'use_config_min_sale_qty' => true
				,'use_config_max_sale_qty' => true
				,'low_stock_date' => null
				,'use_config_notify_stock_qty' => true
				,'manage_stock' => true
				,'use_config_manage_stock' => true
				,'stock_status_changed_auto' => null
				,'use_config_qty_increments' => true
				,'use_config_enable_qty_inc' => true
				,'is_decimal_divided' => null
				,'stock_status_changed_automatically' => null
				,'use_config_enable_qty_increments' => true
			)
		;
		return $result;
	}

	/**
	 * @return string[]
	 */
	private function getProductDataNewOrUpdate() {
		/** @var string[] $result */
		$result =
			array_merge(
				$this->getProductDataNewOrUpdateBase()
				,$this->getProductDataNewOrUpdateAttributeValuesCustom()
				,$this->getProductDataNewOrUpdateOptionValues()
			)
		;
		df_result_array($result);
		return $result;
	}

	/**
	 * @return string[]
	 */
	private function getProductDataNewOrUpdateAttributeValuesCustom() {
		/** @var string[] $result */
		$result = array();
		foreach ($this->getEntityProduct()->getAttributeValuesCustom() as $attributeValue) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom $attributeValue */
			df_assert($attributeValue instanceof Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom);
			if (
				/**
				 * 1C для каждого товара
				 * указывает не только значения свойств, относящихся к товару,
				 * но и значения свойств, к товару никак не относящихся,
				 * при этом значения — пустые, например:
				 *
					<ЗначенияСвойства>
						<Ид>b79b0fe0-c8a5-11e1-a928-4061868fc6eb</Ид>
						<Значение/>
					</ЗначенияСвойства>
				 *
				 * Мы не обрабатываем эти свойства, потому что их обработка приведёт к добавлению
				 * к прикладному типу товара данного свойства, а нам это не нужно, потому что
				 * свойство не имеет отношения к прикладному типу товара.
				 */
				!(
						df_empty($attributeValue->getEntityParam('Значение'))
					&&
						df_empty($attributeValue->getEntityParam('ИдЗначения'))
					&&
						!$attributeValue->isAttributeExistAndBelongToTheProductType()
				)
			)  {
				$result[$attributeValue->getAttributeName()] =
					$attributeValue->getValueForDataflow()
				;
			}
		}
		return $result;
	}

	/**
	 * @return string[]
	 */
	private function getProductDataNewOrUpdateOptionValues() {
		/** @var string[] $result */
		$result = array();
		if (0 < count($this->getEntityOffer()->getOptionValues())) {
			df_helper()->_1c()
				->create1CAttributeGroupIfNeeded(
					$this->getEntityProduct()->getAttributeSet()->getId()
				)
			;
		}
		/**
		 * Импорт значений настраиваемых опций
		 */
		foreach ($this->getEntityOffer()->getOptionValues() as $optionValue) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_OptionValue $optionValue */
			df_assert($optionValue instanceof Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_OptionValue);
			/** @var Mage_Catalog_Model_Resource_Eav_Attribute $attribute */
			$attribute = $optionValue->getAttributeMagento();
			df_assert($attribute instanceof Mage_Catalog_Model_Resource_Eav_Attribute);
			Df_Catalog_Model_Installer_AddAttributeToSet
				::processStatic(
					$attribute->getAttributeCode()
					,$this->getEntityProduct()->getAttributeSet()->getId()
					,Df_1C_Const::PRODUCT_ATTRIBUTE_GROUP_NAME
				)
			;
			/** @var Mage_Eav_Model_Entity_Attribute_Option $option */
			$option = $optionValue->getOption();
			$result[$attribute->getName()] = $option->getData('value');
		}
		df_result_array($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getSkuToImport() {
		/** @var string $result */
		$result = $this->getEntityProduct()->getSku();
		if (!df_empty($result)) {
			/**
			 * Вдруг этот артикул уже использует другой товар?
			 * @var int|null $productIdBySku
			 */
			$productIdBySku = df_helper()->catalog()->product()->getIdBySku($result);
			if (
					!df_empty($productIdBySku)
				&&
					(
							is_null($this->getExistingMagentoProduct())
						||
							($this->getExistingMagentoProduct()->getId() != $productIdBySku)
					)
			) {
				/**
				 * Товар с данным артикулом уже присутствует в магазине.
				 */
				$result = null;
			}
		}
		if (df_empty($result)) {
			$result = $this->getSku();
		}
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * @return mixed[]
	 */
	private function getTierPricesInImporterFormat() {
		if (!isset($this->_tierPricesInImporterFormat)) {
			/** @var mixed[] $result  */
			$result = array();
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_Price|null $mainPrice */
			$mainPrice = $this->getEntityOffer()->getPrices()->getMain();
			foreach ($this->getEntityOffer()->getPrices()->getItems() as $price) {
				/** @var Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_Price $price */
				if (is_null($mainPrice) || ($price->getId() !== $mainPrice->getId())) {
					/** @var int|null $customerGroupId */
					$customerGroupId = $price->getPriceType()->getCustomerGroupId();
					if (!df_empty($customerGroupId)) {
						/** @var string $groupPriceKey */
						$groupPriceKey =
							sprintf(
								'rm_tier_price_%d_%d_%d'
								,df()->state()->getStoreProcessed()->getWebsiteId()
								,$customerGroupId
								,1
							)
						;
						$result[$groupPriceKey] = $price->getPriceBase();
					}
				}
			}
			$this->_tierPricesInImporterFormat = $result;
		}
		return $this->_tierPricesInImporterFormat;
	}
	/** @var mixed[] */
	private $_tierPricesInImporterFormat;

	/**
	 * @return string
	 */
	private function getVisibilityAsString() {
		/** @var string $result */
		$result =
			df_a(
				Mage_Catalog_Model_Product_Visibility::getOptionArray()
				,$this->getVisibility()
			)
		;
		df_result_string($result);
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}