<?php
class Df_1C_Model_Cml2_Import_Data_Collection_Attributes
	extends Df_1C_Model_Cml2_Import_Data_Collection {
	/**
	 * @override
	 * @param Varien_Simplexml_Element $entityAsSimpleXMLElement
	 * @return Df_1C_Model_Cml2_Import_Data_Entity
	 */
	protected function createItemFromSimpleXmlElement(Varien_Simplexml_Element $entityAsSimpleXMLElement) {
		return Df_1C_Model_Cml2_Import_Data_Entity_Attribute::create($entityAsSimpleXMLElement);
	}

	/**
	 * @override
	 * @return Varien_Simplexml_Element[]
	 */
	protected function getImportEntitiesAsSimpleXMLElementArray() {
		if (!isset($this->_importEntitiesAsSimpleXMLElementArray)) {
			/** @var Varien_Simplexml_Element[] $result */
			$result = parent::getImportEntitiesAsSimpleXMLElementArray();
			/**
			 * 11 июля 2013 года в магазине belle.com.ua
			 * («Управление торговлей для Украины» редации 2.3
			 * ,редакция платформы 1С:Предприятие — 10.3) заметил,
			 * что одно свойство описано в import.xml следующим образом:
				<Классификатор>
					(...)
					<Свойства>
						<СвойствоНоменклатуры>
							<Ид>dd6bfa58-d7e9-11d9-bfbc-00112f3000a2</Ид>
							<Наименование>Канал сбыта</Наименование>
							<Обязательное>false</Обязательное>
							<Множественное>false</Множественное>
							<ИспользованиеСвойства>true</ИспользованиеСвойства>
						</СвойствоНоменклатуры>
					</Свойства>
				</Классификатор>
			 * Обратите внимание на использование тега «СвойствоНоменклатуры»
			 * вместо стандартного тега «Свойство».
			 * Причём это происходит в типовой конфигурации
			 * (смотрел программный код той же конфигурации другого магазина).
			 */
			/** @var Varien_Simplexml_Element[] $entitiesFromAdditionalPath */
			$entitiesFromAdditionalPath =
				$this->e()->xpath(
					implode(Df_Core_Const::T_XPATH_SEPARATOR, $this->getItemsXmlPathAsArrayAdditional())
				)
			;
			if (is_array($entitiesFromAdditionalPath)) {
				$result = array_merge($result, $entitiesFromAdditionalPath);
			}
			$this->_importEntitiesAsSimpleXMLElementArray = $result;
		}
		return $this->_importEntitiesAsSimpleXMLElementArray;
	}
	/** @var Varien_Simplexml_Element[] */
	private $_importEntitiesAsSimpleXMLElementArray;

	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_Attribute::mf();
	}

	/**
	 * @override
	 * @return string[]
	 */
	protected function getItemsXmlPathAsArray() {
		return
			array(
				Df_Core_Const::T_EMPTY
				,'КоммерческаяИнформация'
				,'Классификатор'
				,'Свойства'
				,'Свойство'
			)
		;
	}

	/**
	 * @return string[]
	 */
	private function getItemsXmlPathAsArrayAdditional() {
		return
			array(
				Df_Core_Const::T_EMPTY
				,'КоммерческаяИнформация'
				,'Классификатор'
				,'Свойства'
				,'СвойствоНоменклатуры'
			)
		;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Attributes
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}