<?php
class Df_1C_Model_Cml2_Registry_Export_Products extends Df_Varien_Data_Collection {
	/**
	 * @param int $productId
	 * @return Df_Catalog_Model_Product
	 */
	public function getProductById($productId) {
		df_param_integer($productId, 0);
		/** @var Df_Catalog_Model_Product $result */
		$result = $this->getItemById($productId);
		if (is_null($result)) {
			$result =
				Df_Catalog_Model_Product::i(
					array(
						Df_Catalog_Model_Product::PARAM__STORE_ID =>
							df()->state()->getStoreProcessed()->getId()
					)
				)
			;
			$result->load($productId);
			$this->addItem($result);
		}
		df_assert($result instanceof Df_Catalog_Model_Product);
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Registry_Export_Products
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}