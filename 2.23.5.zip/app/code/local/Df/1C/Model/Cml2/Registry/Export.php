<?php
class Df_1C_Model_Cml2_Registry_Export extends Df_Core_Model_Abstract {
	/**
	 * @return Df_1C_Model_Cml2_Registry_Export_Products
	 */
	public function getProducts() {
		if (!isset($this->_products)) {
			$this->_products = Df_1C_Model_Cml2_Registry_Export_Products::i();
		}
		return $this->_products;
	}
	/** @var Df_1C_Model_Cml2_Registry_Export_Products */
	private $_products;	

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Registry_Export
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_1C_Model_Cml2_Registry_Export
	 */
	public static function s() {
		return Mage::getSingleton(self::mf());
	}
}