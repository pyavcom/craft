<?php
class Df_1C_Model_Cml2_Import_Data_Entity_Offer extends Df_1C_Model_Cml2_Import_Data_Entity {
	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Offer[]
	 */
	public function getConfigurableChildren() {
		if (!isset($this->_configurableChildren)) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer[] $result */
			$result = array();
			if (!$this->isTypeConfigurableChild()) {
				foreach ($this->getRegistryOffers() as $offer) {
					/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer */
					df_assert($offer instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
					if ($offer->isTypeConfigurableChild()) {
						if (
								$this->getExternalId()
							===
								$offer->getExternalIdForConfigurableParent()
						) {
							$result[]= $offer;
						}
					}
				}
			}
			df_result_array($result);
			$this->_configurableChildren = $result;
		}
		return $this->_configurableChildren;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer[] */
	private $_configurableChildren;

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Offer
	 */
	public function getConfigurableParent() {
		/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $result */
		$result =
			!$this->isTypeConfigurableChild()
			? null
			: $this->getRegistryOffers()->findByExternalId(
				$this->getExternalIdForConfigurableParent()
			)
		;
		df_assert($result instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
		return $result;
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Product
	 */
	public function getEntityProduct() {
		/** @var Df_1C_Model_Cml2_Import_Data_Entity_Product $result */
		$result =
			$this->getRegistryProductEntities()->findByExternalId(
				$this->getExternalIdForConfigurableParent()
			)
		;
		df_assert($result instanceof Df_1C_Model_Cml2_Import_Data_Entity_Product);
		return $result;
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_OptionValues
	 */
	public function getOptionValues() {
		if (!isset($this->_optionValues)) {
			$this->_optionValues =
				Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_OptionValues::i($this->e())
			;
		}
		return $this->_optionValues;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_OptionValues */
	private $_optionValues;

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices
	 */
	public function getPrices() {
		if (!isset($this->_prices)) {
			$this->_prices =
				Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices::i(
					array(
						Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices::PARAM__SIMPLE_XML => $this->e()
						,Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices::PARAM__OFFER => $this
					)
				)
			;
		}
		return $this->_prices;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices */
	private $_prices;

	/**
	 * @return Mage_Catalog_Model_Product
	 */
	public function getProduct() {
		/** @var Mage_Catalog_Model_Product|null $result */
		$result =
			df()->registry()->products()->findByExternalId(
				$this->getExternalId()
			)
		;
		if (is_null($result)) {
			df_error(
				'Товар не найден в реестре: «%s»'
				,$this->getExternalId()
			);
		}
		df_assert($result instanceof Mage_Catalog_Model_Product);
		return $result;
	}

	/**
	 * @return int
	 */
	public function getQuantity() {
		return intval(floatval($this->getEntityParam('Количество')));
	}

	/**
	 * @return bool
	 */
	public function isTypeConfigurableChild() {
		return(1 < count($this->getExternalIdExploded()));
	}

	/**
	 * @return bool
	 */
	public function isTypeConfigurableParent() {
		return(0 < count($this->getConfigurableChildren()));
	}

	/**
	 * @return bool
	 */
	public function isTypeSimple() {
		/** @var bool $result */
		$result =
			!(
					$this->isTypeConfigurableChild()
				||
					$this->isTypeConfigurableParent()
			)
		;
		return $result;
	}

	/**
	 * @return string[]
	 */
	private function getExternalIdExploded() {
		return explode('#', parent::getExternalId());
	}

	/**
	 * @return string
	 */
	private function getExternalIdForConfigurableParent() {
		/** @var string $result */
		$result = df_array_first($this->getExternalIdExploded());
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Offers
	 */
	private function getRegistryOffers() {
		return $this->getRegistry()->import()->collections()->getOffers();
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Products
	 */
	private function getRegistryProductEntities() {
		return $this->getRegistry()->import()->collections()->getProducts();
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}