<?php
class Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_Image
	extends Df_1C_Model_Cml2_Import_Data_Entity {
	/**
	 * @override
	 * @return string
	 */
	public function getExternalId() {
		/** @var string $result */
		$result = $this->getFilePathRelative();
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getFilePathFull() {
		/** @var string $filePathRelative */
		$filePathRelative = $this->getFilePathRelative();
		if (df_empty($filePathRelative)) {
			df_error(
				'1C почему-то передала в интернет-магазин пустой путь к файлу товарного изображения.'
			);
		}
		/** @var string $filePathFull */
		$filePathFull =
			$this->getRegistry()->import()->files('catalog')->getFullPathByRelativePath(
				$this->getFilePathRelative()
			)
		;
		df_assert_string_not_empty($filePathFull);
		/** @var string $result */
		$result = str_replace(DS, '/', $filePathFull);
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * Обратите внимание, что результат метода может быть пустой строкой.
	 * В частности, такое замечено в магазине belle.com.ua:
	 * там 1С передаёт интернет-магазину пустой тег <Картинка/>.
	 * @return string
	 */
	public function getFilePathRelative() {
		return (string)($this->e());
	}

	/**
	 * @override
	 * @return string
	 */
	public function getName() {
		/** @var string $result */
		$result = $this->e()->getAttribute('Описание');
		df_result_string($result);
		return $result;
	}

	/**
	 * От разультата этого метода зависит добавление данного объекта
	 * в коллекцию Df_Core_Model_SimpleXml_Parser_Collection
	 * @ovverride
	 * @see Df_Core_Model_SimpleXml_Parser_Collection::getItems()
	 * @return bool
	 */
	public function isValid() {
		return parent::isValid() && !df_empty($this->getFilePathRelative());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}