<?php
class Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices
	extends Df_1C_Model_Cml2_Import_Data_Collection {
	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_Price|null
	 */
	public function getMain() {
		/** @var Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_Price|null $result */
		$result =
			$this->findByExternalId(
				$this->getRegistry()->getPriceTypes()->getMain()->getExternalId()
			)
		;
		if (!is_null($result)) {
			df_assert($result instanceof Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_Price);
		}
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_OfferPart_Price::mf();
	}

	/**
	 * @override
	 * @return string[]
	 */
	protected function getItemsXmlPathAsArray() {
		return array('Цены', 'Цена');
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Offer
	 */
	private function getOffer() {
		return $this->cfg(self::PARAM__OFFER);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(
				self::PARAM__OFFER, Df_1C_Model_Cml2_Import_Data_Entity_Offer::_CLASS
			)
		;
	}

	const _CLASS = __CLASS__;
	const PARAM__OFFER = 'offer';

	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_OfferPart_Prices
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}