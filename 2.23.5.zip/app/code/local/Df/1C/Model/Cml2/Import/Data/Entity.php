<?php
abstract class Df_1C_Model_Cml2_Import_Data_Entity extends Df_Core_Model_SimpleXml_Parser_Entity {
	/**
	 * @return string
	 */
	public function getExternalId() {
		/** @var string $result */
		$result = $this->getEntityParam('Ид');
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	public function getId() {
		/**
		 * Обратите внимание, что именно getId должен вызывать getExternalId,
		 * а не наоборот, потому что раньше у нас был только метод getExternalId,
		 * и потомки данного класса перекрывают именно метод getExternalId
		 */
		return $this->getExternalId();
	}

	/**
	 * @override
	 * @return string
	 */
	public function getName() {
		/** @var string $result */
		$result = $this->getEntityParam('Наименование');
		df_result_string($result);
		return $result;
	}

	/**
	 * Данный метод никак не связан данным с классом,
	 * однако включён в класс для удобного доступа объектов класса к реестру
	 * (чтобы писать $this->getRegistry() вместо df_helper()->_1c()->cml2()->registry())
	 * @return Df_1C_Helper_Cml2_Registry
	 */
	protected function getRegistry() {
		return df_helper()->_1c()->cml2()->registry();
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}