<?php
class Df_1C_Model_Cml2_Registry_Import extends Df_Core_Model_Abstract {
	/**
	 * @return Df_1C_Model_Cml2_Registry_Import_Collections
	 */
	public function collections() {
		/** @var Df_1C_Model_Cml2_Registry_Import_Collections $result */
		static $result;
		if (!isset($result)) {
			/** @var Df_1C_Model_Cml2_Registry_Import_Collections $result */
			$result = Df_1C_Model_Cml2_Registry_Import_Collections::i();
		}
		return $result;
	}

	/**
	 * @param string $area
	 * @return Df_1C_Model_Cml2_Registry_Import_Files
	 */
	public function files($area) {
		df_param_string($area, 0);
		if (!isset($this->_files[$area])) {
			$this->_files[$area] =
				Df_1C_Model_Cml2_Registry_Import_Files::i(
					array(
						Df_1C_Model_Cml2_Registry_Import_Files::PARAM__AREA => $area
					)
				)
			;
		}
		return $this->_files[$area];
	}
	/** @var Df_1C_Model_Cml2_Registry_Import_Files[] */
	private $_files = array();

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function getRootCategory() {
		if (!isset($this->_rootCategory)) {
			$this->_rootCategory = Df_Catalog_Model_Category::ld($this->getRootCategoryId());
		}
		return $this->_rootCategory;
	}
	/** @var Df_Catalog_Model_Category */
	private $_rootCategory;

	/**
	 * @return int
	 */
	private function getRootCategoryId() {
		if (!isset($this->_rootCategoryId)) {
			/** @var int $result */
			$result = intval(df()->state()->getStoreProcessed()->getRootCategoryId());
			if (0 === $result) {
				df_error('В обрабатываемом магазине должен присутствовать корневой товарный раздел');
			}
			$this->_rootCategoryId = $result;
		}
		return $this->_rootCategoryId;
	}
	/** @var int */
	private $_rootCategoryId;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Registry_Import
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_1C_Model_Cml2_Registry_Import
	 */
	public static function s() {
		return Mage::getSingleton(self::mf());
	}
}