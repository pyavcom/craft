<?php
class Df_1C_Model_Cml2_Import_Processor_Product_Part_Images
	extends Df_1C_Model_Cml2_Import_Processor_Product {
	/**
	 * @override
	 * @return Df_1C_Model_Cml2_Import_Processor
	 */
	public function process() {
		if (is_null($this->getExistingMagentoProduct())) {
			df_error(
				'Попытка импорта картинок для отсутствующего в системе товара «%s»'
				,$this->getEntityOffer()->getExternalId()
			);
		}
		df_assert(!is_null($this->getExistingMagentoProduct()));
		Df_Dataflow_Model_Importer_Product_Images::i(
			$this->getExistingMagentoProduct()
			, $this->getEntityProduct()->getImagesPaths()
			, df_helper()->_1c()
		)->process();
		return $this;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer
	 * @return Df_1C_Model_Cml2_Import_Processor_Product_Part_Images
	 */
	public static function i(Df_1C_Model_Cml2_Import_Data_Entity_Offer $offer) {
		return df_model(self::mf(), array(self::PARAM__ENTITY => $offer));
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}