<?php
abstract class Df_1C_Model_Cml2_Import_Processor extends Df_1C_Model_Cml2 {
	/**
	 * @abstract
	 * @return Df_1C_Model_Cml2_Import_Processor
	 */
	abstract public function process();

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity
	 */
	protected function getEntity() {
		return $this->cfg(self::PARAM__ENTITY);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(
				self::PARAM__ENTITY, Df_1C_Model_Cml2_Import_Data_Entity::_CLASS
			)
		;
	}

	const PARAM__ENTITY = 'entity';
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}