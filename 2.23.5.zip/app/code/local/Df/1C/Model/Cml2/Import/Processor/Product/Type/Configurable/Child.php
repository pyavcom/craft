<?php
class Df_1C_Model_Cml2_Import_Processor_Product_Type_Configurable_Child
	extends Df_1C_Model_Cml2_Import_Processor_Product_Type_Simple_Abstract {
	/**
	 * @override
	 * @return Df_1C_Model_Cml2_Import_Processor
	 */
	public function process() {
		if ($this->getEntityOffer()->isTypeConfigurableChild()) {
			$this->getImporter()->import();
			df_helper()->_1c()
				->log(
					sprintf(
						'%s товар «%s».'
						,!is_null($this->getExistingMagentoProduct()) ? 'Обновлён' : 'Создан'
						,$this->getImporter()->getProduct()->getName()
					)
				)
			;
			df()->registry()->products()
				->addEntity(
					$this->getImporter()->getProduct()
				)
			;
		}
		return $this;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getSku() {
		if (!isset($this->_sku)) {
			$this->_sku =
				!is_null($this->getExistingMagentoProduct())
				? $this->getExistingMagentoProduct()->getSku()
				: $this->getEntityOffer()->getExternalId()
			;
			df_result_string_not_empty($this->_sku);
		}
		return $this->_sku;
	}
	/** @var string */
	private $_sku;

	/**
	 * @override
	 * @return int
	 */
	protected function getVisibility() {
		return Mage_Catalog_Model_Product_Visibility::VISIBILITY_NOT_VISIBLE;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Import_Processor_Product_Type_Configurable_Child
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}