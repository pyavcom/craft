<?php
class Df_Admin_Model_Settings_Admin_Editor extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function fixHeadersAlreadySent() {
		return $this->getYesNo('df_tweaks_admin/editor/fix_headers_already_sent');
	}
	/**
	 * @return boolean
	 */
	public function fixImages() {
		return $this->getYesNo('df_tweaks_admin/editor/fix_images');
	}
	/**
	 * @return boolean
	 */
	public function useRm() {
		return $this->getYesNo('df_tweaks_admin/editor/use_rm');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}