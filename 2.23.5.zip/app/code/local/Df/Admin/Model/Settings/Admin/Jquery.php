<?php
class Df_Admin_Model_Settings_Admin_Jquery extends Df_Core_Model_Settings_Jquery {
	/**
	 * @override
	 * @return string
	 */
	public function getLoadMode() {
		return $this->getString('df_tweaks_admin/other/jquery_load_mode');
	}
	/**
	 * @override
	 * @return boolean
	 */
	public function needRemoveExtraneous() {
		return $this->getYesNo('df_tweaks_admin/other/jquery_remove_extraneous');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}