<?php
class Df_Admin_Model_Settings_Base extends Df_Core_Model_Settings {
	/**
	 * @param mixed $store[optional]
	 * @return string
	 */
	public function getStorePhone($store = null) {
		return $this->getStringNullable(Mage_Core_Model_Store::XML_PATH_STORE_STORE_PHONE, $store);
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}