<?php
class Df_Admin_Model_Settings_Admin_Interface extends Df_Core_Model_Settings {
	/**
	 * @return Df_Admin_Model_Config_Extractor_Font
	 */
	public function getButtonLabelFont() {
		if (!isset($this->_buttonLabelFont)) {
			$this->_buttonLabelFont =
				Df_Admin_Model_Config_Extractor_Font::i(
					array(
						Df_Admin_Model_Config_Extractor_Font::PARAM__CONFIG_GROUP_PATH =>
							self::CONFIG_GROUP_PATH
						,Df_Admin_Model_Config_Extractor_Font::PARAM__CONFIG_KEY_PREFIX =>
							self::CONFIG_KEY_PREFIX__BUTTON_LABEL
					)
				)
			;
		}
		return $this->_buttonLabelFont;
	}
	/** @var Df_Admin_Model_Config_Extractor_Font */
	private $_buttonLabelFont;

	/**
	 * @return Df_Admin_Model_Config_Extractor_Font
	 */
	public function getGridLabelFont() {
		if (!isset($this->_gridLabelFont)) {
			$this->_gridLabelFont =
				Df_Admin_Model_Config_Extractor_Font::i(
					array(
						Df_Admin_Model_Config_Extractor_Font::PARAM__CONFIG_GROUP_PATH =>
							self::CONFIG_GROUP_PATH
						,Df_Admin_Model_Config_Extractor_Font::PARAM__CONFIG_KEY_PREFIX =>
							self::CONFIG_KEY_PREFIX__GRID_LABEL
					)
				)
			;
		}
		return $this->_gridLabelFont;
	}
	/** @var Df_Admin_Model_Config_Extractor_Font */
	private $_gridLabelFont;	

	/**
	 * @return Df_Admin_Model_Config_Extractor_Font
	 */
	public function getFormLabelFont() {
		if (!isset($this->_formLabelFont)) {
			$this->_formLabelFont =
				Df_Admin_Model_Config_Extractor_Font::i(
					array(
						Df_Admin_Model_Config_Extractor_Font::PARAM__CONFIG_GROUP_PATH =>
							self::CONFIG_GROUP_PATH
						,Df_Admin_Model_Config_Extractor_Font::PARAM__CONFIG_KEY_PREFIX =>
							self::CONFIG_KEY_PREFIX__FORM_LABEL
					)
				)
			;
		}
		return $this->_formLabelFont;
	}
	/** @var Df_Admin_Model_Config_Extractor_Font */
	private $_formLabelFont;	

	const _CLASS = __CLASS__;
	const CONFIG_GROUP_PATH = 'df_tweaks_admin/interface';
	const CONFIG_KEY_PREFIX__FORM_LABEL = 'form_label';
	const CONFIG_KEY_PREFIX__GRID_LABEL = 'grid_label';
	const CONFIG_KEY_PREFIX__BUTTON_LABEL = 'button_label';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}