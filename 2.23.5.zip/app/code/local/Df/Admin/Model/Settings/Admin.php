<?php
class Df_Admin_Model_Settings_Admin extends Df_Core_Model_Settings {
	/**
	 * @return Df_Admin_Model_Settings_Admin_Interface
	 */
	public function _interface() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Interface::mf());
	}
	/**
	 * @return Df_AccessControl_Model_Settings
	 */
	public function access_control() {
		return Mage::getSingleton(Df_AccessControl_Model_Settings::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_Catalog
	 */
	public function catalog() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Catalog::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_Editor
	 */
	public function editor() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Editor::mf());
	}
	/**
	 * @return Df_Logging_Model_Settings
	 */
	public function logging() {
		return Mage::getSingleton(Df_Logging_Model_Settings::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_Optimization
	 */
	public function optimization() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Optimization::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_Jquery
	 */
	public function jquery() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Jquery::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_Promotions
	 */
	public function promotions() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Promotions::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_Sales
	 */
	public function sales() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_Sales::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_System
	 */
	public function system() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_System::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}