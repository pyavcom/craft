<?php
class Df_Admin_Model_Settings_Admin_System extends Df_Core_Model_Settings {
	/**
	 * @return Df_Admin_Model_Settings_Admin_System_Configuration
	 */
	public function configuration() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_System_Configuration::mf());
	}
	/**
	 * @return Df_AdminNotification_Model_Settings
	 */
	public function notifications() {
		return Mage::getSingleton(Df_AdminNotification_Model_Settings::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin_System_Tools
	 */
	public function tools() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_System_Tools::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}