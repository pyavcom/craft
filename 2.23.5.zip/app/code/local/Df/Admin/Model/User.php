<?php
class Df_Admin_Model_User extends Mage_Admin_Model_User {
	/**
	 * @override
	 * @return Df_Admin_Model_Resource_User
	 */
	public function getResource() {
		return parent::getResource();
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->_init(Df_Admin_Model_Resource_User::mf());
	}

	const _CLASS = __CLASS__;
	const PARAM__EMAIL = 'email';
	const PARAM__FIRSTNAME = 'firstname';
	const PARAM__IS_ACTIVE = 'is_active';
	const PARAM__LASTNAME = 'lastname';
	const PARAM__NEW_PASSWORD = 'new_password';
	const PARAM__PASSWORD_CONFIRMATION = 'password_confirmation';
	const PARAM__ROLE_ID = 'role_id';
	const PARAM__USERNAME = 'username';
	/**
	 * @static
	 * @return Df_Admin_Model_Resource_User_Collection
	 */
	public static function c() {
		return Mage::getSingleton(self::mf())->getCollection();
	}
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Admin_Model_User
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @param int|string $id
	 * @param string|null $field [optional]
	 * @return Df_Admin_Model_User
	 */
	public static function ld($id, $field = null) {
		return df_load(self::i(), $id, $field);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}