<?php
/**
 * @singleton
 * Система создаёт объект-одиночку для потомков этого класса.
 * Не забывайте об этом при реализации кеширования результатов вычислений внутри этого класса!
 */
class Df_Admin_Model_Config_Source_Units_Weight extends Df_Admin_Model_Config_Source {
	/**
	 * @override
	 * @param bool $isMultiSelect
	 * @return array(array(string => string))
	 */
	protected function toOptionArrayInternal($isMultiSelect = false) {
		return $this->getAsOptionArray();
	}

	/**
	 * @return string[][]
	 */
	private function getAsOptionArray() {
		/**
		 * Здесь кэшировать результат можно,
		 * потому что у класса нет параметров.
		 */
		if (!isset($this->_asOptionArray)) {
			/** @var string[][] $result */
			$result = array();
			foreach (df()->units()->weight()->getAll() as $unitId => $unitData) {
				/** @var mixed[] $unit */
				df_assert_array($unitData);
				$result[]=
					array(
						self::OPTION_KEY__LABEL =>
							df_a($unitData, Df_Core_Model_Units_Weight::UNIT__LABEL)
						,self::OPTION_KEY__VALUE => $unitId
					)
				;
			}
			$this->_asOptionArray = $result;
		}
		return $this->_asOptionArray;
	}
	/** @var string[][] */
	private $_asOptionArray;
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_Admin_Model_Config_Source_Units_Weight
	 */
	public static function s() {
		return Mage::getSingleton(self::mf());
	}
}