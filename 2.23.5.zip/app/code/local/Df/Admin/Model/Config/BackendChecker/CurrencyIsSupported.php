<?php
class Df_Admin_Model_Config_BackendChecker_CurrencyIsSupported
	extends Df_Admin_Model_Config_BackendChecker {
	/**
	 * @param Mage_Core_Model_Store $store
	 * @return bool
	 */
	public function checkCurrencyIsSupportedByStore(Mage_Core_Model_Store $store) {
		/** @var bool $result */
		$result =
				in_array($this->getCurrencyCode(), $store->getAvailableCurrencyCodes())
			&&
				(false !== $store->getBaseCurrency()->getRate($this->getCurrencyCode()))
		;
		return $result;
	}

	/**
	 * @override
	 * @return Df_Admin_Model_Config_BackendChecker
	 */
	protected function checkInternal() {
		if (0 < count($this->getFailedStores())) {
			df_error(
				strtr(
					'1) Убедитесь, что валюта «%selectedCurrency%» включена для магазинов: %stores%.<br/>'
					.'2) Укажите курс обмена учётной валюты магазина на валюту «%selectedCurrency%».'
					,array(
						'%selectedCurrency%' => $this->getCurrencyZend()->getName()
						,'%stores%' =>
							implode(
								', '
								,array_map(
									'df_quote_russian'
									,$this->getFailedStores()->getColumnValues('name')
								)
							)
					)
				)
			);
		}
		return $this;
	}

	/**
	 * @return Mage_Directory_Model_Currency
	 */
	private function getCurrency() {
		if (!isset($this->_currency)) {
			$this->_currency = Df_Directory_Model_Currency::ld($this->getCurrencyCode());
		}
		return $this->_currency;
	}
	/** @var Mage_Directory_Model_Currency */
	private $_currency;	


	/**
	 * @return string
	 */
	private function getCurrencyCode() {
		return $this->cfg(self::PARAM__CURRENCY_CODE);
	}

	/**
	 * @return Zend_Currency
	 */
	private function getCurrencyZend() {
		if (!isset($this->_currencyZend)) {
			/** @var Zend_Currency $result */
			$this->_currencyZend = df_zf_currency($this->getCurrencyCode());
		}
		return $this->_currencyZend;
	}
	/** @var Zend_Currency */
	private $_currencyZend;

	/**
	 * @return int[]
	 */
	private function getFailedStoreIds() {
		if (!isset($this->_failedStoreIds)) {
			/** @var int[] $result */
			$this->_failedStoreIds =
				array_diff(
					array_keys(
						$this->getSupportMatrix()
					)
					,array_keys(
						array_filter(
							$this->getSupportMatrix()
						)
					)
				)
			;
		}
		return $this->_failedStoreIds;
	}
	/** @var int[] */
	private $_failedStoreIds;

	/**
	 * @return Mage_Core_Model_Resource_Store_Collection|Mage_Core_Model_Mysql4_Store_Collection
	 */
	private function getFailedStores() {
		if (!isset($this->_failedStores)) {
			/** @var Mage_Core_Model_Resource_Store_Collection|Mage_Core_Model_Mysql4_Store_Collection $result */
			$result =
				Mage::app()->getStore()->getResourceCollection()
			;
			df()->assert()->storeCollection($result);
			$result->addIdFilter($this->getFailedStoreIds());
			$this->_failedStores = $result;
		}


		df()->assert()->storeCollection($this->_failedStores);
		return $this->_failedStores;
	}
	/** @var Mage_Core_Model_Resource_Store_Collection|Mage_Core_Model_Mysql4_Store_Collection */
	private $_failedStores;

	/**
	 * @return bool[]
	 */
	private function getSupportMatrix() {
		if (!isset($this->_supportMatrix)) {
			/** @var bool[] $result */
			$this->_supportMatrix =
				$this->getBackend()->getStores()->walk(
					array($this, 'checkCurrencyIsSupportedByStore')
				)			
			;
		}
		return $this->_supportMatrix;
	}
	/** @var bool[] */
	private $_supportMatrix;	


	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->addValidator(
				self::PARAM__CURRENCY_CODE, new Df_Zf_Validate_String()
			)
		;
	}

	const _CLASS = __CLASS__;
	const PARAM__CURRENCY_CODE = 'currencyCode';

	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Admin_Model_Config_BackendChecker_CurrencyIsSupported
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}

	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}