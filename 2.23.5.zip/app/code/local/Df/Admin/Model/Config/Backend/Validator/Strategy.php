<?php
abstract class Df_Admin_Model_Config_Backend_Validator_Strategy extends Df_Core_Model_Abstract {
	/**
	 * @abstract
	 * @return bool
	 */
	abstract public function validate();

	/**
	 * @return Df_Admin_Model_Config_Backend_Validator
	 */
	protected function getBackend() {
		return $this->cfg(self::PARAM__BACKEND);
	}

	/**
	 * @return Mage_Core_Model_Store
	 */
	protected function getStore() {
		return $this->cfg(self::PARAM__STORE);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(
				self::PARAM__BACKEND, Df_Admin_Model_Config_Backend::_CLASS
			)
			->validateClass(
				self::PARAM__STORE, Df_Core_Const::STORE_CLASS
			)
		;
	}

	const PARAM__BACKEND = 'backend';
	const PARAM__STORE = 'store';
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

}