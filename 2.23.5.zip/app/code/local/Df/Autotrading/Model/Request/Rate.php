<?php
class Df_Autotrading_Model_Request_Rate extends Df_Shipping_Model_Request {
	/**
	 * @return float
	 */
	public function getRate() {
		if (!isset($this->_rate)) {
			$this->responseFailureDetect();
			/** @var phpQueryObject $pqResultCell */
			$pqResultCell = df_pq('.calculator .calc_result ul li.inner .col2', $this->getResponseAsPq());
			df_assert($pqResultCell instanceof phpQueryObject);
			/** @var string $resultAsText */
			$resultAsText = df_trim($pqResultCell->text());
			df_assert_string($resultAsText);
			/** @var string|null $costFormatted */
			$costFormatted = rm_preg_match('#([\d\s,]+)#u', $resultAsText, $needThrow = false);
			if (is_null($costFormatted)) {
				df_error('Невозможно рассчитать стоимость доставки при данных условиях');
			}
			/**
			 * Обратите внимание,
			 * что $costFormatted теперь содержит строку вида «6 657,4»,
			 * причём пробел между цифрами — необычный, там символ Unicode.
			 * Чтобы его устранить, используем preg_replace
			 */
			/** @var string $costFormattedRegularly */
			$costFormattedRegularly =
				strtr(
					preg_replace('#\s#u', '', $costFormatted)
					,array(
						',' => '.'
						,' ' => ''
					)
				)
			;
			df_assert_string($costFormattedRegularly);
			/** @var float $result */
			$result = floatval($costFormattedRegularly);
			/**
			 * Обратите внимание, что раз мы везде используем ===  вместо ==,
			 * то правильно писать именно 0.0, а не 0, иначе сравнение будет работать неверно.
			 */
			if (0.0 === $result) {
				df_notify_me(
					sprintf(
						'Автотрейдинг: при расчёте тарифа получили 0.'
						."\nПараметры запроса:\n%s"
						."\nОтвет сервера:\n\n%s"
						,print_r(
							$this->getPostParameters()
							,$return = true
						)
						,$this->getResponseAsText()
					)
				);
			}
			$this->_rate = $result;
		}
		return $this->_rate;
	}
	/** @var float */
	private $_rate;

	/**
	 * @override
	 * @return array(string => string)
	 */
	protected function getHeaders() {
		return
			array_merge(
				parent::getHeaders()
				,array(
					'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
					,'Accept-Encoding' => 'gzip, deflate'
					,'Accept-Language' => 'en-us,en;q=0.5'
					,'Connection' => 'keep-alive'
					,'Host' => 'www.ae5000.ru'
					,'Referer' => 'http://www.ae5000.ru/rates/calculate/'
					,'User-Agent' => Df_Core_Const::FAKE_USER_AGENT
				)
			)
		;
	}

	/**
	 * @return array
	 */
	protected function getPostParameters() {
		/** @var array $result */
		$result =
			array_merge(
				parent::getPostParameters()
				,array(
					/**
					 * Всегда 1
					 */
					self::POST__TARGET => '1'

					/**
					 * Тип доставки.
					 *
					 * ch1 — стандартная
					 * ch2 — экспресс (пока не поддерживается калькулятором)
					 */
					,self::POST__DELIVERY_TYPE => 'ch1'

					/**
					 * Нужен ли детальный расчёт?
					 * В нашем случае значением будет всегда "on"
					 */
					,self::POST__ADVANCED_CALCULATION => '1'

					/**
					 * Дата отправки груза
					 */
					,self::POST__SEND_DATE =>
						Zend_Date::now()->toString(
							Df_Core_Model_Format_Date::FORMAT__RUSSIAN
						)
				)
			)
		;
		df_result_array($result);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getQueryHost() {
		return 'www.ae5000.ru';
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getQueryPath() {
		return '/rates/calculate/';
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getRequestMethod() {
		return Zend_Http_Client::POST;
	}

	/**
	 * @override
	 * @return Df_Shipping_Model_Request
	 */
	protected function responseFailureDetectInternal() {
		/** @var phpQueryObject $pqErrors */
		$pqErrors =
			df_pq(
				'.calculator .error_message ul li'
				,$this->getResponseAsPq()
			)
		;
		df_assert($pqErrors instanceof phpQueryObject);
		if (0 < count($pqErrors)) {
			/** @var string[] $errors */
			$errors = array();
			foreach ($pqErrors as $nodeError) {
				/** @var DOMNode $nodeError */
				df_assert($nodeError instanceof DOMNode);
				$errors[]= df_pq($nodeError)->text();
			}
			$this->responseFailureHandle(implode("\n", $errors));
		}
		return $this;
	}
	const _CLASS = __CLASS__;
	const POST__CHECK_CARGO_ON_RECEIPT = 'assort';
	const POST__DECLARED_VALUE__FOR_CHECKING_CARGO_ON_RECEIPT = 'cargo_cost';
	const POST__NEED_INSURANCE = 'insurance';
	const POST__DECLARED_VALUE__FOR_INSURANCE = 'insurance_cargo_cost';
	const POST__CAN_CARGO_BE_PUT_ON_A_SIDE = 'CalculateForm[manipulate]';
	const POST__MAKE_ACCOMPANYING_FORMS = 'docs';
	const POST__NOTIFY_SENDER_ABOUT_DELIVERY = 'mailuved';
	const POST__NEED_COLLAPSIBLE_PALLET_BOX = 'evrobort';
	const POST__NEED_TAPING = 'scotc';
	const POST__NEED_TAPING_ADVANCED = 'firmscotc';
	const POST__NEED_BOX = 'box';
	const POST__BOX_PLACES = 'box_places';
	const POST__NEED_PALLET_PACKING = 'pallet';
	const POST__PALLET_PLACES = 'pallet_places';
	const POST__PALLET_VOLUME = 'pallet_volume';
	const POST__NEED_BAG_PACKING = 'meshok';
	const POST__BAG_PLACES = 'meshok_places';
	const POST__NEED_OPEN_SLAT_CRATE = 'obreshotka';
	const POST__NEED_PLYWOOD_BOX = 'faneryashik';
	const POST__NEED_CARGO_TAIL_LOADER = 'gidrobort';
	const POST__SEND_DATE = 'CalculateForm[send_date]';
	const POST__TARGET = 'target';
	const POST__DELIVERY_TYPE = 'delivery';
	const POST__ADVANCED_CALCULATION = 'CalculateForm[extended]';
	const POST__LOCATION__SOURCE = 'CalculateForm[from]';
	const POST__LOCATION__SOURCE__BRANCH = 'CalculateForm[from_filial]';
	const POST__LOCATION__SOURCE__DETAILS = 'CalculateForm[from_delivery]';
	const POST__LOCATION__DESTINATION = 'CalculateForm[to]';
	const POST__LOCATION__DESTINATION__BRANCH = 'CalculateForm[to_filial]';
	const POST__LOCATION__DESTINATION__DETAILS = 'CalculateForm[to_delivery]';
	const POST__HEIGHT = 'height';
	const POST__LENGTH = 'length';
	const POST__WIDTH = 'width';
	const POST__WEIGHT = 'weight';
	const POST__QUANTITY = 'quantity';

	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Autotrading_Model_Request_Rate
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), array(self::PARAM__POST_PARAMS => $parameters));
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}