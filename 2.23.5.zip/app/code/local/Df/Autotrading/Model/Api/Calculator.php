<?php
class Df_Autotrading_Model_Api_Calculator extends Df_Core_Model_Abstract {
	/**
	 * @param string $paramName
	 * @param int $productIndex
	 * @return string
	 */
	public function addProductIndexToParameter($paramName, $productIndex) {
		return implode('_', array($paramName, $productIndex));
	}

	/**
	 * @return float
	 */
	public function getRate() {
		return $this->getApiRequest()->getRate();
	}

	/**
	 * @param string $locationName
	 * @return Df_Autotrading_Model_Api_Calculator
	 * @throws Exception
	 */
	private function assertDestinationIsAllowed($locationName) {
		if (!(Df_Autotrading_Model_Request_Locations::s()->isLocationAllowed($locationName))) {
			$this->getRequest()->throwExceptionInvalidDestination();
		}
		return $this;
	}

	/**
	 * @return Df_Autotrading_Model_Request_Rate
	 */
	private function getApiRequest() {
		if (!isset($this->_apiRequest)) {
			$this->_apiRequest = Df_Autotrading_Model_Request_Rate::i($this->getRequestParameters());
		}
		return $this->_apiRequest;
	}
	/** @var Df_Autotrading_Model_Request_Rate */
	private $_apiRequest;
	
	/**
	 * @return string
	 */
	private function getDestinationRegionalCenter() {
		if (!isset($this->_destinationRegionalCenter)) {
			$this->_destinationRegionalCenter =
				$this->getRequest()->isDestinationRussia()
				? $this->getRequest()->getDestinationRegionalCenter()
				: $this->getRegionalCenterForForeighCountries(
					$this->getRequest()->getDestinationCity()
					,true
				)
			;
			df_result_string($this->_destinationRegionalCenter);
		}
		return $this->_destinationRegionalCenter;
	}
	/** @var string */
	private $_destinationRegionalCenter;

	/**
	 * @return string
	 */
	private function getLocationDestinationInApiFormat() {
		if (!isset($this->_locationDestinationInApiFormat)) {
			/** @var string $result */
			$result = null;
			/**
			 * Поведение системы было логически неверным:
			 * если администратор указывал «нет» в качестве значения настройки
			 * «Должна ли служба доставки доставлять товар до дома покупателя?»,
			 * то система молча рассчитывала доставку до регионального центра,
			 * даже не предупреждая об этом покупателя.
			 * Таким образом, если покупатель ввёл адрес:
			 * город Мухоморск (несуществующий) Вологодская область,
			 * то система как ни в чём не бывало рассчитывала доставку до Вологды,
			 * не предупреждая покупателя о том, что доставки в Мухоморск нет.
			 */
			//			if (!$this->getServiceConfig()->needDeliverCargoToTheBuyerHome()) {
			//				$this->assertDestinationIsAllowed($this->getDestinationRegionalCenter());
			//				$result = $this->normalizeLocationName($this->getDestinationRegionalCenter());
			//			}
			//			else {
			if ($this->isDestinationCityRegionalCenter()) {
					/**
					 * Обратите внимание, что правильный код — именно
					 * $this->assertDestinationIsAllowed($this->getRequest()->getDestinationCity());
					 * а не
					 * $this->assertDestinationIsAllowed($this->getRequest()->getDestinationRegionalCenter());
					 * потому что если покупатель при оформлении заказа укажет областью «Иркутская область»,
					 * а городом — «Петропавловск-Камчатский», то при коде
					 * $this->assertDestinationIsAllowed($this->getRequest()->getDestinationRegionalCenter());
					 * система выдаст неверное диагностическое сообщение:
					 * «Служба Автотрейдинг не доставляет грузы в населённый пункт Иркутск»,
					 * либо же рассчитает тариф до Иркутска, что тоже неверно.
					 */
					$this->assertDestinationIsAllowed($this->getRequest()->getDestinationCity());
					$result =
						sprintf(
							'В пределы города %s'
							,$this->normalizeLocationName($this->getDestinationRegionalCenter())
						)
					;
				}
				else {
					$this->assertDestinationIsAllowed($this->getRequest()->getDestinationCity());
					$result =
						$this->getPeripheralDestinationNameInApiFormat(
							$this->getRequest()->getDestinationCity()
							,$this->getDestinationRegionalCenter()
						)
					;
					if (df_empty($result)) {
						$this->getRequest()->throwExceptionInvalidDestination();
					}
				}
//			}
			df_result_string($result);
			$this->_locationDestinationInApiFormat = $result;
		}
		return $this->_locationDestinationInApiFormat;
	}
	/** @var string */
	private $_locationDestinationInApiFormat;

	/**
	 * @return string
	 */
	private function getLocationOriginInApiFormat() {
		if (!isset($this->_locationOriginInApiFormat)) {
			/** @var string $result */
			$result = 
				!$this->getServiceConfig()->needGetCargoFromTheShopStore()
				? $this->normalizeLocationName($this->getOriginRegionalCenter())
				:
					(
						$this->isOriginCityRegionalCenter()
						? sprintf(
							'В пределах города %s'
							,$this->normalizeLocationName($this->getOriginRegionalCenter())
						)
						:
							$this->getPeripheralDestinationNameInApiFormat(
								$this->getRequest()->getOriginCity()
								,$this->getOriginRegionalCenter()
							)
					)
			;
			df_result_string($result);
			$this->_locationOriginInApiFormat = $result;
		}
		return $this->_locationOriginInApiFormat;
	}
	/** @var string */
	private $_locationOriginInApiFormat;	

	/**
	 * @return string
	 */
	private function getOriginRegionalCenter() {
		if (!isset($this->_originRegionalCenter)) {
			$this->_originRegionalCenter =
				$this->getRequest()->isOriginRussia()
				? $this->getRequest()->getOriginRegionalCenter()
				: $this->getRegionalCenterForForeighCountries(
					$this->getRequest()->getOriginCity()
					,false
				)
			;
			df_result_string($this->_originRegionalCenter);
		}
		return $this->_originRegionalCenter;
	}
	/** @var string */
	private $_originRegionalCenter;

	/**
	 * @param string $locationName
	 * @param string $regionalCenterName
	 * @return string
	 */
	private function getPeripheralDestinationNameInApiFormat($locationName, $regionalCenterName) {
		df_param_string($locationName, 0);
		df_param_string($regionalCenterName, 1);
		/** @var string $result */
		$result =
			df_a(
				df_a(
					Df_Autotrading_Model_Request_Locations::s()->getLocationsGrouped()
					,df_helper()->directory()->normalizeLocationName($regionalCenterName)
					,array()
				)
				,df_helper()->directory()->normalizeLocationName($locationName)
			)
		;
		if (df_empty($result)) {
			$this->getRequest()->throwExceptionInvalidDestination();
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @param string $locationName
	 * @param bool $isDestination
	 * @return string
	 */
	private function getRegionalCenterForForeighCountries($locationName, $isDestination) {
		/** @var string $result */
		$result = null;
		/**
		 * Для других стран, кроме России,
		 * мы не можем использовать метод $this->getRequest()->getDestinationRegionalCenter()
		 */
		/** @var string $locationNameNormalized */
		$locationNameNormalized =
			df_helper()->directory()->normalizeLocationName(
				$locationName
			)
		;
		/** @var array(string => string)|null $locationNameInfo */
		$locationNameInfo =
			Df_Autotrading_Model_Request_Locations::s()->getPeripheralLocationInfo(
				$locationNameNormalized
			)
		;
		if (is_null($locationNameInfo)) {
			if (
				Df_Autotrading_Model_Request_Locations::s()->isLocationAllowed(
					$locationNameNormalized
				)
			) {
				$result = $locationName;
			}
			else {
				if ($isDestination) {
					$this->getRequest()->throwExceptionInvalidDestination();
				}
				else {
					$this->getRequest()->throwExceptionInvalidOrigin();
				}
			}
		}
		else {
			/** @var string $destinationRegionalCenter */
			$result = df_a($locationNameInfo, 'regionalCenter');
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @return Df_Shipping_Model_Rate_Request
	 */
	private function getRequest() {
		return $this->cfg(self::PARAM__REQUEST);
	}

	/**
	 * @return mixed[]
	 */
	private function getRequestParameters() {
		if (!isset($this->_requestParameters)) {
			/** @var mixed[] $result */
			$result = array();
			if ($this->getServiceConfig()->checkCargoOnReceipt()) {
				/**
				 * Должна ли служба доставки вскрывать и сверять груз при покупателе?
				 * service__check_cargo_on_receipt
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__CHECK_CARGO_ON_RECEIPT] =
					Df_Autotrading_Model_Request_Rate::POST__CHECK_CARGO_ON_RECEIPT
				;
			}
			/**
			 * Объявленная ценность в том случае, если
			 * служба доставки должна вскрывать и сверять груз при покупателе?
			 *
			 * admin__declared_value_percent
			 */
			$result[Df_Autotrading_Model_Request_Rate::POST__DECLARED_VALUE__FOR_CHECKING_CARGO_ON_RECEIPT] =
					$this->getServiceConfig()->checkCargoOnReceipt()
				?
					df_helper()->directory()->currency()->convertFromBaseToRoubles(
						$this->getRequest()->getDeclaredValue()
					)

				:
					0
			;
			if ($this->getServiceConfig()->needInsurance()) {
				/**
				 * Должна ли служба доставки вскрывать и сверять груз при покупателе?
				 * service__check_cargo_on_receipt
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_INSURANCE] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_INSURANCE
				;
			}
			/**
			 * Объявленная ценность в том случае, если
			 * служба доставки должна страховать груз
			 *
			 * admin__declared_value_percent
			 */
			$result[Df_Autotrading_Model_Request_Rate::POST__DECLARED_VALUE__FOR_INSURANCE] =
					$this->getServiceConfig()->needInsurance()
				?
					df_helper()->directory()->currency()->convertFromBaseToRoubles(
						$this->getRequest()->getDeclaredValue()
					)
				:
					0
			;
			if ($this->getServiceConfig()->canCargoBePutOnASide()) {
				/**
				 * Можно ли переворачивать груз?
				 *
				 * service__can_cargo_be_put_on_a_side
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__CAN_CARGO_BE_PUT_ON_A_SIDE] =
					'on'
				;
			}
			if ($this->getServiceConfig()->makeAccompanyingForms()) {
				/**
				 * Должна ли служба доставки
				 * составлять сопроводительную документацию на груз?
				 *
				 * Опция доступна только если выбрана доставка до дома покупателя.
				 *
				 * service__make_accompanying_forms
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__MAKE_ACCOMPANYING_FORMS] =
					Df_Autotrading_Model_Request_Rate::POST__MAKE_ACCOMPANYING_FORMS
				;
			}
			if ($this->getServiceConfig()->notifySenderAboutDelivery()) {
				/**
				 * Должна ли служба доставки
				 * уведомлять отправителя в письменном виде
				 * о доставке груза получателю?
				 *
				 * service__notify_sender_about_delivery
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NOTIFY_SENDER_ABOUT_DELIVERY] =
					Df_Autotrading_Model_Request_Rate::POST__NOTIFY_SENDER_ABOUT_DELIVERY
				;
			}
			if ($this->getServiceConfig()->needCollapsiblePalletBox()) {
				/**
				 * Нужен ли для груза поддон с деревянными съёмными ограждениями
				 * (евроборт, паллетный борт)?
				 *
				 * service__need_collapsible_pallet_box
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_COLLAPSIBLE_PALLET_BOX] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_COLLAPSIBLE_PALLET_BOX
				;
			}
			if ($this->getServiceConfig()->needTaping()) {
				/**
				 * Нужна ли услуга перетяжки груза обычной клейкой лентой?
				 *
				 * service__need_taping
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_TAPING] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_TAPING
				;
			}
			if ($this->getServiceConfig()->needTapingAdvanced()) {
				/**
				 * Нужна ли услуга перетяжки груза фирменной клейкой лентой?
				 *
				 * service__need_taping_advanced
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_TAPING_ADVANCED] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_TAPING_ADVANCED
				;
			}
			if ($this->getServiceConfig()->needBox()) {
				/**
				 * Нужна ли коробка?
				 *
				 * service__need_box
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_BOX] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_BOX
				;
				/**
				 * Сколько коробок нужно?
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__BOX_PLACES] = 1;
			}
			if ($this->getServiceConfig()->needPalletPacking()) {
				/**
				 * Нужна ли услуга упаковки груза на поддоне (паллете)?
				 *
				 * service__need_pallet_packing
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_PALLET_PACKING] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_PALLET_PACKING
				;
				/**
				 * Сколько нужно поддонов?
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__PALLET_PLACES] = 1;
				/**
				 * Объём паллетированного груза
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__PALLET_VOLUME] = 1;
			}
			if ($this->getServiceConfig()->needBagPacking()) {
				/**
				 * Нужна ли услуга упаковки груза в мешок?
				 *
				 * service__need_bag_packing
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_BAG_PACKING] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_BAG_PACKING
				;
				/**
				 * Сколько нужно мешков?
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__BAG_PLACES] = 1;
			}
			if ($this->getServiceConfig()->needOpenSlatCrate()) {
				/**
				 * Нужна ли услуга обрешётки?
				 *
				 * service__need_open_slat_crate
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_OPEN_SLAT_CRATE] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_OPEN_SLAT_CRATE
				;
			}
			if ($this->getServiceConfig()->needPlywoodBox()) {
				/**
				 * Нужна ли услуга упаковки груза в фанерный ящик?
				 *
				 * service__need_plywood_box
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_PLYWOOD_BOX] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_PLYWOOD_BOX
				;
			}
			if ($this->getServiceConfig()->needCargoTailLoader()) {
				/**
				 * Нужен ли для погрузки и выгрузки гидравлический подъёмник?
				 *
				 * service__need_cargo_tail_loader
				 */
				$result[Df_Autotrading_Model_Request_Rate::POST__NEED_CARGO_TAIL_LOADER] =
					Df_Autotrading_Model_Request_Rate::POST__NEED_CARGO_TAIL_LOADER
				;
			}
			$result =
				array_merge(
					$result
					,array(
						Df_Autotrading_Model_Request_Rate::POST__LOCATION__SOURCE__BRANCH =>
							$this->normalizeLocationName($this->getOriginRegionalCenter())
						,Df_Autotrading_Model_Request_Rate::POST__LOCATION__SOURCE =>
							$this->getLocationOriginInApiFormat()
						,Df_Autotrading_Model_Request_Rate::POST__LOCATION__SOURCE__DETAILS =>
							$this->getLocationOriginInApiFormat()
						,Df_Autotrading_Model_Request_Rate::POST__LOCATION__DESTINATION__BRANCH =>
							$this->normalizeLocationName($this->getDestinationRegionalCenter())
						,Df_Autotrading_Model_Request_Rate::POST__LOCATION__DESTINATION =>
							$this->getLocationDestinationInApiFormat()
						,Df_Autotrading_Model_Request_Rate::POST__LOCATION__DESTINATION__DETAILS =>
							$this->getLocationDestinationInApiFormat()
					)
				)
			;
			/** @var int $productIndex */
			$productIndex = 0;
			foreach ($this->getRequest()->getQuoteItemsSimple() as $quoteItem) {
				/** @var Mage_Sales_Model_Quote_Item $quoteItem */
				df_assert($quoteItem instanceof Mage_Sales_Model_Quote_Item);
				/** @var Df_Sales_Model_Quote_Item_Extended $quoteItemExtended */
				$quoteItemExtended =
					Df_Sales_Model_Quote_Item_Extended::create(
						$quoteItem
					)
				;
				df_assert($quoteItemExtended instanceof Df_Sales_Model_Quote_Item_Extended);
				/** @var Df_Catalog_Model_Product $product */
				$product =
					$this->getRequest()->getProductsWithDimensions()->getItemById(
						$quoteItem->getProductId()
					)
				;
				df_assert($product instanceof Df_Catalog_Model_Product);

				/** @var array $productDimensionsWithServiceLabels */
				$productDimensionsWithServiceLabels =
					df_array_combine(
						df_map(
							array($this, 'addProductIndexToParameter')
							,array(
								'width'
								,'height'
								,'length'
							)
							,$productIndex
						)
						,array_map(
							array(df()->units()->length(), 'convertToMetres')
							,array(
								$product->getWidth()
								,$product->getHeight()
								,$product->getLength()
							)
						)
					)
				;
				df_assert_array($productDimensionsWithServiceLabels);
				$result =
					array_merge(
						$result
						,$productDimensionsWithServiceLabels
						,array(
							$this->addProductIndexToParameter('weight', $productIndex) =>
								df()->units()->weight()->convertToKilogrammes(
									/**
									 * Здесь нужен вес именно товара, а не строки заказа
									 */
									floatval($product->getWeight())
								)
							,$this->addProductIndexToParameter('quantity', $productIndex) =>
								$quoteItemExtended->getQty()
						)
					)
				;
				$productIndex++;
			}
			$this->_requestParameters = $result;
		}
		return $this->_requestParameters;
	}
	/** @var mixed[] */
	private $_requestParameters;

	/**
	 * @return Df_Shipping_Model_Config_Facade
	 */
	private function getRmConfig() {
		return $this->cfg(self::PARAM__RM_CONFIG);
	}

	/**
	 * @return Df_Autotrading_Model_Config_Area_Service
	 */
	private function getServiceConfig() {
		return $this->getRmConfig()->service();
	}

	/**
	 * @return bool
	 */
	private function isDestinationCityRegionalCenter() {
		return $this->getDestinationRegionalCenter() === $this->getRequest()->getDestinationCity();
	}

	/**
	 * @return bool
	 */
	private function isOriginCityRegionalCenter() {
		return $this->getOriginRegionalCenter() === $this->getRequest()->getOriginCity();
	}

	/**
	 * @param string $locationName
	 * @return string
	 */
	private function normalizeLocationName($locationName) {
		df_assert_string_not_empty($locationName, 0);
		/** @var string $result */
		$result =
					!rm_contains($locationName, '-')
				&&
					!rm_contains($locationName, ' ')
			? df_text()->ucfirst(mb_strtolower($locationName))
			:
				/**
				 * Чтобы не преображало «Санкт-Петербург» в «Санкт-петербург»
				 * (хотя влияние регистра букв на работу калькулятора Автотрейдинга не установлена)
				 */
				$locationName
		;
		return $result;
	}

	/**
	 * @param string $locationName
	 * @return Df_Autotrading_Model_Api_Calculator
	 * @throws Exception
	 */
	private function throwCanNotDeliver($locationName) {
		df_error(
			'Служба Автотрейдинг не доставляет грузы в населённый пункт %s.'
			,$locationName
		);
		return $this;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(self::PARAM__REQUEST, Df_Shipping_Model_Rate_Request::_CLASS)
			->validateClass(self::PARAM__RM_CONFIG, Df_Shipping_Model_Config_Facade::_CLASS)
		;
	}

	const _CLASS = __CLASS__;
	const PARAM__REQUEST = 'request';
	const PARAM__RM_CONFIG = 'rm_config';

	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Autotrading_Model_Api_Calculator
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}