<?php
class Df_Assist_Model_Payment extends Df_Payment_Model_Method_WithRedirect {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}