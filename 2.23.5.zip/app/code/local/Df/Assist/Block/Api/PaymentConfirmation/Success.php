<?php
class Df_Assist_Block_Api_PaymentConfirmation_Success extends Df_Core_Block_Template {
	/**
	 * @return string
	 */
	public function getBillNumber() {
		/** @var string $result */
		$result = self::PARAM__BILL_NUMBER;
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getPacketDate() {
		/** @var string $result */
		$result = self::PARAM__PACKET_DATE;
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	public function getTemplate() {
		return self::RM__TEMPLATE;
	}

	const _CLASS = __CLASS__;
	const PARAM__BILL_NUMBER = 'bill_number';
	const PARAM__PACKET_DATE = 'packet_date';
	const RM__TEMPLATE = 'df/assist/api/payment-confirmation/success.xml';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}