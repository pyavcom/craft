<?php
class Df_Adminhtml_Block_Widget_Grid_Column_RendererDf extends Df_Core_Block_Template {
	/**
	 * @return Varien_Object
	 */
	protected function getColumn() {
		return $this->getOriginalRenderer()->getColumn();
	}

	/**
	 * @param string $paramName
	 * @param mixed $defaultValue
	 * @return mixed
	 */
	protected function getColumnParam($paramName, $defaultValue = null) {
		/** @var string $result */
		$result = df_a($this->getColumn(), $paramName, $defaultValue);
		return $result;
	}

	/**
	 * @return Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
	 */
	protected function getOriginalRenderer() {
		return $this->_getData(self::PARAM__ORIGINAL_RENDERER);
	}

	/**
	 * @param string $paramName
	 * @param mixed $defaultValue
	 * @return mixed
	 */
	protected function getRowParam($paramName, $defaultValue = null) {
		/** @var string $result */
		$result = df_a($this->getRow(), $paramName, $defaultValue);
		return $result;
	}

	/**
	 * @return Varien_Object
	 */
	protected function getRow() {
		return $this->cfg(self::PARAM__ROW);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(self::PARAM__ROW, 'Varien_Object')
			->validateClass(
				self::PARAM__ORIGINAL_RENDERER
				,'Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract'
			)
		;
	}
	const _CLASS = __CLASS__;
	const PARAM__ORIGINAL_RENDERER = 'original_renderer';
	const PARAM__ROW = 'row';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}