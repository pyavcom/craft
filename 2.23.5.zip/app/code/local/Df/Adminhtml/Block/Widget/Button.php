<?php
class Df_Adminhtml_Block_Widget_Button extends Mage_Adminhtml_Block_Widget_Button {

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}