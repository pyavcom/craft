<?php
class Df_Adminhtml_Helper_Data extends Mage_Adminhtml_Helper_Data {
	/**
	 * @override
	 * @return string
	 */
	public function __() {
		/**
		 * Обратите внимание, что этот метод нельзя записать в одну строку,
		 * потому что функция func_get_args() не может быть параметром другой функции.
		 */
		/** @var mixed[] $args */
		$args = func_get_args();
		return df_helper()->localization()->translation()->translateByParent($args, $this);
	}

	/**
	 * @param Mage_Adminhtml_Controller_Action $controller
	 * @return string
	 */
	public function getTranslatorByController(Mage_Adminhtml_Controller_Action $controller) {
		/** @var string $controllerClass */
		$controllerClass = get_class($controller);
		df_assert_string($controllerClass);
		if (!isset($this->_translatorByController[$controllerClass])) {
			/** @var array $classNameParts */
			$classNameParts =
				explode(
					Df_Core_Model_Reflection::PARTS_SEPARATOR
					,$controllerClass
				)
			;
			if ('Mage' !== df_a($classNameParts, 0)) {
				$result =
					df()->reflection()->getModuleName(
						$controllerClass
					)
				;
			}
			else {
				$result =
					implode(
						Df_Core_Model_Reflection::PARTS_SEPARATOR
						,array(
							df_a($classNameParts, 0)
							,df_a($classNameParts, 2)
						)
					)
				;
				/**
				 * Однако же, данного модуля может не существовать.
				 * Например, для адреса http://localhost.com:656/index.php/admin/system_design/
				 * алгоритм возвращает название несуществующего модуля «Mage_System».
				 *
				 * В таком случае возвращаемся к алторитму из первой ветки
				 * (по сути, для стандартного кода возвращаем «Mage_Adminhtml»)
				 */

				if (!df_module_enabled ($result)) {
					$result =
						df()->reflection()->getModuleName(
							$controllerClass
						)
					;
				}
			}
			df_result_string($result);
			$this->_translatorByController[$controllerClass] = $result;
		}
		return $this->_translatorByController[$controllerClass];
	}
	/** @var array */
	private $_translatorByController = array();

	/**
	 * @return string
	 */
	private function getModuleNameForTranslation() {
		if (!isset($this->_moduleNameForTranslation)) {
			/** @var string $result */
			$result = self::DF_PARENT_MODULE;
			if (
					df_enabled(Df_Core_Feature::LOCALIZATION)
				&&
					df_cfg()->localization()->translation()->admin()->isEnabled()
				&&
					(df()->state()->getController() instanceof Mage_Adminhtml_Controller_Action)
			) {
				/** @var Mage_Adminhtml_Controller_Action $controller */
				$controller = df()->state()->getController();
				$result =
					df_helper()->adminhtml()->getTranslatorByController(
						$controller
					)
				;
			}
			df_result_string($result);
			$this->_moduleNameForTranslation = $result;
		}
		return $this->_moduleNameForTranslation;
	}
	/** @var string */
	private $_moduleNameForTranslation;

	const _CLASS = __CLASS__;
	const DF_PARENT_MODULE = 'Mage_Adminhtml';

	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

}