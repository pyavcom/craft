<?php
interface Df_Adminhtml_Const {
	const T_SAVE_AND_CONTINUE_EDIT = 'Save and Continue Edit';
	const BUTTON_TYPE_SAVE = 'save';
	const BUTTON_TYPE_DELETE = 'delete';
	const BUTTON_TYPE_SAVE_AND_CONTINUE = 'save_and_continue';
	const BUTTON_PROPERTY_LABEL = 'label';
	const BUTTON_PROPERTY_ON_CLICK = 'onclick';
	const BUTTON_PROPERTY_CLASS = 'class';
	const BUTTON_PROPERTY_CLASS__VALUE_SAVE = 'save';
	const BUTTON_PROPERTY_ON_CLICK__VALUE_SAVE_AND_CONTINUE_EDIT = 'saveAndContinueEdit()';
	const GRID_COLUMN__PARAM__HEADER = 'header';
}