<?php
class Df_Catalog_Helper_Assert extends Mage_Core_Helper_Abstract {
	/**
	 * @var Varien_Data_Collection_Db $collection
	 * @return Df_Catalog_Helper_Assert
	 */
	public function categoryCollection(Varien_Data_Collection_Db $collection) {
			df_assert(
				df_helper()->catalog()->check()->categoryCollection($collection)
			)
		;
		return $this;
	}

	/**
	 * @var Mage_Core_Model_Resource_Abstract $resource
	 * @return Df_Catalog_Helper_Assert
	 */
	public function categoryResource(Mage_Core_Model_Resource_Abstract $resource) {
			df_assert(
				df_helper()->catalog()->check()->categoryResource($resource)
			)
		;
		return $this;
	}

	/**
	 * @var Varien_Data_Collection_Db $collection
	 * @return Df_Catalog_Helper_Assert
	 */
	public function productAttributeCollection(Varien_Data_Collection_Db $collection) {
			df_assert(
				df_helper()->catalog()->check()->productAttributeCollection($collection)
			)
		;
		return $this;
	}

	/**
	 * @var Varien_Data_Collection_Db $collection
	 * @return Df_Catalog_Helper_Assert
	 */
	public function productCollection(Varien_Data_Collection_Db $collection) {
		df_assert(
			df_helper()->catalog()->check()->productCollection($collection)
		);
		return $this;
	}

	/**
	 * @var Mage_Core_Model_Resource_Abstract $resource
	 * @return Df_Catalog_Helper_Assert
	 */
	public function productResource(Mage_Core_Model_Resource_Abstract $resource) {
			df_assert(
				df_helper()->catalog()->check()->productResource($resource)
			)
		;
		return $this;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

}