<?php
class Df_Catalog_Helper_Data extends Mage_Core_Helper_Abstract {
	/**
	 * @return Df_Catalog_Helper_Assert
	 */
	public function assert() {
		return Mage::helper(Df_Catalog_Helper_Assert::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Category
	 */
	public function category() {
		return Mage::helper(Df_Catalog_Helper_Category::mf());
	}	

	/**
	 * @return Df_Catalog_Helper_Check
	 */
	public function check() {
		return Mage::helper(Df_Catalog_Helper_Check::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Eav
	 */
	public function eav() {
		return Mage::helper(Df_Catalog_Helper_Eav::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Product
	 */
	public function product() {
		return Mage::helper(Df_Catalog_Helper_Product::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Product_Dataflow
	 */
	public function product_dataflow() {
		return Mage::helper(Df_Catalog_Helper_Product_Dataflow::mf());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}