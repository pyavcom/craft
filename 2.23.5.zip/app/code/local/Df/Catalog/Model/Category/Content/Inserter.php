<?php
/**
 * Объект данного класса способен добавлять новые блоки на страницу товарного раздела
 * без каких-либо правок, перкрытий и наследований системных файлов
 */
class Df_Catalog_Model_Category_Content_Inserter extends Df_Core_Model_Abstract {
	/**
	 * @return bool
	 */
	public function insert() {
		$result = false;
		if ($this->getTransport()) {
			if (!df_empty($this->getMethodOfUpdate())) {
				call_user_func(
					array($this, $this->getMethodOfUpdate())
					,$this->getNewContent()
				)
				;
				$result = true;
			}
		}
		return $result;
	}
	
	/**
	 * @return string|null
	 */
	private function getMethodOfUpdate() {
		if (!isset($this->_methodOfUpdate) && !$this->_methodOfUpdateIsNull) {
			/** @var (string|null)[] $map */
			$map = array();
			if ($this->isItProductListBlock()) {
				$map =
					array(
						Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_AFTER_PRODUCTS => self::DF_METHOD_APPEND
						,Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_BEFORE_PRODUCTS => self::DF_METHOD_PREPEND
						,Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_BEFORE_STATIC_BLOCK => null
						,Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_BEFORE_AND_AFTER_PRODUCTS => self::DF_METHOD_APPEND_AND_PREPEND
					)
				;
			}
			else if ($this->isItCategoryStaticBlock()) {
				$map =
					array(
						Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_AFTER_PRODUCTS => null
						,Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_BEFORE_PRODUCTS => self::DF_METHOD_APPEND
						,Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_BEFORE_STATIC_BLOCK => self::DF_METHOD_PREPEND
						,Df_Catalog_Model_System_Config_Source_Category_Content_Position
							::DF_BEFORE_AND_AFTER_PRODUCTS => null
					)
				;
			}
			/** @var string|null $result */
			$result = df_a($map, df_cfg()->catalog()->navigation()->getPosition());
			if (is_null($result)) {
				$this->_methodOfUpdateIsNull = true;
			}
			else {
				df_result_string($result);
			}
			$this->_methodOfUpdate = $result;
		}
		return $this->_methodOfUpdate;
	}
	/** @var string|null */
	private $_methodOfUpdate;
	/** @var bool */
	private $_methodOfUpdateIsNull = false;	
	

	/**
	 * @return bool
	 */
	private function isItProductListBlock() {
		return 'product_list' === $this->getBlock()->getNameInLayout();
	}

	/**
	 * @return bool
	 */
	private function isItCategoryStaticBlock() {
		$result = false;
		if ($this->getBlock() instanceof Mage_Cms_Block_Block) {
			if ($this->getCurrentCategory()) {
				if (
						(!is_null($this->getLandingPageId()))
					&&
						(!is_null($this->getBlockId()))
					&&
						($this->getBlockId() === $this->getLandingPageId())
				) {
					$result = true;
				}

			}
		}
		return $result;
	}

	/**
	 * @param string $content
	 * @return Df_Catalog_Model_Category_Content_Inserter
	 */
	public function prependContent($content) {
		$this
			->setContentByArray(
				array(
					$content
					,$this->getContent()
				)
			)
		;
		return $this;
	}

	/**
	 * @param string $content
	 * @return Df_Catalog_Model_Category_Content_Inserter
	 */
	public function appendAndPrependContent($content) {
		$this
			->setContentByArray(
				array(
					$content
					,$this->getContent()
					,$content
				)
			)
		;
		return $this;
	}

	/**
	 * @param string $content
	 * @return Df_Catalog_Model_Category_Content_Inserter
	 */
	public function appendContent($content) {
		$this
			->setContentByArray(
				array(
					$this->getContent()
					,$content
				)
			)
		;
		return $this;
	}

	/**
	 * @param array $content
	 * @return Df_Catalog_Model_Category_Content_Inserter
	 */
	private function setContentByArray(array $content) {
		$this->setContent(df_concat($content));
		return $this;
	}

	/**
	 * @param string $content
	 * @return Df_Catalog_Model_Category_Content_Inserter
	 */
	private function setContent($content) {
		$this->getTransport()->setData(self::DF_CONTENT_KEY, $content);
		return $this;
	}

	/**
	 * @return string
	 */
	private function getContent() {
		return $this->getTransport()->getData(self::DF_CONTENT_KEY);
	}

	/**
	 * @return Mage_Catalog_Model_Category|null
	 */
	private function getCurrentCategory() {
		return Mage::registry('current_category');
	}

	/**
	 * @return int|null
	 */
	private function getLandingPageId() {
		return 
				!$this->getCurrentCategory()
			? 
				null
			: 
				$this->getCurrentCategory()->getData('landing_page')
			;
	}	


	/**
	 * @return int|null
	 */
	private function getBlockId() {
		return $this->getBlock()->getData('block_id');
	}	


	/**
	 * @return Mage_Core_Block_Abstract
	 */
	private function getBlock() {
		return $this->_block;
	}

	/**
	 * @var Mage_Core_Block_Abstract
	 */
	private $_block;

	/**
	 * @return Varien_Object
	 */
	private function getTransport() {
		return $this->_transport;
	}	

	/**
	 * @var Varien_Object
	 */
	private $_transport;

	/**
	 * Возвращает HTML нового блока
	 * @return string
	 */
	private function getNewContent() {
		if (!isset($this->_newContent)) {
			// Mage_Core_Block_Abstract::$_transportObject — глобальный объект.
			// Его содержимое перетирается в методе Mage_Core_Block_Abstract::toHtml
			// Поэтому перед вызовом toHtml мы сохраняем состояние объекта Mage_Core_Block_Abstract::$_transportObject
			//$currentBlockContent = $this->getContent();
			$transportObjectState = $this->getTransport()->getData();
			$this->_newContent = $this->getBlockToInsert()->toHtml();
			$this->getTransport()->setData($transportObjectState);
		}
		return $this->_newContent;
	}

	/** @var string */
	private $_newContent;

	/**
	 * @return Mage_Core_Block_Abstract
	 */
	private function getBlockToInsert() {
		return $this->cfg(self::PARAM__BLOCK_TO_INSERT);
	}

	/**
	 * @return Varien_Event_Observer
	 */
	private function getObserver() {
		return $this->cfg(self::PARAM__OBSERVER);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this

			/**
			 * Удаление $this->validateClass(self::PARAM__OBSERVER, self::PARAM__OBSERVER_TYPE)
			 * ускорило загрузку главной страницы с 1.078 сек до 1.067 сек
			 */

			->validateClass(self::PARAM__BLOCK_TO_INSERT, self::PARAM__BLOCK_TO_INSERT_TYPE)
		;
		$this->_block = $this->getObserver()->getData('block');
		$this->_transport = $this->getObserver()->getData('transport');
	}

	const _CLASS = __CLASS__;
	const DF_CONTENT_KEY = 'html';
	const DF_METHOD_PREPEND = 'prependContent';
	const DF_METHOD_APPEND = 'appendContent';
	const DF_METHOD_APPEND_AND_PREPEND = 'appendAndPrependContent';
	const PARAM__BLOCK_TO_INSERT = 'blockToInsert';
	const PARAM__BLOCK_TO_INSERT_TYPE = 'Mage_Core_Block_Abstract';
	const PARAM__OBSERVER = 'observer';
	const PARAM__OBSERVER_TYPE = 'Varien_Event_Observer';

	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Catalog_Model_Category_Content_Inserter
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}