<?php
/**
 * @method Df_Catalog_Model_Resource_Category|Df_Catalog_Model_Resource_Category_Flat getResource()
 */
class Df_Catalog_Model_Category extends Mage_Catalog_Model_Category {
	/**
	 * @override
	 * @return string
	 */
	public function getDescription() {
		/** @var string $result */
		$result = df_nts(parent::_getData('description'));
		/** @var int $pageNumber */
		$pageNumber = intval(df_request('p'));
		if (
				(1 < $pageNumber)
			&&
				df_enabled(Df_Core_Feature::SEO)
			&&
				df_cfg()->seo()->catalog()->category()->needHideDescriptionFromNonFirstPages()
		) {
			$result = Df_Core_Const::T_EMPTY;
		}
		return $result;
	}

	/**
	 * @return string|null
	 */
	public function getDisplayMode() {
		return $this->_getData(self::PARAM__DISPLAY_MODE);
	}

	/**
	 * @return bool
	 */
	public function getExcludeUrlRewrite() {
		return (bool)($this->_getData(self::PARAM__EXCLUDE_URL_REWRITE));
	}

	/**
	 * @return string|null
	 */
	public function getExternalUrl() {
		return $this->_getData(self::PARAM__EXTERNAL_URL);
	}
	
	/**
	 * @return Zend_Uri_Http|null
	 */
	public function getExternalUri() {
		if (!isset($this->_externalUri) && !$this->_externalUriIsNull) {
			if (is_null($this->getExternalUrl())) {
				$this->_externalUri = null;
				$this->_externalUriIsNull = true;
			}
			else {
				$this->_externalUri = Zend_Uri::factory($this->getExternalUrl());
			}
		}
		return $this->_externalUri;
	}
	/** @var Zend_Uri_Http|null */
	private $_externalUri;
	/** @var bool */
	private $_externalUriIsNull = false;	

	/**
	 * @return bool
	 */
	public function getIsActive() {
		return (bool)($this->_getData(self::PARAM__IS_ACTIVE));
	}

	/**
	 * @return bool
	 */
	public function getIsAnchor() {
		return (bool)($this->_getData(self::PARAM__IS_ANCHOR));
	}

	/**
	 * @return string
	 */
	public function getName() {
		return df_nts($this->_getData(self::PARAM__NAME));
	}

	/**
	 * @return string|int|null
	 */
	public function getPath() {
		return $this->_getData(self::PARAM__PATH);
	}

	/**
	 * @return string|null
	 */
	public function getUrlKey() {
		return $this->_getData(self::PARAM__URL_KEY);
	}

	/**
	 * @param string $str
	 * @return string
	 */
	public function formatUrlKey($str) {
		return
				(
						df_enabled(Df_Core_Feature::SEO)
					&&
						df_cfg()->seo()->common()->getEnhancedRussianTransliteration()
				)
			?
				df_helper()->catalog()->product()->url()->extendedFormat($str)
			:
				parent::formatUrlKey($str)
		;			
	}

	/**
	 * @param string $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setDisplayMode($value) {
		df_param_string($value, 0);
		$this->setData(self::PARAM__DISPLAY_MODE, $value);
		return $this;
	}

	/**
	 * @param bool|int $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setExcludeUrlRewrite($value) {
		if (is_int($value)) {
			$value = (0 !== $value);
		}
		df_param_boolean ($value, 0);
		$this->setData(self::PARAM__EXCLUDE_URL_REWRITE, $value);
		return $this;
	}

	/**
	 * @param bool|int $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setIsActive($value) {
		if (is_int($value)) {
			$value = (0 !== $value);
		}
		df_param_boolean ($value, 0);
		$this->setData(self::PARAM__IS_ACTIVE, $value);
		return $this;
	}

	/**
	 * @param bool $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setIsAnchor($value) {
		df_param_boolean ($value, 0);
		$this->setData(self::PARAM__IS_ANCHOR, $value);
		return $this;
	}

	/**
	 * @param string $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setName($value) {
		df_param_string($value, 0);
		$this->setData(self::PARAM__NAME, $value);
		return $this;
	}

	/**
	 * @param string|int $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setPath($value) {
		if (is_int($value)) {
			$value = strval($value);
		}
		df_param_string($value, 0);
		$this->setData(self::PARAM__PATH, $value);
		return $this;
	}

	/**
	 * @param string $value
	 * @return Df_Catalog_Model_Category
	 */
	public function setUrlKey($value) {
		df_param_string($value, 0);
		$this->setData(self::PARAM__URL_KEY, $value);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function unsetDisplayMode() {
		$this->unsetData(self::PARAM__DISPLAY_MODE);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function unsetIsActive() {
		$this->unsetData(self::PARAM__IS_ACTIVE);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function unsetIsAnchor() {
		$this->unsetData(self::PARAM__IS_ANCHOR);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function unsetName() {
		$this->unsetData(self::PARAM__NAME);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function unsetPath() {
		$this->unsetData(self::PARAM__URL_KEY);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Category
	 */
	public function unsetUrlKey() {
		$this->unsetData(self::PARAM__PATH);
		return $this;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		/**
		 * Сюда мы попадаем при одновременной установке
		 * Magento CE 1.5.1.0 и Российской сборки Magento,
		 * поэтому надо инициализировать Российскую сборку Magento
		 * @link http://magento-forum.ru/topic/3732/
		 */
		if (!Mage::isInstalled()) {
			/** @var Df_Core_Model_Lib $libCore */
			$libCore = Mage::getSingleton('df_core/lib');
			$libCore->init();
		}
		/** @var Mage_Catalog_Helper_Category_Flat $flatHelper */
		$flatHelper = Mage::helper('catalog/category_flat');
		/** @var bool $needEnableFlatHelper */
		$needEnableFlatHelper =
			df_magento_version('1.8.0.0', '<')
			? $flatHelper->isEnabled()
			: (
					$flatHelper->isAvailable()
				&&
					!Mage::app()->getStore()->isAdmin()
				&&
					$flatHelper->isBuilt(true)
				&&
					!$this->getDataUsingMethod('disable_flat')
			)
		;
		if ($needEnableFlatHelper) {
			$this->_init(Df_Catalog_Model_Resource_Category_Flat::mf());
			$this->_useFlatResource = true;
		} else {
			$this->_init(Df_Catalog_Model_Resource_Category::mf());
		}
	}
	const _CLASS = __CLASS__;
	const PARAM__DISPLAY_MODE = 'display_mode';
	const PARAM__EXCLUDE_URL_REWRITE = 'exclude_url_rewrite';
	const PARAM__EXTERNAL_URL = 'rm__external_url';
	const PARAM__IS_ACTIVE = 'is_active';
	const PARAM__IS_ANCHOR = 'is_anchor';
	const PARAM__NAME = 'name';
	const PARAM__PATH = 'path';
	const PARAM__THUMBNAIL = 'thumbnail';
	const PARAM__URL_KEY = 'url_key';

	/**
	 * @static
	 * @return Df_Catalog_Model_Resource_Category_Collection
	 */
	public static function c() {
		return Mage::getSingleton(self::mf())->getCollection();
	}
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Catalog_Model_Category
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @param int|string $id
	 * @param int|null $storeId [optional]
	 * @return Df_Catalog_Model_Category
	 */
	public static function ld($id, $storeId = null) {
		/** @var Df_Catalog_Model_Category $result */
		$result = self::i();
		if (!is_null($storeId)) {
			$result->setStoreId($storeId);
		}
		return df_load($result, $id);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}