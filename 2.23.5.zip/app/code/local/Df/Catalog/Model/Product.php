<?php
class Df_Catalog_Model_Product extends Mage_Catalog_Model_Product {
	/**
	 * @return Df_Catalog_Model_Product
	 */
	public function deleteImages() {
		/** @var Mage_Eav_Model_Entity_Attribute_Abstract[] $attributes */
		$attributes = $this->getTypeInstance()->getSetAttributes();
		df_assert_array($attributes);
		/** @var Mage_Eav_Model_Entity_Attribute_Abstract|null $mediaGalleryAttribute */
		$mediaGalleryAttribute = df_a($attributes, self::PARAM__MEDIA_GALLERY);
		if (!is_null($mediaGalleryAttribute)) {
			df_assert($mediaGalleryAttribute instanceof Mage_Eav_Model_Entity_Attribute_Abstract);
			if (is_array($this->getMediaGallery())) {
				$this->getMediaGalleryImages();
				/** @var array|null $images */
				$images = df_a($this->getMediaGallery(), 'images');
				if (is_array($images)) {
					/** @var Mage_Catalog_Model_Product_Attribute_Backend_Media $backend */
					$backend = $mediaGalleryAttribute->getBackend();
					df_assert($backend instanceof Mage_Catalog_Model_Product_Attribute_Backend_Media);
					foreach ($images as $image){
						/** @var string|null $fileName */
						$fileName = df_a($image, 'file');
						if ($backend->getImage($this, $fileName)) {
							$backend->removeImage($this, $fileName);
						}
					}
				}
			}
		}
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Product
	 */
	public function deleteOptions() {
		df_assert_array($this->getOptions());
		foreach ($this->getOptions() as $option) {
			/** @var Df_Catalog_Model_Product_Option $option */
			df_assert($option instanceof Df_Catalog_Model_Product_Option);
			$option->deleteWithDependencies();
		}
		return $this;
	}

	/**
	 * @return int
	 */
	public function getAttributeSetId() {
		return intval($this->_getData(self::PARAM__ATTRIBUTE_SET_ID));
	}

	/**
	 * Перекрываем родительский метод пока только ради модуля Яндекс.Маркет.
	 * Модулю Яндекс.Маркет нужно, чтобы адреса товарных страниц включали товарный раздел.
	 * Этого можно было бы достичь посредством
	 * Mage::register('current_category', $category)
	 * однако этот способ неэффективен по производительности:
	 * модулю Яндекс.Маркет изначально известны только идентификаторы
	 * привязанных к товару разделов, а загрузка этих товарных разделов
	 * только ради метода Mage_Catalog_Model_Product::getCategoryId()
	 * (где все равно используется только идентификатор) приведет к торможению системы.
	 * Именно поэтому перекрываем метод Mage_Catalog_Model_Product::getCategoryId() своим.
	 * @override
	 * @return int|bool
	 */
	public function getCategoryId() {
		/** @var int|bool $result */
		$result = parent::getCategoryId();
		if (false === $result) {
			$result = $this->_getData(self::PARAM__RM_CATEGORY_ID);
			if (df_empty($result)) {
				$result = false;
			}
		}
		return $result;
	}

	/**
	 * @return float
	 */
	public function getCompositeFinalPriceWithTax() {
		if (!isset($this->_compositeFinalPriceWithTax)) {
			/** @var float $result */
			$result = null;
			switch ($this->getTypeId()) {
				case Mage_Catalog_Model_Product_Type::TYPE_SIMPLE:
				case Mage_Catalog_Model_Product_Type::TYPE_VIRTUAL:
					/** @var float $priceWithoutTax */
					$priceWithoutTax = $this->getPriceModel()->getFinalPrice($qty = 1, $product = $this);
					$result =
						df_mage()->taxHelper()->getPrice(
							$product = $this
							,$price =  $priceWithoutTax
							,$includingTax = true
							,$shippingAddress = null
							,$billingAddress = null
							,$ctc = null
							,$store = $product->getStore()
							,$priceIncludesTax = false
						)
					;
					break;
				case Mage_Catalog_Model_Product_Type::TYPE_CONFIGURABLE:
					$result =
						df_mage()->taxHelper()->getPrice(
							$product = $this
							,$price = $this->getMinimalPrice()
							,$includingTax = true
							,$shippingAddress = null
							,$billingAddress = null
							,$ctc = null
							,$store = $product->getStore()
							,$priceIncludesTax = null
						)
					;
					/**
					 * Обратите внимание, что $result будет равно null,
					 * если товар отсутствует на складе
					 * @see Df_Catalog_Model_Product::getMinimalPrice
					 */
					if (is_null($result)) {
						$result = 0.0;
					}
					df_assert_float($result);
					break;
				case Mage_Catalog_Model_Product_Type::TYPE_GROUPED:
					/** @var Mage_Catalog_Model_Product_Type_Grouped $typeGrouped */
					$typeGrouped = $this->getTypeInstance($singleton = false);
					$typeGrouped->setStoreFilter($store = $this->getStore(), $product = $this);
					/** @var Df_Catalog_Model_Product[] $associatedProducts */
					$associatedProducts = $typeGrouped->getAssociatedProducts($product);
					foreach ($associatedProducts as $associatedProduct) {
						/** @var Df_Catalog_Model_Product $associatedProduct */
						/** @var float $currentPrice */
						$currentPrice = $associatedProduct->getCompositeFinalPriceWithTax();
						$result =
							is_null($result)
							? $currentPrice
							: min($result, $currentPrice)
						;
					}
					if (is_null($result)) {
						$result = 0.0;
					}
					break;
				case Mage_Catalog_Model_Product_Type::TYPE_BUNDLE:
					/** @var Mage_Bundle_Model_Product_Price $priceModel */
					$priceModel  = $this->getPriceModel();
					$result =
						$priceModel
							->getTotalPrices(
								$this
								,$which = 'min'
								,$includeTax = true
								,$takeTierPrice = false
							)
					;
					break;
				default:
					df_error('Незвестный тип товара');
					break;
			}
			df_result_float($result);
			$this->_compositeFinalPriceWithTax = $result;
		}
		return $this->_compositeFinalPriceWithTax;
	}
	/** @var float */
	private $_compositeFinalPriceWithTax;

	/**
	 * @return string
	 */
	public function getDescription() {
		return df_nts($this->_getData(self::PARAM__DESCRIPTION));
	}

	/**
	 * Обратите внимание, что этот метод надлежит использовать только для простых товаров!
	 * Для настраиваемых товаров значения свойств «длина», «ширина», «высота»
	 * могу отсутствовать!
	 * @return float
	 */
	public function getHeight() {
		/** @var float $result */
		$result = parent::_getData(self::PARAM__HEIGHT);
		if (is_null($result) || (0.0 === floatval($result))) {
			$result = df_cfg()->shipping()->product()->getDefaultHeight();
		}
		$result = floatval($result);
		return $result;
	}

	/**
	 * @override
	 * @return int|null
	 */
	public function getId() {
		/** @var int|null $result */
		$result = parent::getId();
		if (!is_null($result)) {
			$result = intval($result);
		}
		return $result;
	}

	/**
	 * Обратите внимание, что этот метод надлежит использовать только для простых товаров!
	 * Для настраиваемых товаров значения свойств «длина», «ширина», «высота»
	 * могу отсутствовать!
	 * @return float
	 */
	public function getLength() {
		/** @var float $result */
		$result = parent::_getData(self::PARAM__LENGTH);
		if (is_null($result) || (0.0 === floatval($result))) {
			$result = df_cfg()->shipping()->product()->getDefaultLength();
		}
		$result = floatval($result);
		return $result;
	}

	/**
	 * Обратите внимание, что стандартный программный код иногда использует синтаксис:
	 * $this->getMediaGallery('images')
	 * Наш метод тоже поддерживает этот синтаксис.
	 * @param string|null $key[optional]
	 * @return mixed[]|null
	 */
	public function getMediaGallery($key = null) {
		/** @var mixed[]|null $result */
		$result = null;
		/** @var mixed[]|null $mediaGallery */
		$mediaGallery = $this->_getData(self::PARAM__MEDIA_GALLERY);
		if (!is_null($mediaGallery)) {
			df_assert_array($mediaGallery);
			$result =
				is_null($key)
				? $mediaGallery
				: df_a($mediaGallery, $key)
			;
		}
		if (!is_null($result)) {
			df_result_array($result);
		}
		return $result;
	}

	/**
	 * @return string
	 */
	public function getMetaTitle() {
		return
			df_enabled(Df_Core_Feature::SEO)
			? $this->getMetaTitleDf()
			: parent::_getData(self::PARAM__META_TITLE)
		;
	}

	/**
	 * Обратите внимание, что метод вернёт null,
	 * если товар отсутствует на складе
	 * @override
	 * @return float|null
	 */
	public function getMinimalPrice() {
		/** @var float|null $result */
		$result = parent::getMinimalPrice();
		if (is_null($result)) {
			/**
			 * @see Mage_Catalog_Model_Product::getMinimalPrice()
			 * вернёт непустое значение только в том случае,
			 * если товар был загружен не в одиночку, а коллекцией,
			 * и для коллекции перед загрузкой был вызван метод
			 * @see Mage_Catalog_Model_Resource_Product_Collection::addMinimalPrice()
			 * или @see Mage_Catalog_Model_Resource_Product_Collection::addPriceData().
			 * В противном случае значение свойства minimal_price надо загрузить вручную.
			 */
			/** @var Zend_Db_Select $select */
			$select = df()->db()->conn()->select();
			$select
				->from(
					array(
						'maintable' =>
							df_mage()->core()->resource()->getTableName('catalog/product_index_price')
					)
				)
				->where('(? = maintable.entity_id)', $this->getId())
				->where('(? = maintable.website_id)', $this->getStore()->getWebsiteId())
				->where('(? = maintable.customer_group_id)', 0)
				->where('(? = maintable.tax_class_id)', 0)
			;
			/** @var Zend_Db_Statement_Pdo $query */
			$query = df()->db()->conn()->query($select);
			/** @var array(string => string) $row */
			$row = $query->fetch($style = Zend_Db::FETCH_ASSOC);
			if (is_array($row)) {
				$result = df_a($row, 'min_price');
				if (!is_null($result)) {
					$result = floatval($result);
				}
				$this->setData('minimal_price', $result);
			}
		}
		/**
		 * Обратите внимание, что метод вернёт null,
		 * если товар отсутствует на складе
		 */
		return $result;
	}

	/**
	 * @return string
	 */
	public function getName() {
		return df_nts($this->_getData(self::PARAM__NAME));
	}

	/**
	 * @param string $title
	 * @return array
	 */
	public function getOptionsByTitle($title) {
		df_param_string($title, 0);
		$result = array();
		df_assert_array($this->getOptions());
		foreach ($this->getOptions() as $option) {
			/** @var Df_Catalog_Model_Product_Option $option */
			df_assert($option instanceof Df_Catalog_Model_Product_Option);
			if (
					$title
				==
					$option->getDataUsingMethod(
						Df_Catalog_Model_Product_Option::PARAM__TITLE
					)
			) {
				$result[]= $option;
			}
		}
		return $result;
	}

	/**
	 * @override
	 * @return Df_Catalog_Model_Resource_Product
	 */
	public function getResource() {
		return parent::getResource();
	}

	/**
	 * @override
	 * @return float
	 */
	public function getWeight() {
		/**
		 * Раньше тут стояло parent::_getData(self::PARAM__WEIGHT), что в корне неправильно,
		 * потому что в родительском классе Mage_Catalog_Model_Product
		 * метод getWeight присутствует (@see Mage_Catalog_Model_Product::getWeight),
		 * и он работает как
		 * $this->getTypeInstance(true)->getWeight($this)
		 *
		 * Тупое parent::_getData(self::PARAM__WEIGHT) не работает (возвращает пустое значение)
		 * для сложных типов товаров (например, для настраиваемого).
		 *
		 * Дефект было допущен 15 марта 2013 года (версия 2.17.3)
		 * и замечен мной только 21 сентября 2013 года.
		 * Что интересно, никто из клиентов за эти 6 месяцев дефекта не заметил.
		 */
		/** @var float $result */
		$result = parent::getWeight();
		if ((is_null($result) || (0.0 === floatval($result)))) {
			/**
			 * Обратите внимание, что для некоторых типов товаров нормально не иметь вес.
			 * Например, для виртуальных и скачиваемых товаров.
			 * Думаю, что перезагружать товар для уточнения веса
			 * имеет смысл вообще только для простых товаров.
			 */
			if (Mage_Catalog_Model_Product_Type::TYPE_SIMPLE === $this->getTypeId()) {
				/**
				 * Видимо, товар был взят из коллекции,
				 * в которую не было добавлено свойство «вес».
				 */
				/** @vare bool $inRecursion */
				static $inRecursion = false;
				if (!$inRecursion) {
					$inRecursion = true;
					$product = df_helper()->catalog()->product()->reload($this);
					$result = $product->getWeight();
					$inRecursion = false;
				}
				if ((is_null($result) || (0.0 === floatval($result)))) {
					$result = df_cfg()->shipping()->product()->getDefaultWeight();
				}
				if (false === strpos(Mage::app()->getRequest()->getRequestUri(), 'sales/order/reorder')) {
					/**
					 * Для страницы перезаказа отсутствие веса в коллекции — это нормально
					 */
					/*df_notify_me(
						sprintf(
							'У товара «%s» отсутствует вес на странице %s'
							,$this->getName()
							,Mage::app()->getRequest()->getRequestUri()
						)
					);
					df_bt();     */
				}
			}
		}
		$result = floatval($result);
		return $result;
	}

	/**
	 * Обратите внимание, что этот метод надлежит использовать только для простых товаров!
	 * Для настраиваемых товаров значения свойств «длина», «ширина», «высота»
	 * могу отсутствовать!
	 * @return float
	 */
	public function getWidth() {
		/** @var float $result */
		$result = parent::_getData(self::PARAM__WIDTH);
		if (is_null($result) || (0.0 === floatval($result))) {
			$result = df_cfg()->shipping()->product()->getDefaultWidth();
		}
		$result = floatval($result);
		return $result;
	}

	/**
	 * @return Df_Catalog_Model_Product
	 */
	public function log() {
		/** @var array(string => string|int|float) $dataToLog */
		$dataToLog = array();
		foreach($this->getData() as $key => $value) {
			/** @var string $key */
			/** @var mixed $value */
			if (!is_object($value) && !is_array($value)) {
				$dataToLog[$key] = $value;
			}
		}
		Mage::log($dataToLog);
		return $this;
	}

	/**
	 * @param int $value
	 * @return Df_Catalog_Model_Product
	 */
	public function setAttributeSetId($value) {
		df_param_integer($value, 0);
		$this->setData(self::PARAM__ATTRIBUTE_SET_ID, $value);
		return $this;
	}

	/**
	 * @param int $value
	 * @return Df_Catalog_Model_Product
	 */
	public function setStoreId($value) {
		df_param_integer($value, 0);
		$this->setData(self::PARAM__STORE_ID, $value);
		return $this;
	}

	/**
	 * @param string $value
	 * @return Df_Catalog_Model_Product
	 */
	public function setUrlKey($value) {
		df_param_string($value, 0);
		$this->setData(self::PARAM__URL_KEY, $value);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Product
	 */
	public function unsetAttributeSetId() {
		$this->unsetData(self::PARAM__ATTRIBUTE_SET_ID);
		return $this;
	}

	/**
	 * @return Df_Catalog_Model_Product
	 */
	public function unsetUrlKey() {
		$this->unsetData(self::PARAM__URL_KEY);
		return $this;
	}

	/**
	 * @return string|null
	 */
	private function getCategoryTail() {
		return
			!$this->getCurrentCategory()
			? null
			: $this->getCurrentCategory()->getName()
		;
	}

	/**
	 * @return boolean
	 */
	private function isCategoryTailEnabled() {
		return df_cfg()->seo()->html()->getAppendCategoryNameToProductTitleTag();
	}

	/**
	 * @return string|null
	 */
	private function getCategoryTailIfEnabled() {
		return
			!$this->isCategoryTailEnabled()
			? null
			: $this->getCategoryTail()
		;
	}

	/**
	 * @return Mage_Catalog_Model_Category|null
	 */
	private function getCurrentCategory() {
		return Mage::registry(self::REGISTRY__CURRENT_CATEGORY);
	}

	/**
	 * @return string
	 */
	private function getDefaultProductRawMetaTitle() {
		return df_cfg()->seo()->html()->getDefaultPatternForProductTitleTag();
	}

	/**
	 * @return string
	 */
	private function getMetaTitleDf() {
		return
			implode(
				' - '
				,df_clean(
					array(
						$this->processPatterns($this->getRawMetaTitle())
						,$this->getCategoryTailIfEnabled()
					)
				)
			)
		;
	}

	/**
	 * @return string
	 */
	private function getRawMetaTitle() {
		return
			!df_empty(parent::_getData(self::PARAM__META_TITLE))
			? parent::_getData(self::PARAM__META_TITLE)
			: $this->getDefaultProductRawMetaTitle()
		;
	}

	/**
	 * @param string $text
	 * @return string
	 */
	private function processPatterns($text) {
		return
			Df_Seo_Model_Template_Processor::i(
				array(
					/**
					 * Явно приводим $text к типу string,
					 * потому что $text в настоящий момент может быть равен null
					 */
					Df_Seo_Model_Template_Processor::PARAM__TEXT => (string)$text
					,Df_Seo_Model_Template_Processor::PARAM__OBJECTS =>
						array(
							'product' => $this
						)
				)
			)->process()
		;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		/**
		 * Обязательно, иначе будет сбой при установке.
		 * Ведь наш класс перекрывает системный класс Mage_Catalog_Model_Product,
		 * а системный класс используется при установке ядра,
		 * в то время, когда Российская сборка ещё не инициализирована.
		 */
		Mage::getModel('df_core/lib')->init();
		$this->_init(Df_Catalog_Model_Resource_Product::mf());
	}
	const _CLASS = __CLASS__;
	const PARAM__ATTRIBUTE_SET_ID = 'attribute_set_id';
	const PARAM__COUNTRY_OF_MANUFACTURE = 'country_of_manufacture';
	const PARAM__DESCRIPTION = 'description';
	const PARAM__HAS_OPTIONS = 'has_options';
	const PARAM__HEIGHT = 'height';
	const PARAM__IMAGE = 'image';
	const PARAM__IS_SALABLE = 'is_salable';
	const PARAM__LENGTH = 'length';
	const PARAM__MANUFACTURER = 'manufacturer';
	const PARAM__MEDIA_GALLERY = 'media_gallery';
	const PARAM__META_TITLE = 'meta_title';
	const PARAM__NAME = 'name';
	const PARAM__PRICE = 'price';
	const PARAM__RM_CATEGORY_ID = 'rm_category_id';
	const PARAM__SHORT_DESCRIPTION = 'short_description';
	const PARAM__SKU = 'sku';
	const PARAM__SMALL_IMAGE = 'small_image';
	const PARAM__STORE_ID = 'store_id';
	const PARAM__TYPE_ID = 'type_id';
	const PARAM__URL_KEY = 'url_key';
	const PARAM__VISIBILITY = 'visibility';
	const PARAM__WEIGHT = 'weight';
	const PARAM__WIDTH = 'width';
	const REGISTRY__CURRENT_CATEGORY = 'current_category';
	/**
	 * @static
	 * @return Df_Catalog_Model_Resource_Product_Collection
	 */
	public static function c() {
		return Mage::getSingleton(self::mf())->getCollection();
	}
	/**
	 * @static
	 * @return string[]
	 */
	public static function getMediaAttributeNames() {
		return array('image', 'small_image', 'thumbnail');
	}
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Catalog_Model_Product
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @param int|string $id
	 * @param string|null $field [optional]
	 * @return Df_Catalog_Model_Product
	 */
	public static function ld($id, $field = null) {
		return df_load(self::i(), $id, $field);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_Catalog_Model_Product
	 */
	public static function s() {
		return Mage::getSingleton(self::mf());
	}
}