<?php
class Df_Checkout_Block_Cart_Shipping extends Mage_Checkout_Block_Cart_Shipping {
	/** @return bool */
	public function getCityActive() {
		return true;
	}
}