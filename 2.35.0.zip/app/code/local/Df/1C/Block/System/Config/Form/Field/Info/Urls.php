<?php
class Df_1C_Block_System_Config_Form_Field_Info_Urls extends Mage_Adminhtml_Block_System_Config_Form_Field {
	/**
	 * @override
	 * @return string
	 */
	public function getTemplate() {return 'df/1c/system/config/form/field/info/urls.phtml';}

	/** @return array(string => mixed) */
	public function getUrls() {
		if (!isset($this->{__METHOD__})) {
			/** @var array(string => mixed) $result */
			$result = array();
			foreach (Mage::app()->getStores() as $store) {
				/** @var Mage_Core_Model_Store $store */
				$result[$store->getName()] = $this->getUrlForStore($store);
			}
			$this->{__METHOD__} = $result;
		}
		return $this->{__METHOD__};
	}

	/**
	 * @override
	 * @param Varien_Data_Form_Element_Abstract $element
	 * @return string
	 */
	public function render(Varien_Data_Form_Element_Abstract $element) {
		$this->addData(array(
			self::P__ELEMENT => $element
		));
		return $this->_decorateRowHtml($element, $this->_toHtml());
	}

	/**
	 * @param Mage_Core_Model_Store $store
	 * @return string
	 */
	private function getUrlForStore(Mage_Core_Model_Store $store) {
		return
			Mage::getUrl(
				Mage::app()->isSingleStoreMode()
				? 'df-1c/cml2/index'
				: df_concat_url('df-1c/cml2/index/store-view', $store->getCode())
				, array(
					'_nosid' => true
					/**
					 * Указывание значения Mage_Core_Model_Store::URL_TYPE_DIRECT_LINK
					 * вместо значения по умолчанию Mage_Core_Model_Store::URL_TYPE_LINK
					 * позволяет нам избежать включения в адрес кода магазина:
					 * @see Mage_Core_Model_Store::getBaseUrl()
					 */
					, '_type' => Mage_Core_Model_Store::URL_TYPE_DIRECT_LINK
					/**
					 * Указание магазина обязательно
					 * для корректного исключения из адресов index.php при необходимости,
					 * потому что иначе система сочтёт магазин административным,
					 * а для административного магазина
					 * она никогда не исключает index.php из адресов:
					 * @see Mage_Core_Model_Store::_updatePathUseRewrites()
					 */
					, '_store' => $store
				)
			)
		;
	}

	const P__ELEMENT = 'element';
}