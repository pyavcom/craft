<?php
class Df_Assist_Model_Payment extends Df_Payment_Model_Method_WithRedirect {}