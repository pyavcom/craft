<?php
class Df_CatalogInventory_Helper_Data extends Mage_Core_Helper_Abstract {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}