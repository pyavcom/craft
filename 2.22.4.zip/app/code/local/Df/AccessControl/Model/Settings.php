<?php
class Df_AccessControl_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function getAutoExpandAll() {
		return $this->getYesNo('df_tweaks_admin/access_control/auto_expand_all');
	}

	/**
	 * @return boolean
	 */
	public function getAutoSelectAncestors() {
		return $this->getYesNo('df_tweaks_admin/access_control/auto_select_ancestors');
	}

	/**
	 * @return boolean
	 */
	public function getAutoSelectDescendants() {
		return $this->getYesNo('df_tweaks_admin/access_control/auto_select_descendants');
	}

	/**
	 * @return boolean
	 */
	public function getEnabled() {
		return $this->getYesNo('df_tweaks_admin/access_control/enabled');
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}