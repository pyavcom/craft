<?php
/**
 * @method Df_AccessControl_Model_Event_Permissions_Role_Saverole getEvent()
 */
class Df_AccessControl_Model_Handler_Permissions_Role_Saverole_UpdateCatalogAccessRights
	extends Df_Core_Model_Handler {
	/**
	 * Метод-обработчик события
	 * @override
	 * @return void
	 */
	public function handle() {
		if (
				df_enabled(Df_Core_Feature::ACCESS_CONTROL)
			&&
				df_cfg()->admin()->access_control()->getEnabled()
		) {
			if (
				/**
				 * true, если расширенное управление доступом
				 * включено для данной конкретной должности
				 */
				$this->getEvent()->isModuleEnabledForRole()
			) {
				$this->getRole()
					->setCategoryIds(
						$this->getEvent()->getSelectedCategoryIds()
					)
				;
				if (is_null($this->getRole()->getId())) {
					$this->getRole()
						->prepareForInsert($this->getEvent()->getRoleId())
					;
				}
				$this->getRole()
					->save()
					/**
					 * Небольшой хак.
					 * Если ранее вызывался метод prepareForInsert(), то id сбрасывается.
					 * Лень разбираться.
					 */
					->setId($this->getEvent()->getRoleId())
				;
				df_assert(
						intval($this->getEvent()->getRoleId())
					===
						intval($this->getRole()->getId())
				);
			}

			else {
				if ($this->getRole()->isModuleEnabled()) {
					$this->getRole()
						->delete()
						->setId(null)
					;
				}

			}
		}

	}

	/**
	 * @return Df_AccessControl_Model_Role
	 */
	private function getRole() {
		if (!isset($this->_role)) {
			$this->_role = Df_AccessControl_Model_Role::i();
			if (!df_empty($this->getEvent()->getRoleId())) {
				$this->_role->load($this->getEvent()->getRoleId());
			}
		}
		return $this->_role;
	}
	/** @var Df_AccessControl_Model_Role */
	private $_role;

	/**
	 * Класс события (для валидации события)
	 * @override
	 * @return string
	 */
	protected function getEventClass() {
		return Df_AccessControl_Model_Event_Permissions_Role_Saverole::_CLASS;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}