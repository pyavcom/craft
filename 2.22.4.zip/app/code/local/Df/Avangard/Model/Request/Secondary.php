<?php
/**
 * @method Df_Avangard_Model_Payment getPaymentMethod()
 */
abstract class Df_Avangard_Model_Request_Secondary extends Df_Payment_Model_Request_Secondary {
	/**
	 * @return string
	 */
	abstract protected function getRequestDocumentTag();

	/**
	 * @return string
	 */
	abstract protected function getRequestUriSuffix();

	/**
	 * @override
	 * @return array(string => string)
	 */
	protected function getResponseAsArray() {
		if (!isset($this->_responseAsArray)) {
			$this->_responseAsArray = $this->getResponseAsSimpleXml()->asCanonicalArray();
		}
		return $this->_responseAsArray;
	}
	/** @var mixed[] */
	private $_responseAsArray;

	/**
	 * @return Zend_Http_Client
	 */
	private function getHttpClient() {
		if (!isset($this->_httpClient)) {
			/** @var Zend_Http_Client $result */
			$result = new Zend_Http_Client();
			$result
				->setHeaders(array())
				->setUri($this->getRequestUri())
				->setConfig(array('timeout' => 3))
				->setParameterPost(array('xml' => $this->getRequestDocument()->getXml()))
			;
			df()->debug()->report(
				sprintf('%s-request-{date}-{time}.xml', $this->getRequestUriSuffix())
				,$this->getRequestDocument()->getXml()
			);
			$this->_httpClient = $result;
		}
		return $this->_httpClient;
	}
	/** @var Zend_Http_Client */
	private $_httpClient;

	/**
	 * @return Zend_Http_Response
	 */
	private function getHttpResponse() {
		if (!isset($this->_httpResponse)) {
			$this->_httpResponse = $this->getHttpClient()->request(Zend_Http_Client::POST);
		}
		return $this->_httpResponse;
	}
	/** @var Zend_Http_Response */
	private $_httpResponse;

	/**
	 * @override
	 * @return array(string => string|int)
	 */
	protected function getParams() {
		return
			array(
				'shop_id' => $this->getServiceConfig()->getShopId()
				,'shop_passwd' => $this->getServiceConfig()->getRequestPassword()
				,'ticket' => $this->getPaymentExternalId()
			)
		;
	}
	
	/** 
	 * @override
	 * @return string
	 */
	protected function getPaymentExternalId() {
		return $this->getResponseRegistration()->getPaymentExternalId();
	}	
	
	/**
	 * @return Df_Avangard_Model_RequestDocument
	 */
	private function getRequestDocument() {
		if (!isset($this->_requestDocument)) {
			$this->_requestDocument =
				Df_Avangard_Model_RequestDocument::i(
					$requestParams = $this->getParams()
					,$tagName = $this->getRequestDocumentTag()
				)
			;
		}
		return $this->_requestDocument;
	}
	/** @var Object */
	private $_requestDocument;

	/**
	 * @return Zend_Uri_Http
	 */
	private function getRequestUri() {
		if (!isset($this->_requestUri)) {
			/** @var Zend_Uri_Http $result */
			$result = Zend_Uri::factory('https');
			$result->setHost('www.avangard.ru');
			$result->setPath(sprintf('/iacq/h2h/%s', $this->getRequestUriSuffix()));
			$this->_requestUri = $result;
		}
		return $this->_requestUri;
	}
	/** @var Zend_Uri_Http */
	private $_requestUri;

	/**
	 * @return Df_Varien_Simplexml_Element
	 */
	private function getResponseAsSimpleXml() {
		if (!isset($this->_responseAsSimpleXml)) {
			$this->_responseAsSimpleXml =
				new Df_Varien_Simplexml_Element(
					$this->getHttpResponse()->getBody()
				)
			;
			df()->debug()->report(
				sprintf('%s-response-{date}-{time}.xml', $this->getRequestUriSuffix())
				,$this->getHttpResponse()->getBody()
			);
		}
		return $this->_responseAsSimpleXml;
	}
	/** @var Df_Varien_Simplexml_Element */
	private $_responseAsSimpleXml;
	
	/**
	 * @return Df_Avangard_Model_Response_Registration
	 */
	private function getResponseRegistration() {
		if (!isset($this->_responseRegistration)) {
			$this->_responseRegistration = Df_Avangard_Model_Response_Registration::i();
			$this->_responseRegistration->loadFromPaymentInfo($this->getOrderPayment());
		}
		return $this->_responseRegistration;
	}
	/** @var Df_Avangard_Model_Response_Registration */
	private $_responseRegistration;	
	
	const _CLASS = __CLASS__;
}