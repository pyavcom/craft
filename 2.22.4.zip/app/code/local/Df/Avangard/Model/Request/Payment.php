<?php
class Df_Avangard_Model_Request_Payment extends Df_Payment_Model_Request_Payment {
	/**
	 * @return Df_Avangard_Model_Response_Registration
	 */
	public function getResponse() {
		if (!isset($this->_response)) {
			$this->_response =
				Df_Avangard_Model_Response_Registration::i(
					$this->getResponseAsSimpleXml()->asCanonicalArray()
				)
			;
			$this->_response->saveInPaymentInfo($this->getPaymentMethod()->getInfoInstance());
			$this->_response->throwOnFailure();
		}
		return $this->_response;
	}
	/** @var Df_Avangard_Model_Response_Registration */
	private $_response;

	/**
	 * @override
	 * @return string
	 */
	public function getTransactionType() {
		return Mage_Sales_Model_Order_Payment_Transaction::TYPE_PAYMENT;
	}

	/**
	 * @override
	 * @return array(string => string)
	 */
	protected function getParamsInternal() {
		return
			array(
				'shop_id' => $this->getServiceConfig()->getShopId()
				,'shop_passwd' => $this->getServiceConfig()->getRequestPassword()
				,'amount' => intval(round(100 * $this->getAmount()->getAsFixedFloat()))
				,'order_number' => $this->getOrder()->getIncrementId()
				,'order_description' => $this->getTransactionDescription()
				,'language' => 'RU'
				,'back_url' => $this->getCustomerReturnUrl()
				,'client_name' => $this->getCustomerNameFull()
				,'client_address' => $this->getAddressStreet()
				,'client_phone' => $this->getCustomerPhone()
				,'client_email' => $this->getCustomerEmail()
				,'client_ip' => $this->getCustomerIpAddress()
			)
		;
	}

	/**
	 * @return string
	 */
	private function getCustomerReturnUrl() {
		if (!isset($this->_customerReturnUrl)) {
			$this->_customerReturnUrl =
				Mage::getUrl(
					implode(
						Df_Core_Const::T_URL_PATH_SEPARATOR
						,array($this->getPaymentMethod()->getCode(), 'customerReturn')
					)
					,array(
						'_query' =>
							array(
								Df_Avangard_Model_Action_CustomerReturn
									::REQUEST_PARAM__ORDER_INCREMENT_ID =>
										$this->getOrder()->getIncrementId()
							)
					)
				)
			;
		}
		return $this->_customerReturnUrl;
	}
	/** @var string */
	private $_customerReturnUrl;
	
	/**
	 * @return Zend_Http_Client
	 */
	private function getHttpClient() {
		if (!isset($this->_httpClient)) {
			/** @var Zend_Http_Client $result */
			$result = new Zend_Http_Client();
			$result
				->setHeaders(array())
				->setUri($this->getRequestUri())
				->setConfig(array('timeout' => 3))
				->setParameterPost(array('xml' => $this->getRequestDocument()->getXml()))
			;
			$this->_httpClient = $result;
		}
		return $this->_httpClient;
	}
	/** @var Zend_Http_Client */
	private $_httpClient;
	
	/**
	 * @return Zend_Http_Response
	 */
	private function getHttpResponse() {
		if (!isset($this->_httpResponse)) {
			$this->_httpResponse = $this->getHttpClient()->request(Zend_Http_Client::POST);
		}
		return $this->_httpResponse;
	}
	/** @var Zend_Http_Response */
	private $_httpResponse;	
	
	/**
	 * @return Df_Avangard_Model_RequestDocument
	 */
	private function getRequestDocument() {
		if (!isset($this->_requestDocument)) {
			$this->_requestDocument =
				Df_Avangard_Model_RequestDocument::registration($this->getParams())
			;
		}
		return $this->_requestDocument;
	}
	/** @var Df_Avangard_Model_RequestDocument */
	private $_requestDocument;
	
	/**
	 * @return Zend_Uri_Http
	 */
	private function getRequestUri() {
		if (!isset($this->_requestUri)) {
			/** @var Zend_Uri_Http $result */
			$result = Zend_Uri::factory('https');
			$result->setHost('www.avangard.ru');
			$result->setPath('/iacq/h2h/reg');
			$this->_requestUri = $result;
		}
		return $this->_requestUri;
	}
	/** @var Zend_Uri_Http */
	private $_requestUri;

	/**
	 * @return Df_Varien_Simplexml_Element
	 */
	private function getResponseAsSimpleXml() {
		if (!isset($this->_responseAsSimpleXml)) {
			$this->_responseAsSimpleXml =
				new Df_Varien_Simplexml_Element(
					$this->getHttpResponse()->getBody()
				)
			;
			df()->debug()->report(
				'registration-{date}-{time}.xml'
				,$this->getHttpResponse()->getBody()
			);
		}
		return $this->_responseAsSimpleXml;
	}
	/** @var Df_Varien_Simplexml_Element */
	private $_responseAsSimpleXml;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}