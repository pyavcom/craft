<?php
class Df_Admin_Helper_Data extends Mage_Adminhtml_Helper_Data {
	/**
	 * @return string
	 */
	public function getAdminUrl() {
		if (!isset($this->_adminUrl)) {
			/** @var Mage_Core_Model_Config_Element $route */
			$route =
				Mage::getConfig()->getNode(
					df_parse_boolean(Mage::getConfig()->getNode(self::XML_PATH_USE_CUSTOM_ADMIN_PATH))
					? self::XML_PATH_CUSTOM_ADMIN_PATH
					: self::XML_PATH_ADMINHTML_ROUTER_FRONTNAME
				)
			;
			/**
			 * Обратите внимание, что $route неявно преобразуется в строку
			 */
			$this->_adminUrl = df_concat_url(Mage::getBaseUrl(), $route);
		}
		return $this->_adminUrl;
	}
	/** @var string */
	private $_adminUrl;

	/**
	 * @return Mage_Adminhtml_Model_System_Config_Source_Yesno
	 */
	public function yesNo() {
		/** @var Mage_Adminhtml_Model_System_Config_Source_Yesno $result */
		static $result;
		if (!isset($result)) {
			$result = df_model('adminhtml/system_config_source_yesno');
			df_assert($result instanceof Mage_Adminhtml_Model_System_Config_Source_Yesno);
		}
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}