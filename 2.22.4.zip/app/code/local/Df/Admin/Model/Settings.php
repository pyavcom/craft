<?php
class Df_Admin_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return Df_1C_Model_Settings
	 */
	public function _1c() {
		return Mage::getSingleton(Df_1C_Model_Settings::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Admin
	 */
	public function admin() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin::mf());
	}
	/**
	 * @return Df_Admin_Model_Settings_Base
	 */
	public function base() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Base::mf());
	}
	/**
	 * @return Df_Catalog_Model_Settings
	 */
	public function catalog() {
		return Mage::getSingleton(Df_Catalog_Model_Settings::mf());
	}
	/**
	 * @return Df_Checkout_Model_Settings
	 */
	public function checkout() {
		return Mage::getSingleton(Df_Checkout_Model_Settings::mf());
	}
	/**
	 * @return Df_Cms_Model_Settings
	 */
	public function cms() {
		return Mage::getSingleton(Df_Cms_Model_Settings::mf());
	}
	/**
	 * @return Df_Customer_Model_Settings
	 */
	public function customer() {
		return Mage::getSingleton(Df_Customer_Model_Settings::mf());
	}
	/**
	 * @return Df_Dataflow_Model_Settings
	 */
	public function dataflow() {
		return Mage::getSingleton(Df_Dataflow_Model_Settings::mf());
	}
	/**
	 * @return Df_Directory_Model_Settings
	 */
	public function directory() {
		return Mage::getSingleton(Df_Directory_Model_Settings::mf());
	}
	/**
	 * @return Df_Forum_Model_Settings
	 */
	public function forum() {
		return Mage::getSingleton(Df_Forum_Model_Settings::mf());
	}
	/**
	 * @return Df_Index_Model_Settings
	 */
	public function index() {
		return Mage::getSingleton(Df_Index_Model_Settings::mf());
	}
	/**
	 * @return Df_Localization_Model_Settings
	 */
	public function localization() {
		return Mage::getSingleton(Df_Localization_Model_Settings::mf());
	}
	/**
	 * @return Df_Logging_Model_Settings
	 */
	public function logging() {
		return Mage::getSingleton(Df_Logging_Model_Settings::mf());
	}
	/**
	 * @return Df_Newsletter_Model_Settings
	 */
	public function newsletter() {
		return Mage::getSingleton(Df_Newsletter_Model_Settings::mf());
	}
	/**
	 * @return Df_Promotion_Model_Settings
	 */
	public function promotion() {
		return Mage::getSingleton(Df_Promotion_Model_Settings::mf());
	}
	/**
	 * @return Df_Reward_Model_Settings
	 */
	public function reward() {
		return Mage::getSingleton(Df_Reward_Model_Settings::mf());
	}
	/**
	 * @return Df_Reports_Model_Settings
	 */
	public function reports() {
		return Mage::getSingleton(Df_Reports_Model_Settings::mf());
	}
	/**
	 * @return Df_Sales_Model_Settings
	 */
	public function sales() {
		return Mage::getSingleton(Df_Sales_Model_Settings::mf());
	}
	/**
	 * @return Df_Seo_Model_Settings
	 */
	public function seo() {
		return Mage::getSingleton(Df_Seo_Model_Settings::mf());
	}
	/**
	 * @return Df_Shipping_Model_Settings
	 */
	public function shipping() {
		return Mage::getSingleton(Df_Shipping_Model_Settings::mf());
	}
	/**
	 * @return Df_Sms_Model_Settings
	 */
	public function sms() {
		return Mage::getSingleton(Df_Sms_Model_Settings::mf());
	}
	/**
	 * @return Df_Speed_Model_Settings
	 */
	public function speed() {
		return Mage::getSingleton(Df_Speed_Model_Settings::mf());
	}
	/**
	 * @return Df_Torg12_Model_Settings
	 */
	public function torg12() {
		return Mage::getSingleton(Df_Torg12_Model_Settings::mf());
	}
	/**
	 * @return Df_Tweaks_Model_Settings
	 */
	public function tweaks() {
		return Mage::getSingleton(Df_Tweaks_Model_Settings::mf());
	}
	/**
	 * @return Df_Vk_Model_Settings
	 */
	public function vk() {
		return Mage::getSingleton(Df_Vk_Model_Settings::mf());
	}
	/**
	 * @return Df_YandexMarket_Model_Settings
	 */
	public function yandexMarket() {
		return Mage::getSingleton(Df_YandexMarket_Model_Settings::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}