<?php
class Df_Admin_Model_Settings_Admin_Promotions extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function getFixProductsSubselection() {
		return $this->getYesNo('df_tweaks_admin/promotions/fix_products_subselection');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}