<?php
class Df_Admin_Model_Settings_Admin_Sales_Customers extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function getEnableWebsiteChanging() {
		return $this->getYesNo('df_tweaks_admin/sales_customers/enable_website_changing');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}