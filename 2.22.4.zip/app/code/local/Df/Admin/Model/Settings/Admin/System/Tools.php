<?php
class Df_Admin_Model_Settings_Admin_System_Tools extends Df_Core_Model_Settings {
	/**
	 * @return Df_Admin_Model_Settings_Admin_System_Tools_Compilation
	 */
	public function compilation() {
		return Mage::getSingleton(Df_Admin_Model_Settings_Admin_System_Tools_Compilation::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}