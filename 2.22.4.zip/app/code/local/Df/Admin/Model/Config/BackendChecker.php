<?php
abstract class Df_Admin_Model_Config_BackendChecker
	extends Df_Core_Model_Abstract {
	abstract protected function checkInternal();

	/**
	 * @return Df_Admin_Model_Config_BackendChecker
	 */
	public function check() {
		try {
			$this->checkInternal();
		}
		catch(Exception $e) {
			rm_session()->addError($e->getMessage());
		}
		return $this;
	}

	/**
	 * @return Df_Admin_Model_Config_Backend
	 */
	protected function getBackend() {
		/** @var Df_Admin_Model_Config_Backend $result */
		$result = $this->cfg(self::PARAM__BACKEND);
		df_assert($result instanceof Df_Admin_Model_Config_Backend);
		return $result;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(
				self::PARAM__BACKEND, Df_Admin_Model_Config_Backend::_CLASS
			)
		;
	}

	const PARAM__BACKEND = 'backend';
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

}