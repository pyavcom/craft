<?php
abstract class Df_Admin_Model_Config_Extractor extends Df_Core_Model_Abstract {
	/**
	 * @abstract
	 * @return string
	 */
	abstract protected function getEntityName();

	/**
	 * @param string $fieldNameUniqueSuffix
	 * @return bool
	 */
	protected function getYesNo($fieldNameUniqueSuffix) {
		return rm_parse_yes_no($this->getValue($fieldNameUniqueSuffix));
	}

	/**
	 * @param string $fieldNameUniqueSuffix
	 * @param string $defaultValue[optional]
	 * @return string
	 */
	protected function getValue($fieldNameUniqueSuffix, $defaultValue = Df_Core_Const::T_EMPTY) {
		df_param_string($fieldNameUniqueSuffix, 0);
		/** @var string $result */
		$result =
			Mage::getStoreConfig(
				df()->config()->implodeKey(
					array(
						$this->getConfigGroupPath()
						,$this->implode(
							df_clean(
								array(
									$this->getConfigKeyPrefix()
									,$this->getEntityName()
									,$fieldNameUniqueSuffix
								)
							)
						)
					)
				)
				,$this->getStore()
			)
		;
		if (is_null($result)) {
			$result = $defaultValue;
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @param string $fieldNameUniqueSuffix
	 * @return string
	 */
	private function composePath($fieldNameUniqueSuffix) {
		df_param_string($fieldNameUniqueSuffix, 0);
		/** @var string $result */
		$result =
			df()->config()->implodeKey(
				array(
					$this->getConfigGroupPath()
					,$this->implode(
						df_clean(
							array(
								$this->getConfigKeyPrefix()
								,$this->getEntityName()
								,$fieldNameUniqueSuffix
							)
						)
					)
				)
			)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getConfigGroupPath() {
		return $this->cfg(self::PARAM__CONFIG_GROUP_PATH);
	}

	/**
	 * @return string
	 */
	private function getConfigKeyPrefix() {
		return $this->cfg(self::PARAM__CONFIG_KEY_PREFIX);
	}

	/**
	 * @return Mage_Core_Model_Store
	 */
	private function getStore() {
		/** @var Mage_Core_Model_Store $result */
		$result =
			Mage::app()->getStore(
				$this->cfg(self::PARAM__STORE)
			)
		;
		df_assert($result instanceof Mage_Core_Model_Store);
		return $result;
	}

	/**
	 * @param string[] $configKeyParts
	 * @return string
	 */
	private function implode(array $configKeyParts) {
		return implode(self::T__CONFIG_PARTS_SEPARATOR, $configKeyParts);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->addValidator(
				self::PARAM__CONFIG_KEY_PREFIX,	new Df_Zf_Validate_String()
			)
			->addValidator(
				self::PARAM__CONFIG_GROUP_PATH,	new Df_Zf_Validate_String()
			)
			->validateClass(
				self::PARAM__STORE,	Df_Core_Const::STORE_CLASS,	false
			)
		;
	}

	const _CLASS = __CLASS__;
	const PARAM__CONFIG_GROUP_PATH = 'config_group_path';
	const PARAM__CONFIG_KEY_PREFIX = 'config_key_prefix';
	const PARAM__STORE = 'store';
	const T__CONFIG_PARTS_SEPARATOR = '__';

	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}