<?php
class Df_Admin_Model_Resource_User extends Mage_Admin_Model_Mysql4_User {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf_r(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_Admin_Model_Resource_User
	 */
	public static function s() {
		return Mage::getResourceSingleton(self::mf());
	}
}