<?php
/**
 * Cообщение:		«df_catalog__attribute_set__group_added»
 *
 * Источник:		Df_Catalog_Helper_Product::addGroupToAttributeSetIfNeeded()
 * [code]
 * [/code]
 */
class Df_Catalog_Model_Event_AttributeSet_GroupAdded extends Df_Core_Model_Event {
	/**
	 * @return int
	 */
	public function getAttributeSetId() {
		/** @var int $result */
		$result = intval($this->getEventParam(self::EVENT_PARAM__ATTRIBUTE_SET_ID));
		df_result_between($result, 1);
		return $result;
	}

	/**
	 * @return Df_Eav_Model_Entity_Attribute_Set
	 */
	public function getAttributeSet() {
		if (!isset($this->_attributeSet)) {
			$this->_attributeSet =
				Df_Eav_Model_Entity_Attribute_Set::ld(
					$this->getAttributeSetId()
				)
			;
		}
		return $this->_attributeSet;
	}
	/** @var Df_Eav_Model_Entity_Attribute_Set */
	private $_attributeSet;	


	/**
	 * @return int
	 */
	public function getGroupName() {
		return $this->getEventParam(self::EVENT_PARAM__GROUP_NAME);
	}	


	/**
	 * @override
	 * @return string
	 */
	protected function getExpectedEventPrefix() {
		return self::EVENT;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

	const EVENT = 'df_catalog__attribute_set__group_added';
	const EVENT_PARAM__ATTRIBUTE_SET_ID = 'attribute_set_id';
	const EVENT_PARAM__GROUP_NAME = 'group_name';
}