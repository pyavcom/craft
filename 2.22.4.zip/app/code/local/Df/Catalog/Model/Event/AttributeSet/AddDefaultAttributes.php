<?php
/**
 * Cообщение:		«df_catalog__attribute_set__add_default_attributes»
 *
 * Источник:		Df_Catalog_Model_Installer_AttributeSet::addAttributesDefault()
 * [code]
		Mage
			::dispatchEvent(
				Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes::EVENT
				,array(
					Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes
						::EVENT_PARAM__ATTRIBUTE_SET => $attributeSet
				)
			)
		;
 * [/code]
 */
class Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes extends Df_Core_Model_Event {
	/**
	 * @return Mage_Eav_Model_Entity_Attribute_Set
	 */
	public function getAttributeSet() {
		/** @var Mage_Eav_Model_Entity_Attribute_Set $result */
		$result = $this->getEventParam(self::EVENT_PARAM__ATTRIBUTE_SET);
		df_assert($result instanceof Mage_Eav_Model_Entity_Attribute_Set);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getExpectedEventPrefix() {
		return self::EVENT;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

	const EVENT = 'df_catalog__attribute_set__add_default_attributes';
	const EVENT_PARAM__ATTRIBUTE_SET = 'attribute_set';
}