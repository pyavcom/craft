<?php
class Df_Catalog_Model_Settings_Navigation extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function getEnabled() {
		return $this->getYesNo('df_tweaks/illustrated_catalog_navigation/enabled');
	}
	/**
	 * @return int
	 */
	public function getNumberOfColumns() {
		return $this->getInteger('df_tweaks/illustrated_catalog_navigation/number_of_columns');
	}
	/**
	 * @return string
	 */
	public function getPosition() {
		return $this->getString('df_tweaks/illustrated_catalog_navigation/position');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}