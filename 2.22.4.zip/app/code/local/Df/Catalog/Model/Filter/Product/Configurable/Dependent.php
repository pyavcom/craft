<?php
/**
 * Возвращает коллекцию товаров-элементов
 * для данного товара системного типа Configurable
 */
class Df_Catalog_Model_Filter_Product_Configurable_Dependent
	extends Df_Core_Model_Abstract
	implements Zend_Filter_Interface {
	/**
	 * @override
	 * @param mixed $value
	 * @throws Zend_Filter_Exception If filtering $value is impossible
	 * @return Df_Varien_Data_Collection
	 */
	public function filter($value) {
		df_assert($value instanceof Mage_Catalog_Model_Product);
		/** @var Mage_Catalog_Model_Product $value */
		$dependentProducts =
			$this->getConfigurableTypeInstance()
				->getUsedProducts(null, $value)
		;
		/** @var array $dependentProducts */
		$result = Df_Varien_Data_Collection::createFromCollection($dependentProducts);
		/** @var Df_Varien_Data_Collection $result */
		df_assert($result instanceof Df_Varien_Data_Collection);
		return $result;
	}

	/**
	 * @return Df_Catalog_Model_Product_Type_Configurable
	 */
	private function getConfigurableTypeInstance() {
		if (!isset($this->_configurableTypeInstance)) {
			$this->_configurableTypeInstance = Df_Catalog_Model_Product_Type_Configurable::i();
		}
		return $this->_configurableTypeInstance;
	}
	/**
	 * @var Df_Catalog_Model_Product_Type_Configurable
	 */
	private $_configurableTypeInstance;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Catalog_Model_Filter_Product_Configurable_Dependent
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}