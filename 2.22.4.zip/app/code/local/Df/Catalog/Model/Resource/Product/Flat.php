<?php
class Df_Catalog_Model_Resource_Product_Flat
	extends Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Flat {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf_r(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_Catalog_Model_Resource_Product_Flat
	 */
	public static function s() {
		return Mage::getResourceSingleton(self::mf());
	}
}