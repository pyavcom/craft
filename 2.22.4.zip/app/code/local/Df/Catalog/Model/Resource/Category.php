<?php
class Df_Catalog_Model_Resource_Category extends Mage_Catalog_Model_Resource_Eav_Mysql4_Category {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf_r(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_Catalog_Model_Resource_Category
	 */
	public static function s() {
		return Mage::getResourceSingleton(self::mf());
	}
}