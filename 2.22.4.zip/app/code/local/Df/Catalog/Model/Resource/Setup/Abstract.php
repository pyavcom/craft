<?php
abstract class Df_Catalog_Model_Resource_Setup_Abstract
	extends Mage_Catalog_Model_Resource_Eav_Mysql4_Setup {
	/**
	 * @override
	 * @return Df_Catalog_Model_Resource_Setup_Abstract
	 */
	public function startSetup() {
		parent::startSetup();
		/** @var Df_Core_Model_Lib $libCore */
		$libCore = Mage::getSingleton('df_core/lib');
		$libCore->init();
		/** @var Df_Core_Model_Lib $libZf */
		$libZf = Mage::getSingleton('df_zf/lib');
		$libZf->init();
		return $this;
	}

	/**
	 * @return string
	 */
	public function getGeneralGroupName() {
		return $this->_generalGroupName;
	}
}


