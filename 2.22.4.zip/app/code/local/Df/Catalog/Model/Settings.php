<?php
class Df_Catalog_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return Df_Catalog_Model_Settings_Navigation
	 */
	public function navigation() {
		return Mage::getSingleton(Df_Catalog_Model_Settings_Navigation::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}