<?php
class Df_Catalog_Model_Installer_AddAttributeToSet extends Df_Core_Model_Abstract {
	/**
	 * Метод возвращает статус операции.
	 * @see Df_Catalog_Model_Resource_Setup::addAttributeToSetRm
	 * @return string
	 */
	public function process() {
		/**
		 * Этот метод добавляет группу только по необходимости (при её отсутствии)
		 */
		df_helper()->catalog()->product()
			->addGroupToAttributeSetIfNeeded(
				$this->getSetId()
				,$this->getGroupName()
			)
		;
		$result =
			df_helper()->catalog()->getSetup()
				->addAttributeToSetRm(
					self::getEntityTypeId()
					,$this->getSetId()
					,$this->getGroupName()
					,$this->getAttributeCode()
					,$this->getOrdering()
				)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getAttributeCode() {
		return $this->cfg(self::PARAM__ATTRIBUTE_CODE);
	}

	/**
	 * @return string
	 */
	private function getGroupName() {
		return $this->cfg(self::PARAM__GROUP_NAME, self::GROUP_NAME__GENERAL);
	}

	/**
	 * @return int|null
	 */
	private function getOrdering() {
		return $this->cfg(self::PARAM__ORDERING);
	}

	/**
	 * @return int
	 */
	private function getSetId() {
		return $this->cfg(self::PARAM__SET_ID);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->addValidator(
				self::PARAM__GROUP_NAME, new Df_Zf_Validate_String(), $isRequired = false
			)
			->addValidator(self::PARAM__ATTRIBUTE_CODE, new Df_Zf_Validate_String())
			->addValidator(self::PARAM__SET_ID, new Df_Zf_Validate_Int())
			->addValidator(self::PARAM__ORDERING, new Df_Zf_Validate_Int(), $isRequired = false)
		;
	}

	const _CLASS = __CLASS__;
	const GROUP_NAME__GENERAL = 'General';
	const PARAM__ATTRIBUTE_CODE = 'attribute_code';
	const PARAM__ORDERING = 'ordering';
	const PARAM__SET_ID = 'set_id';
	const PARAM__GROUP_NAME = 'group_name';

	/**
	 * @static
	 * @return int
	 */
	private static function getEntityTypeId() {
		return df_helper()->catalog()->eav()->getProductEntity()->getTypeId();
	}
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Catalog_Model_Installer_AddAttributeToSet
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

	/**
	 * Метод возвращает статус операции.
	 * @see Df_Catalog_Model_Resource_Setup::addAttributeToSetRm
	 *
	 * @param string $attributeCode
	 * @param int $setId
	 * @param string $groupName
	 * @param int $ordering[optional]
	 * @return string
	 */
	public static function processStatic($attributeCode, $setId, $groupName, $ordering = null) {
		df_param_string($attributeCode, 0);
		df_param_integer($setId, 1);
		df_param_string($groupName, 2);
		if (!is_null($ordering)) {
			df_param_integer($ordering, 3);
		}
		$result =
			self::i(
				array(
					self::PARAM__GROUP_NAME => $groupName
					,self::PARAM__ATTRIBUTE_CODE => $attributeCode
					,self::PARAM__SET_ID => $setId
					,self::PARAM__ORDERING => $ordering
				)
			)->process();
		df_result_string($result);
		return $result;
	}
}