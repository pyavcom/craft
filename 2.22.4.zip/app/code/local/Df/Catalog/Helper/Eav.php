<?php
class Df_Catalog_Helper_Eav extends Mage_Catalog_Helper_Data {
	/**
	 * @return Df_Eav_Model_Entity
	 */
	public function getProductEntity() {
		if (!isset($this->_productEntity)) {
			$this->_productEntity = Df_Eav_Model_Entity::i();
			$this->_productEntity->setType('catalog_product');
		}
		return $this->_productEntity;
	}
	/** @var Df_Eav_Model_Entity */
	private $_productEntity;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}