<?php
class Df_Catalog_Helper_Data extends Mage_Core_Helper_Abstract {
	/**
	 * @return Df_Catalog_Helper_Assert
	 */
	public function assert() {
		return Mage::helper(Df_Catalog_Helper_Assert::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Category
	 */
	public function category() {
		return Mage::helper(Df_Catalog_Helper_Category::mf());
	}	

	/**
	 * @return Df_Catalog_Helper_Check
	 */
	public function check() {
		return Mage::helper(Df_Catalog_Helper_Check::mf());
	}

	/**
	 * @return Df_Catalog_Model_Resource_Setup
	 */
	public function getSetup() {
		/** @var Df_Catalog_Model_Resource_Setup $result */
		static $result;
		if (!isset($result)) {
			/** @var Df_Catalog_Model_Resource_Setup $result */
			$result =
				Mage::getResourceModel(
					Df_Catalog_Model_Resource_Setup::mf()
					,'df_catalog_setup'
				)
			;
			df_assert($result instanceof Df_Catalog_Model_Resource_Setup);
		}
		return $result;
	}

	/**
	 * @return Df_Catalog_Helper_Eav
	 */
	public function eav() {
		return Mage::helper(Df_Catalog_Helper_Eav::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Product
	 */
	public function product() {
		return Mage::helper(Df_Catalog_Helper_Product::mf());
	}

	/**
	 * @return Df_Catalog_Helper_Product_Dataflow
	 */
	public function product_dataflow() {
		return Mage::helper(Df_Catalog_Helper_Product_Dataflow::mf());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}