<?php
class Df_Catalog_Helper_Category extends Mage_Core_Helper_Abstract {
	/**
	 * Перед созданием и сохранением товарного раздела
	 * надо обязательно надо установить текущим магазином административный, * иначе возникают неприятные проблемы.
	 *
	 * В частности, для успешного сохранения товарного раздела
	 * надо отключить на время сохранения режим денормализации.
	 * Так вот, в стандартном программном коде Magento автоматически отключает
	 * режим денормализации при создании товарного раздела из административного магазина
	 * (в конструкторе товарного раздела).
	 *
	 * А если сохранять раздел, чей конструктор вызван при включенном режиме денормализации —
	 * то произойдёт сбой:
	 *
	 * SQLSTATE[23000]: Integrity constraint violation:
	 * 1452 Cannot add or update a child row:
	 * a foreign key constraint fails
	 * (`catalog_category_flat_store_1`,
	 * CONSTRAINT `FK_CAT_CTGR_FLAT_STORE_1_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID`
	 * FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`en)
	 *
	 * @param array $data
	 * @param int $storeId
	 * @return Df_Catalog_Model_Category
	 * @throws Exception
	 */
	public function createAndSave(array $data, $storeId) {
		/** @var Df_Catalog_Model_Category $result */
		$result = null;
		/** @var Mage_Core_Model_Store $currentStore */
		$currentStore = Mage::app()->getStore();
		Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);
		try {
			/** @var Df_Catalog_Model_Category $result */
			$result = Df_Catalog_Model_Category::i($data);
			$result->setStoreId($storeId);
			$result->save();
		}
		catch(Exception $e) {
			Mage::app()->setCurrentStore($currentStore);
			throw $e;
		}
		Mage::app()->setCurrentStore($currentStore);
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}