<?php
class Df_Cdek_Model_Request_Rate extends Df_Cdek_Model_Request {
	/**
	 * @return int
	 */
	public function getDeliveryTimeMax() {
		$this->responseFailureDetect();
		/** @var int $result */
		$result = intval(df_a($this->getResponseSuccessData(), 'deliveryPeriodMax'));
		return $result;
	}

	/**
	 * @return int
	 */
	public function getDeliveryTimeMin() {
		$this->responseFailureDetect();
		/** @var int $result */
		$result = intval(df_a($this->getResponseSuccessData(), 'deliveryPeriodMin'));
		return $result;
	}

	/**
	 * @return float
	 */
	public function getRate() {
		$this->responseFailureDetect();
		/** @var float $result */
		$result = floatval(df_a($this->getResponseSuccessData(), 'price'));
		return $result;
	}

	/**
	 * @return int
	 */
	public function getServiceId() {
		$this->responseFailureDetect();
		/** @var int $result */
		$result = intval(df_a($this->getResponseSuccessData(), 'tariffId'));
		return $result;
	}

	/**
	 * @override
	 * @return array(string => string)
	 */
	protected function getHeaders() {
		return array_merge(parent::getHeaders(), array('Content-Type' => 'application/json'));
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getPostRawData() {
		return
			/**
			 * Zend_Json::encode использует json_encode при наличии расширения PHP JSON
			 * и свой внутренний кодировщик при отсутствии расширения PHP JSON.
			 * @see Zend_Json::encode
			 * @link http://stackoverflow.com/questions/4402426/json-encode-json-decode-vs-zend-jsonencode-zend-jsondecode
			 * Обратите внимание,
			 * что расширение PHP JSON не входит в системные требования Magento.
			 * @link http://www.magentocommerce.com/system-requirements
			 * Поэтому использование Zend_Json::encode выглядит более правильным, чем json_encode.
			 */
			Zend_Json::encode(array_merge(array('version' => '1.0'), $this->getPostParameters()))
		;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getQueryPath() {
		return '/calculator/calculate_price_by_json.php';
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getRequestMethod() {
		return Zend_Http_Client::POST;
	}

	/**
	 * @override
	 * @return bool
	 */
	protected function needLogNonExceptionErrors() {
		return false;
	}

	/**
	 * @override
	 * @return Df_Shipping_Model_Request
	 */
	protected function responseFailureDetectInternal() {
		/** @var mixed[][]|null $errors */
		$errors = df_a($this->getResponseAsArray(), 'error');
		if (!is_null($errors))  {
			df_assert_array($errors);
			df_assert_between(count($errors), 1);
			/** @var string[] $messages */
			$messages = array();
			foreach ($errors as $error) {
				/** @var mixed[] $error */
				df_assert_array($error);
				/** @var string $message */
				$message = df_a($error, 'text');
				df_assert_string($message);
				$messages[]= $message;
			}
			$this->responseFailureHandle(implode("\n", $messages));
		}
		return $this;
	}

	/**
	 * @return mixed[][]
	 */
	private function getResponseAsArray() {
		if (!isset($this->_responseAsArray)) {
			/** @var mixed[][] $result */
			$result =
				/**
				 * Zend_Json::decode использует json_decode при наличии расширения PHP JSON
				 * и свой внутренний кодировщик при отсутствии расширения PHP JSON.
				 * @see Zend_Json::decode
				 * @link http://stackoverflow.com/questions/4402426/json-encode-json-decode-vs-zend-jsonencode-zend-jsondecode
				 * Обратите внимание,
				 * что расширение PHP JSON не входит в системные требования Magento.
				 * @link http://www.magentocommerce.com/system-requirements
				 * Поэтому использование Zend_Json::decode выглядит более правильным, чем json_decode.
				 */
				Zend_Json::decode($this->getResponseAsText())
			;
			df_result_array($result);
			$this->_responseAsArray = $result;
		}
		return $this->_responseAsArray;
	}
	/** @var mixed[][] */
	private $_responseAsArray;

	/**
	 * Обратите внимание, что по состоянию 2013-06-10 API не рассчитал стоимость доставки
	 * из Санкт-Петербурга в Могилёв-Подольский, а вот калькулятор на сайте СДЭК — рассчитал
	 * @override
	 * @return string
	 */
	protected function getResponseAsTextInternal() {
		return
			/**
			 * Сервер СДЭК может давать сбой:
			 * Notice: Undefined variable: data in
			 * /var/www/api/calculator/library_calculate_price/CalculateDelivery.php on line 202
			 */
			preg_replace(
				"#Notice:[^\n]+\n#"
				,Df_Core_Const::T_EMPTY
				,parent::getResponseAsTextInternal()
			)
		;
	}

	/**
	 * @return mixed[]
	 */
	private function getResponseSuccessData() {
		/** @var mixed[] $result */
		$result = df_a($this->getResponseAsArray(), 'result');
		df_result_array($result);
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Cdek_Model_Request_Rate
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), array(self::PARAM__POST_PARAMS => $parameters));
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}