<?php
class Df_Cdek_Model_Location extends Df_Shipping_Model_Location {
	/**
	 * @return string
	 */
	public function getCity() {
		if (!isset($this->_city)) {
			$this->_city = $this->normalizeName($this->cfg(self::PARAM__CITY));
		}
		return $this->_city;
	}
	/** @var string */
	private $_city;

	/**
	 * @return string
	 */
	public function getCountry() {
		return df_nts($this->cfg(self::PARAM__COUNTRY));
	}

	/**
	 * @override
	 * @return int
	 */
	public function getId() {
		return intval($this->cfg(self::PARAM__ID));
	}

	/**
	 * @override
	 * @return string
	 */
	public function getRegion() {
		if (!isset($this->_region)) {
			/** @var string $result */
			$result = null;
			if (in_array($this->getCity(), $this->normalizeName(array('Минск')))) {
				$result = $this->getCity();
			}
			else {
				$result = $this->normalizeRegionName($this->cfg(self::PARAM__REGION));
			}
			$this->_region = $result;
		}
		return $this->_region;
	}
	/** @var string */
	private $_region;

	/**
	 * @override
	 * @param string $name
	 * @return string
	 */
	public function normalizeNameSingle($name) {
		return
			parent::normalizeNameSingle(
				df_trim(
					/**
					 * СДЭК может вернуть название населенного пункта в формате
					 * «Киев, Киевская обл., Украина»
					 * @link http://api.edostavka.ru/city/getListByTerm/jsonp.php?q=Киев
					 */
					df_array_first(explode(',', $name))
				)
			)
		;
	}

	const _CLASS = __CLASS__;
	const PARAM__CITY = 'cityName';
	const PARAM__COUNTRY = 'countryName';
	const PARAM__ID = 'id';
	const PARAM__NAME = 'name';
	const PARAM__REGION = 'regionName';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Cdek_Model_Location
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}