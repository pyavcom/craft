<?php
/**
 * @method Df_Cdek_Model_Config_Area_Service service()
 */
class Df_Cdek_Model_Config_Facade extends Df_Shipping_Model_Config_Facade {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}