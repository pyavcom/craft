<?php
class Df_Chronopay_Model_Gate_Config extends Varien_Object {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

	/**
	 * @param string $field
	 * @param string|null $default[optional]
	 * @return string|null
	 */
	public function getParam($field, $default = null) {
		$result =
			$this->getPaymentModel()->getConfigData($field, null)
		;
		return
				(is_null($result))
			?
				$default
			:
				$result
		;
	}

	/**
	 * @return Df_Chronopay_Model_Gate
	 */
	private function getPaymentModel() {
		return
			Mage::getSingleton("df_chronopay/gate")
		;
	}

	/**
	 * @return string
	 */
	public function getSiteId()
	{
		return $this->getParam('site_id');
	}

	/**
	 * @return string
	 */
	public function getProductId()
	{
		return $this->getParam('product_id');
	}

	/**
	 * @return string
	 */
	public function getSharedSecret()
	{
		return $this->getParam('shared_sec');
	}

	/**
	 * @return string
	 */
	public function getDescription() {
		return $this->getParam('description');
	}

	/**
	 * @return string
	 */
	public function getNewOrderStatus()
	{
		return $this->getParam('order_status');
	}

	/**
	 * @return string
	 */
	public function getCurrency()
	{
		return $this->getParam('currency');
	}

	/**
	 * @return string
	 */
	public function getLanguage()
	{
		return $this->getParam('language');
	}
}