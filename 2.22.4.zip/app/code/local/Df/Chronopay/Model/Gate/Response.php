<?php
class Df_Chronopay_Model_Gate_Response extends Df_Core_Model_SimpleXml_Parser_Entity_Singleton {
	/**
	 * @return Df_Chronopay_Model_Gate_Response
	 */
	public function check() {
		if (0 != $this->getCode()) {
			df_log($this->getDiagnosticMessage());
			Mage::throwException($this->getDiagnosticMessage());
		}
		return $this;
	}

	/**
	 * @return int
	 */
	public function getCode() {
		if (!isset($this->_code)) {
			$this->_code = $this->descendI('code');
		}
		return $this->_code;
	}
	/** @var int */
	private $_code;

	/**
	 * @return string
	 */
	public function getDiagnosticMessage() {
		if (!isset($this->_diagnosticMessage)) {
			$this->_diagnosticMessage =
				implode(
					"\r\n"
					,array(
						'Error in capturing the payment via ChronoPay.'
						,'ChronoPay error code: ' . $this->getCode()
						, 'ChronoPay extended error code: ' . $this->getExtendedCode()
						, 'ChronoPay error message: ' . $this->getMessage()
						, 'ChronoPay extended error message: ' . $this->getExtendedMessage()
						, 'Transaction ID: ' . $this->getTransactionId()
					)
				)
			;
		}
		return $this->_diagnosticMessage;
	}
	/** @var string */
	private $_diagnosticMessage;

	/**
	 * @return string
	 */
	public function getExtendedCode() {
		if (!isset($this->_extendedCode)) {
			$this->_extendedCode = $this->descendS('Extended/code');
		}
		return $this->_extendedCode;
	}
	/** @var string */
	private $_extendedCode;

	/**
	 * @return string
	 */
	public function getExtendedMessage() {
		if (!isset($this->_extendedMessage)) {
			$this->_extendedMessage = $this->descendS('Extended/message');
		}
		return $this->_extendedMessage;
	}
	/** @var string */
	private $_extendedMessage;

	/**
	 * @return string
	 */
	public function getMessage() {
		if (!isset($this->_message)) {
			$this->_message = $this->descendS('message');
		}
		return $this->_message;
	}
	/** @var string */
	private $_message;

	/**
	 * @return int
	 */
	public function getTransactionId() {
		if (!isset($this->_transactionId)) {
			$this->_transactionId = $this->descendI('Transaction');
		}
		return $this->_transactionId;
	}
	/** @var int */
	private $_transactionId;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param string $xml
	 * @return Df_Chronopay_Model_Gate_Response
	 */
	public static function i($xml) {
		return df_model(self::mf(), array(self::PARAM__SIMPLE_XML => $xml));
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}