<?php
class Df_Chronopay_Model_Gate_Card extends Df_Core_Model_Abstract {
	/**
	 * @return string
	 */
	public function getBankName() {
		return "Bnuu";
	}

	/**
	 * @return string
	 */
	public function getBankPhone() {
		return "+14564967654321";
	}

	/**
	 * @return int
	 */
	public function getCvv() {
		return $this->getPayment()->getCcCid();
	}

	/**
	 * @return string
	 */
	public function getExpirationDate() {
		return
			sprintf(
				"%4d%02d"
				,$this->getPayment()->getCcExpYear()
				,$this->getPayment()->getCcExpMonth()
			)
		;
	}

	/**
	 * @return int
	 */
	public function getNumber() {
		return $this->getPayment()->getCcNumber();
	}

	/**
	 * @return Mage_Payment_Model_Info
	 */
	private function getPayment() {
		return $this->_getData(self::PARAM__PAYMENT);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(
				self::PARAM__PAYMENT, self::PARAM__PAYMENT_TYPE
			)
		;
	}
	const _CLASS = __CLASS__;
	const PARAM__PAYMENT = 'payment';
	const PARAM__PAYMENT_TYPE = 'Mage_Payment_Model_Info';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Chronopay_Model_Gate_Card
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}