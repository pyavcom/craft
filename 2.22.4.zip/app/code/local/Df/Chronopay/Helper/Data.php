<?php
class Df_Chronopay_Helper_Data extends Mage_Core_Helper_Abstract {
	/**
	 * @return Df_Chronopay_Helper_Cardholder_Name_Converter_Config
	 */
	public function cartholderNameConversionConfig() {
		return Mage::helper(Df_Chronopay_Helper_Cardholder_Name_Converter_Config::mf());
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}

}