<?php
class Df_Autolux_Model_Method_ToPointOfIssue extends Df_Autolux_Model_Method {
	/**
	 * @override
	 * @return string
	 */
	public function getMethod() {
		return 'to-point-of-issue';
	}

	/**
	 * @override
	 * @return bool
	 */
	protected function needDeliverToHome() {
		return false;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}