<?php
class Df_Autolux_Model_Request_Rate extends Df_Autolux_Model_Request {
	/**
	 * @return float
	 */
	public function getFactorVolume() {
		/** @var float $result */
		$result = floatval(df_a($this->getResponseAsAssocArray(), 'volume'));
		return $result;
	}

	/**
	 * @return float
	 */
	public function getFactorWeight() {
		/** @var float $result */
		$result = floatval(df_a($this->getResponseAsAssocArray(), 'weight'));
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getQueryPath() {
		return '/Autolux/inc/Pages/PatternStd/img/rates.php';
	}

	/**
	 * @return mixed[]
	 */
	private function getResponseAsAssocArray() {
		if (!isset($this->_responseAsAssocArray)) {
			/** @var mixed[] $result */
			$result =
				/**
				 * Zend_Json::decode использует json_decode при наличии расширения PHP JSON
				 * и свой внутренний кодировщик при отсутствии расширения PHP JSON.
				 * @see Zend_Json::decode
				 * @link http://stackoverflow.com/questions/4402426/json-encode-json-decode-vs-zend-jsonencode-zend-jsondecode
				 * Обратите внимание,
				 * что расширение PHP JSON не входит в системные требования Magento.
				 * @link http://www.magentocommerce.com/system-requirements
				 * Поэтому использование Zend_Json::decode выглядит более правильным, чем json_decode.
				 */
				Zend_Json::decode(
					preg_replace('/\x{EF}\x{BB}\x{BF}/','', $this->getResponseAsText())
				)
			;
			df_result_array($result);
			$this->_responseAsAssocArray = $result;
		}
		return $this->_responseAsAssocArray;
	}
	/** @var mixed[] */
	private $_responseAsAssocArray;

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Autolux_Model_Request_Rate
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), array(self::PARAM__QUERY_PARAMS => $parameters));
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}