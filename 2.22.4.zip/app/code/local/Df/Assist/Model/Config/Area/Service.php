<?php
class Df_Assist_Model_Config_Area_Service extends Df_Payment_Model_Config_Area_Service {
	/**
	 * @override
	 * @return string
	 */
	public function getUrlPaymentPage() {
		/** @var string $result */
		$result = $this->getUrl(self::KEY__CONST__URL__PAYMENT_PAGE);
		df_result_string($result);
		return $result;
	}
	/**
	 * @return string
	 */
	private function getDomain() {
		/** @var string $result */
		$result =
			$this->isTestMode()
			? $this->getConst(self::KEY__CONST__DOMAIN)
			: $this->getVar(self::KEY__VAR__DOMAIN)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @param string $type
	 * @return string
	 */
	private function getUrl($type) {
		df_assert_string($type);
		/** @var string $path */
		$path =
			df_concat(
				Df_Core_Const::T_URL_PATH_SEPARATOR
				,$this->getConstManager()->getUrl($type, false)
			)
		;
		/** @var Zend_Uri_Http $uri */
		$uri = Zend_Uri::factory();
		df_assert($uri instanceof Zend_Uri_Http);
		$uri->setHost($this->getDomain());
		$uri->setPath($path);
		/** @var string $result */
		$result = $uri->getUri();
		df_result_string($result);
		return $result;
	}

	const _CLASS = __CLASS__;
	const KEY__CONST__URL__PAYMENT_PAGE = 'payment_page';
	const KEY__CONST__DOMAIN = 'domain';
	const KEY__VAR__DOMAIN = 'domain';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}