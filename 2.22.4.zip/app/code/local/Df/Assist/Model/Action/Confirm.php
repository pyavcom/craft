<?php
class Df_Assist_Model_Action_Confirm extends Df_Payment_Model_Action_Confirm {
	/**
	 * Использовать getConst нельзя из-за рекурсии.
	 * @override
	 * @return string
	 */
	protected function getRequestKeyOrderIncrementId() {
		return 'ordernumber';
	}

	/**
	 * @override
	 * @param Exception $e
	 * @return string
	 */
	protected function getResponseTextForError(Exception $e) {
		return $this->getResponseBlockForError($e)->toHtml();
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getResponseTextForSuccess() {
		return $this->getResponseBlockForSuccess()->toHtml();
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getSignatureFromOwnCalculations() {
		/** @var string $result */
		$result =
			strtoupper(
				md5(
					strtoupper(
						df_concat(
							md5($this->getResponsePassword())
							,md5(
								df_concat(
									$this->getRequestValueShopId()
									,$this->getRequestValueOrderIncrementId()
									,$this->getRequestValuePaymentAmountAsString()
									,$this->getRequestValuePaymentCurrencyCode()
									,$this->getRequestValueServicePaymentState()
								)
							)
						)
					)
				)
			)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @param Exception $e
	 * @return Df_Assist_Block_Api_PaymentConfirmation_Error
	 */
	private function getResponseBlockForError(Exception $e) {
		if (!isset($this->_responseBlockForError)) {
			$this->_responseBlockForError =
				df_block(
					Df_Assist_Block_Api_PaymentConfirmation_Error::mf()
					,null
					,array(
						Df_Assist_Block_Api_PaymentConfirmation_Error::PARAM__EXCEPTION => $e
					)
				)
			;
		}
		return $this->_responseBlockForError;
	}
	/** @var Df_Assist_Block_Api_PaymentConfirmation_Error */
	private $_responseBlockForError;	

	/**
	 * @return Df_Assist_Block_Api_PaymentConfirmation_Success
	 */
	private function getResponseBlockForSuccess() {
		if (!isset($this->_responseBlockForSuccess)) {
			$this->_responseBlockForSuccess =
				df_block(
					Df_Assist_Block_Api_PaymentConfirmation_Success::mf()
					,null
					,array(
						Df_Assist_Block_Api_PaymentConfirmation_Success::PARAM__BILL_NUMBER =>
							$this->getRequestValueServicePaymentId()
						,Df_Assist_Block_Api_PaymentConfirmation_Success::PARAM__PACKET_DATE =>
							$this->getRequestValueServicePaymentDate()
					)
				)
			;
		}
		return $this->_responseBlockForSuccess;
	}
	/** @var Df_Assist_Block_Api_PaymentConfirmation_Success */
	private $_responseBlockForSuccess;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Assist_Model_Action_Confirm
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}