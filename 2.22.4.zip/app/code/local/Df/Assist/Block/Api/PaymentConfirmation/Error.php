<?php
class Df_Assist_Block_Api_PaymentConfirmation_Error extends Df_Core_Block_Template {
	/**
	 * @return int
	 */
	public function getFirstCode() {
		return 1;
	}

	/**
	 * @return int
	 */
	public function getSecondCode() {
		return 0;
	}

	/**
	 * @override
	 * @return string
	 */
	public function getTemplate() {
		return self::RM__TEMPLATE;
	}

	/**
	 * @return Exception
	 */
	private function getException() {
		/** @var Exception $result */
		$result = $this->cfg(self::PARAM__EXCEPTION);
		df_assert($result instanceof Exception);
		return $result;
	}

	const _CLASS = __CLASS__;
	const PARAM__EXCEPTION = 'exception';
	const RM__TEMPLATE = 'df/assist/api/payment-confirmation/error.xml';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}