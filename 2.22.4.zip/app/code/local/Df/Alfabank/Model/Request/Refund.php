<?php
class Df_Alfabank_Model_Request_Refund extends Df_Alfabank_Model_Request_Secondary {
	/**
	 * @return Df_Core_Model_Money
	 */
	public function getAmount() {
		if (!isset($this->_amount)) {
			$this->_amount =
				Df_Core_Model_Money::i(
					df_helper()->directory()->currency()->convertFromBaseToRoubles(
						$amount = $this->cfg(self::PARAM__AMOUNT)
						,$store = $this->getOrderPayment()->getOrder()->getStore()
					)
				)
			;
		}
		return $this->_amount;
	}
	/** @var Df_Core_Model_Money */
	private $_amount;

	/**
	 * @return array(string => string|int|float)
	 */
	protected function getAdditionalParams() {
		return array('amount' => intval(round(100 * $this->getAmount()->getAsFixedFloat())));
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getGenericFailureMessageUniquePart() {
		return 'возврате оплаты покупателю';
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getResponseClassMf() {
		return Df_Alfabank_Model_Response_Refund::mf();
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getServiceName() {
		return 'refund';
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->addValidator(self::PARAM__AMOUNT, new Df_Zf_Validate_Float());
	}
	const _CLASS = __CLASS__;
	const PARAM__AMOUNT = 'amount';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Alfabank_Model_Request_Refund
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}


