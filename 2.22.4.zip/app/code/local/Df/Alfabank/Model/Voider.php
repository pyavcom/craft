<?php
class Df_Alfabank_Model_Voider extends Df_Payment_Model_Handler {
	/**
	 * @override
	 * @return Df_Alfabank_Model_Voider
	 * @throws Exception
	 */
	public function handleInternal() {
		$this->getResponse();
		return $this;
	}
	
	/**
	 * @return Df_Alfabank_Model_Request_Void
	 */
	private function getRequest() {
		if (!isset($this->_request)) {
			$this->_request =
				Df_Alfabank_Model_Request_Void::i(
					array(
						Df_Alfabank_Model_Request_Void::PARAM__PAYMENT_METHOD => $this->getMethod()
						,Df_Alfabank_Model_Request_Refund::PARAM__ORDER_PAYMENT => $this->getOrderPayment()
					)
				)
			;
		}
		return $this->_request;
	}
	/** @var Df_Alfabank_Model_Request_Void */
	private $_request;

	/**
	 * @return Df_Alfabank_Model_Response_Void
	 */
	private function getResponse() {
		return $this->getRequest()->getResponse();
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}