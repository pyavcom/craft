<?php
/**
 * @method Df_Alfabank_Model_Payment getPaymentMethod()
 */
class Df_Alfabank_Model_Action_CustomerReturn extends Df_Payment_Model_Action_Confirm {
	/**
	 * @override
	 * @return Df_Alfabank_Model_Action_CustomerReturn
	 */
	public function process() {
		try {
			if (!$this->getOrder()->canInvoice()) {
				/**
				 * Бывают платёжные системы (например, «Единая касса»),
				 * которые, согласно их документации,
				 * могут несколько раз присылать подтверждение оплаты покупателем
				 * одного и того же заказа.
				 *
				 * Так вот, данная проверка гарантирует, что платёжный модуль не будет пытаться
				 * принять повторно оплату за уже оплаченный заказ.
				 *
				 * Обратите внимание, что проверку заказа на оплаченность
				 * надо сделать до вызова метода checkPaymentAmount,
				 * потому что иначе требуемая к оплате сумма будет равна нулю,
				 * и checkPaymentAmount будет сравнивать сумму от платёжной системы с нулём.
				 */
				$this->processOrderCanNotInvoice();
			}
			else {
				$this->checkPaymentAmount();
				if (810 !== intval($this->getRequestValuePaymentCurrencyCode())) {
					df_error('Заказ был оплачен не в рублях');
				}
				/** @var Mage_Sales_Model_Order_Invoice $invoice */
				$invoice = $this->getOrder()->prepareInvoice();
				$invoice->register();
				/**
				 * Код «2» означает, что средства с карты покупателя были списаны.
				 * Код «1» означает, что средства с карты покупателя были зарезервированы.
				 * Обратите внимание, что при резервировании средств мы не вызываем $invoice->capture()
				 * (что переводило бы счёт в состояние «оплачен»),
				 * а вместо этого оставляем счёт в открытом состоянии,
				 * что даёт администратору возможность снять зарезервированные покупателем средства
				 * посредством администтративного интерфейса интернет-магазина:
				 * на странице счёта появляется кнопка «Принять оплату» («Capture»).
				 */
				if ($this->getResponseState()->isTransactionClosed()) {
					$invoice->capture();
				}
				/** @var Mage_Core_Model_Resource_Transaction $coreTransaction */
				$coreTransaction = df_model(Df_Core_Const::CORE_RESOURCE_TRANSACTION_CLASS_MF);
				$coreTransaction
					->addObject($invoice)
					->addObject($invoice->getOrder())
					->save()
				;
				$this->getOrder()
					->setState(
						Mage_Sales_Model_Order::STATE_PROCESSING
						,Mage_Sales_Model_Order::STATE_PROCESSING
						,sprintf(
							$this->getMessage(self::CONFIG_KEY__MESSAGE__SUCCESS)
							,$invoice->getIncrementId()
						)
						,true
					)
				;
				$this->getOrder()->save();
				$this->getOrder()->sendNewOrderEmail();
				$this->getResponse()->setRedirect(df_helper()->payment()->url()->getCheckoutSuccess());
				/**
				 * В отличие от метода
				 * @see Df_Payment_Model_Action_Confirm::process()
				 * здесь необходимость вызова unsetRedirected() не вызывает сомнений,
				 * потому что Df_Alfabank_Model_Action_CustomerReturn:process()
				 * обрабатывает именно сессию покупателя, а не запрос платёжной системы
				 */
				Df_Payment_Model_Redirector::s()->unsetRedirected();
			}
		}
		catch (Exception $e) {
			/** @var bool $isPaymentException */
			$isPaymentException = ($e instanceof Df_Payment_Exception_Client);
			if ($isPaymentException && isset($this->_requestState)) {
				$this->logException($e);
			}
			else {
				Mage::logException($e);
			}
			/**
			 * Обратите внимание,
			 * что при возвращении на страницу Df_Checkout_Const::URL__CHECKOUT
			 * диагностическое сообщение надо добавлять в df_mage()->core()->sessionSingleton(),
			 * а не в df_mage()->checkout()->sessionSingleton(),
			 * потому что сообщения сессии checkout
			 * не отображаются в стандартной теме на странице checkout/onepage
			 */
			df_mage()->core()->sessionSingleton()
				->addError(
					($e instanceof Df_Payment_Exception_Client)
					? strtr(
						$this->getPaymentMethod()->getRmConfig()->frontend()->getMessageFailure()
						,array(
							'{сообщение от платёжного шлюза}' => $e->getMessage()
						)
					)
					: $e->getMessage()
				)
			;
			$this->getResponse()->setRedirect(Mage::getUrl(Df_Checkout_Const::URL__CHECKOUT));
		}
		return $this;
	}

	/**
	 * @override
	 * @return Zend_Controller_Request_Abstract
	 */
	protected function getRequest() {
		if (!isset($this->_request)) {
			/** @var Zend_Controller_Request_Abstract $result */
			$this->_request = new Zend_Controller_Request_Http();
			$this->_request
				->setParams(
					array_merge(
						parent::getRequest()->getParams()
						,$this->getRequestState()->getResponse()->getData()
					)
				)
			;
		}
		return $this->_request;
	}
	/** @var Zend_Controller_Request_Abstract */
	private $_request;

	/**
	 * Использовать getConst нельзя из-за рекурсии.
	 * @override
	 * @return string
	 */
	protected function getRequestKeyOrderIncrementId() {
		return self::REQUEST_PARAM__ORDER_INCREMENT_ID;
	}

	/**
	 * @override
	 * @return float
	 */
	protected function getRequestValuePaymentAmountAsString() {
		return floatval(parent::getRequestValuePaymentAmountAsString() / 100);
	}

	/**
	 * @override
	 * @param Exception $e
	 * @return string
	 */
	protected function getResponseTextForError(Exception $e) {
		df_should_not_be_here(__METHOD__);
		return Df_Core_Const::T_EMPTY;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getResponseTextForSuccess() {
		df_should_not_be_here(__METHOD__);
		return Df_Core_Const::T_EMPTY;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getSignatureFromOwnCalculations() {
		df_should_not_be_here(__METHOD__);
		return Df_Core_Const::T_EMPTY;
	}

	/**
	 * @override
	 * @param Exception $e
	 * @return Df_Alfabank_Model_Action_CustomerReturn
	 */
	protected function processResponseForError(Exception $e) {
		$this->getResponse()->setRedirect(df_helper()->payment()->url()->getCheckoutFail());
		return $this;
	}
	
	/**
	 * @return Df_Alfabank_Model_Request_State
	 */
	private function getRequestState() {
		if (!isset($this->_requestState)) {
			$this->_requestState =
				Df_Alfabank_Model_Request_State::i(
					array(
						Df_Alfabank_Model_Request_State::PARAM__ORDER_PAYMENT =>
							$this->getOrder()->getPayment()
						,Df_Alfabank_Model_Request_State::PARAM__PAYMENT_METHOD =>
							$this->getPaymentMethod()
					)
				)
			;
		}
		return $this->_requestState;
	}
	/** @var Df_Alfabank_Model_Request_State */
	private $_requestState;

	/**
	 * @return Df_Alfabank_Model_Response_State
	 */
	private function getResponseState() {
		return $this->getRequestState()->getResponse();
	}
	
	const _CLASS = __CLASS__;
	const REQUEST_PARAM__ORDER_INCREMENT_ID = 'magentoOrderIncrementId';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Alfabank_Model_Action_CustomerReturn
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}