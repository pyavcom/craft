<?php
class Df_Autotrading_Model_Method extends Df_Shipping_Model_Method_CollectedManually {
	/**
	 * @override
	 * @return string
	 */
	public function getMethod() {
		return 'standard';
	}

	/**
	 * @override
	 * @return bool
	 * @throws Exception
	 */
	public function isApplicable() {
		/** @var bool $result */
		$result = parent::isApplicable();
		if ($result) {
			try {
				$this
					->checkCityDestinationIsNotEmpty()
					->checkCityOriginIsNotEmpty()
					->checkOriginAndDestinationCitiesAreDifferent()
				;
			}
			catch(Exception $e) {
				if ($this->needDisplayDiagnosticMessages()) {
					throw $e;
				}
				else {
					$result = false;
				}
			}
		}
		df_result_boolean($result);
		return $result;
	}

	/**
	 * @override
	 * @return int
	 */
	protected function getTimeOfDeliveryMax() {
		return intval(df_a($this->getTimeOfDeliveryAsArray(), 1));
	}

	/**
	 * @override
	 * @return int
	 */
	protected function getTimeOfDeliveryMin() {
		return intval(df_a($this->getTimeOfDeliveryAsArray(), 0));
	}

	/**
	 * @return int[]
	 */
	private function getTimeOfDeliveryAsArray() {
		if (!isset($this->_timeOfDeliveryAsArray)) {
			$this->_timeOfDeliveryAsArray =
				df_a(
					df_a(
						Df_Autotrading_DeliveryTimeMap::getData()
						,mb_strtoupper($this->getRequest()->getOriginCity())
						,array()
					)
					,mb_strtoupper($this->getRequest()->getDestinationCity())
					,array()
				)
			;
			df_result_array($this->_timeOfDeliveryAsArray);
		}
		return $this->_timeOfDeliveryAsArray;
	}
	/** @var int[] */
	private $_timeOfDeliveryAsArray;	

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}