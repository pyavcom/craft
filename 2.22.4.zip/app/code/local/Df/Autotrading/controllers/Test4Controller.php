<?php
class Df_Autotrading_Test4Controller extends Mage_Core_Controller_Front_Action {
	/**
	 * @return void
	 */
	public function indexAction() {
		try {
			/**
			 * Обратите внимание,
			 * что мы используем класс Zend_Http_Client, а не Varien_Http_Client,
			 * потому что применение Varien_Http_Client зачастую приводит к сбою:
			 * Error parsing body - doesn't seem to be a chunked message
			 *
			 * @var Zend_Http_Client $httpClient
			 */
			$httpClient = new Zend_Http_Client();
			/** @var Zend_Uri_Http $uri */
			$uri = Zend_Uri::factory('http');
			$uri->setHost('www.ae5000.ru');
			$uri->setPath('/api/');
			$uri
				->setQuery(
					array(
						'metod' => 'get_city'
						,'term' => 'Доне'
						,'jsoncallback' => 'callback'
					)
				)
			;
			$httpClient
				->setHeaders(
					array(
						'Accept' => 'application/json, text/javascript, */*; q=0.01'
						,'Accept-Encoding' => 'gzip, deflate'
						,'Accept-Language' => 'en-us,en;q=0.5'
						,'Connection' => 'keep-alive'
						,'Host' => 'www.ae5000.ru'
						,'Referer' => 'http://www.ae5000.ru/rates/calculate/'
						,'User-Agent' => Df_Core_Const::FAKE_USER_AGENT
						,'X-Requested-With' => 'XMLHttpRequest'
					)
				)
				->setUri($uri)
				->setConfig(array('timeout' => 10))
			;
			/** @var Zend_Http_Response $response */
			$response = $httpClient->request(Zend_Http_Client::GET);
			/** @var string $responseAsText */
			$responseAsText = $response->getBody();
			$responseAsJson = ltrim(rtrim($responseAsText, ')'), 'callback(');
			/** @var mixed[] $responseAsArray */
			$responseAsArray = Zend_Json::decode($responseAsJson);
			$this
				->getResponse()
				->setBody(
					print_r($responseAsArray, true)
				)
			;
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e, false);
			echo $e->getMessage();
		}
	}
}