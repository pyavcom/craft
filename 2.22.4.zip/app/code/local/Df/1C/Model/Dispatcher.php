<?php
class Df_1C_Model_Dispatcher extends Df_Core_Model_Abstract {
	/**
	 * @param Varien_Event_Observer $observer
	 * @return void
	 */
	public function df_catalog__attribute_set__group_added(
		Varien_Event_Observer $observer
	) {
		try {
			/** @var Df_Catalog_Model_Event_AttributeSet_GroupAdded $event */
			$event =
				df_event(
					Df_Catalog_Model_Event_AttributeSet_GroupAdded::mf()
					,$observer
				)
			;
			df_assert($event instanceof Df_Catalog_Model_Event_AttributeSet_GroupAdded);
			if (df_helper()->_1c()->cml2()->isItCml2Processing()) {
				df_helper()->_1c()
					->log(
						sprintf(
							'Добавили к прикладному типу товаров «%s» группу свойств «%s»'
							,$event->getAttributeSet()->getDataUsingMethod(
								Df_Eav_Model_Entity_Attribute_Set::PARAM__NAME
							)
							,$event->getGroupName()
						)
					)
				;
			}
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e);
		}
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}