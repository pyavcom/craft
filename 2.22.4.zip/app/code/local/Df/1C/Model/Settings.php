<?php
class Df_1C_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return Df_1C_Model_Settings_General
	 */
	public function general() {
		return Mage::getSingleton(Df_1C_Model_Settings_General::mf());
	}
	/**
	 * @return Df_1C_Model_Settings_Orders
	 */
	public function orders() {
		return Mage::getSingleton(Df_1C_Model_Settings_Orders::mf());
	}
	/**
	 * @return Df_1C_Model_Settings_Product
	 */
	public function product() {
		return Mage::getSingleton(Df_1C_Model_Settings_Product::mf());
	}
	/**
	 * @return Df_1C_Model_Settings_ReferenceLists
	 */
	public function referenceLists() {
		return Mage::getSingleton(Df_1C_Model_Settings_ReferenceLists::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}