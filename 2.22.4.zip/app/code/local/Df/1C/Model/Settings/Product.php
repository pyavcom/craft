<?php
class Df_1C_Model_Settings_Product extends Df_1C_Model_Settings_Cml2 {
	/**
	 * @return Df_1C_Model_Settings_Product_Description
	 */
	public function description() {
		return Mage::getSingleton(Df_1C_Model_Settings_Product_Description::mf());
	}
	/**
	 * @return Df_1C_Model_Settings_Product_Name
	 */
	public function name() {
		return Mage::getSingleton(Df_1C_Model_Settings_Product_Name::mf());
	}
	/**
	 * @return Df_1C_Model_Settings_Product_Other
	 */
	public function other() {
		return Mage::getSingleton(Df_1C_Model_Settings_Product_Other::mf());
	}
	/**
	 * @return Df_1C_Model_Settings_Product_Prices
	 */
	public function prices() {
		return Mage::getSingleton(Df_1C_Model_Settings_Product_Prices::mf());
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}