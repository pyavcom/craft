<?php
class Df_1C_Model_Settings_Product_Prices extends Df_1C_Model_Settings_Cml2 {
	/**
	 * @return string
	 */
	public function getMain() {
		return $this->getString('df_1c/product__prices/main');
	}
	/**
	 * @return array(int => string)
	 */
	public function getMapFromCustomerGroupIdToPriceTypeName() {
		if (!isset($this->_mapFromCustomerGroupIdToPriceTypeName)) {
			/** @var array(int => string) $result  */
			$result = array();
			/** @var string|null $mapSerialized */
			$mapSerialized = $this->getStringNullable('df_1c/product__prices/map');
			if (!df_empty($mapSerialized)) {
				df_assert_string($mapSerialized);
				/** @var array[] $map */
				$map = @unserialize($mapSerialized);
				if (is_array($map)) {
					foreach ($map as $mapItem) {
						/** @var string[] $mapItem */
						df_assert_array($mapItem);
						/** @var int $customerGroup */
						$customerGroup =
							intval(
								df_a(
									$mapItem
									,Df_1C_Block_System_Config_Form_Field_MapFromCustomerGroupToPriceType
										::COLUMN__CUSTOMER_GROUP
								)
							)
						;
						/** @var string $priceType */
						$priceType =
							df_nts(
								df_a(
									$mapItem
									,Df_1C_Block_System_Config_Form_Field_MapFromCustomerGroupToPriceType
										::COLUMN__PRICE_TYPE
								)
							)
						;
						df_assert_string($priceType);
						if ((0 !== $customerGroup) && !df_empty($priceType)) {
							$result[$customerGroup] = $priceType;
						}
					}
				}
			}
			df_result_array($result);
			$this->_mapFromCustomerGroupIdToPriceTypeName = $result;
		}
		return $this->_mapFromCustomerGroupIdToPriceTypeName;
	}
	/** @var array(int => string) */
	private $_mapFromCustomerGroupIdToPriceTypeName;

	/**
	 * @return array(string => Mage_Customer_Model_Group|null)
	 */
	public function getMapFromPriceTypeNameToCustomerGroup() {
		if (!isset($this->_mapFromPriceTypeNameToCustomerGroup)) {
			/** @var Mage_Customer_Model_Resource_Group_Collection $customerGroups */
			$customerGroups = Mage::getResourceModel('customer/group_collection');
			/** @var array(string => Mage_Customer_Model_Group|null) $result  */
			$result = array();
			foreach ($this->getMapFromPriceTypeNameToCustomerGroupId()
					 as $priceTypeName => $customerGroupId) {
				/** @var string $priceTypeName */
				/** @var int $customerGroupId */
				$result[$priceTypeName] = $customerGroups->getItemById($customerGroupId);
			}
			$this->_mapFromPriceTypeNameToCustomerGroup = $result;
		}
		return $this->_mapFromPriceTypeNameToCustomerGroup;
	}
	/** @var array(string => Mage_Customer_Model_Group|null) */
	private $_mapFromPriceTypeNameToCustomerGroup;

	/**
	 * @return array(string => int)
	 */
	public function getMapFromPriceTypeNameToCustomerGroupId() {
		if (!isset($this->_mapFromPriceTypeNameToCustomerGroupId)) {
			$this->_mapFromPriceTypeNameToCustomerGroupId =
				array_flip(
					$this->getMapFromCustomerGroupIdToPriceTypeName()
				)
			;
			/**
			 * При сбое array_flip может вернуть null
			 */
			df_result_array($this->_mapFromPriceTypeNameToCustomerGroupId);
		}
		return $this->_mapFromPriceTypeNameToCustomerGroupId;
	}
	/** @var array(string => int) */
	private $_mapFromPriceTypeNameToCustomerGroupId;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}