<?php
class Df_1C_Model_Settings_Product_Other extends Df_1C_Model_Settings_Cml2 {
	/**
	 * @return boolean
	 */
	public function showAttributesOnProductPage() {
		return $this->getYesNo('df_1c/product__other/attributes__show_on_product_page');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}