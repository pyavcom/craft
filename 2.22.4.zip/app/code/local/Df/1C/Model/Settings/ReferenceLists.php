<?php
class Df_1C_Model_Settings_ReferenceLists extends Df_1C_Model_Settings_Cml2 {
	/**
	 * @return string
	 */
	public function updateMode() {
		return $this->getString('df_1c/reference_lists/update_mode');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}