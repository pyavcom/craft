<?php
class Df_1C_Model_Settings_Product_Description extends Df_1C_Model_Settings_Cml2 {
	/**
	 * @return string
	 */
	public function getDefault() {
		return $this->getString('df_1c/product__description/default');
	}
	/**
	 * @return boolean
	 */
	public function preserveInUnique() {
		return $this->getYesNo('df_1c/product__description/preserve_if_unique');
	}
	/**
	 * @return string
	 */
	public function whichFieldToUpdate() {
		return $this->getString('df_1c/product__description/which_field_to_update');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}