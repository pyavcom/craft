<?php
class Df_1C_Model_Cml2_Import_Data_Collection_Orders
	extends Df_1C_Model_Cml2_Import_Data_Collection {
	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_Order::mf();
	}

	/**
	 * @override
	 * @return string[]
	 */
	protected function getItemsXmlPathAsArray() {
		return array(Df_Core_Const::T_EMPTY, 'КоммерческаяИнформация', 'Документ');
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param Varien_Simplexml_Element $element
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Orders
	 */
	public static function i(Varien_Simplexml_Element $element) {
		return df_model(self::mf(), array(self::PARAM__SIMPLE_XML => $element));
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}