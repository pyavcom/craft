<?php
class Df_1C_Model_Cml2_Export_Data_Entity_Customer extends Df_Core_Model_Abstract {
	/**
	 * @return string
	 */
	public function getDateOfBirthAsString() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			if ($this->getMagentoCustomer()->getDateOfBirth() instanceof Zend_Date) {
				$result =
					$this->getMagentoCustomer()->getDateOfBirth()->toString(
						Df_1C_Model_Cml2_SimpleXml_Generator_Document::DATE_FORMAT
					)
				;
			}
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getEmail() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result = $this->getMagentoCustomer()->getEmail();
		}
		if (df_empty($result)) {
			$result = $this->getMergedAddressWithShippingPriority()->getEmail();
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getGenderAsString() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result =
				df_nts(
					df_a(
						array(
							Df_Customer_Model_Customer::GENDER__FEMALE => 'F'
							,Df_Customer_Model_Customer::GENDER__MALE => 'M'
						)
						,$this->getMagentoCustomer()->getGender()
					)
				)
			;
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	public function getId() {
		/** @var string $result */
		$result =
			!is_null($this->getMagentoCustomer())
			? $this->getMagentoCustomer()->getId()
			: $this->getNameFull()
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getInn() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result = $this->getMagentoCustomer()->getInn();
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @return Df_Sales_Model_Order_Address
	 */
	public function getMergedAddressWithShippingPriority() {
		if (!isset($this->_mergedAddressWithShippingPriority)) {
			$this->_mergedAddressWithShippingPriority =
				Df_Sales_Model_Order_Address::i(
					df_merge_not_empty(
						$this->getOrder()->getBillingAddress()->getData()
						,$this->getOrder()->getShippingAddress()->getData()
					)
				)
			;
		}
		return $this->_mergedAddressWithShippingPriority;
	}
	/** @var Df_Sales_Model_Order_Address */
	private $_mergedAddressWithShippingPriority;

	/**
	 * @return string
	 */
	public function getNameFirst() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result = $this->getMagentoCustomer()->getNameFirst();
		}
		if (df_empty($result)) {
			$result = $this->getMergedAddressWithShippingPriority()->getFirstname();
		}
		$result = df_nts($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getNameFull() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result = $this->getMagentoCustomer()->getName();
		}
		if (df_empty($result)) {
			$result = $this->getMergedAddressWithShippingPriority()->getName();
		}
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getNameLast() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result = $this->getMagentoCustomer()->getNameLast();
		}
		if (df_empty($result)) {
			$result = $this->getMergedAddressWithShippingPriority()->getLastname();
		}
		$result = df_nts($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getNameMiddle() {
		/** @var string $result */
		$result = Df_Core_Const::T_EMPTY;
		if (!is_null($this->getMagentoCustomer())) {
			$result = $this->getMagentoCustomer()->getNameMiddle();
		}
		if (df_empty($result)) {
			$result = $this->getMergedAddressWithShippingPriority()->getMiddlename();
		}
		$result = df_nts($result);
		return $result;
	}

	/**
	 * @return string
	 */
	public function getNameShort() {
		return $this->getNameFull();
	}

	/**
	 * @return Df_Customer_Model_Customer|null
	 */
	private function getMagentoCustomer() {
		if (!isset($this->_magentoCustomer) && !$this->_magentoCustomerIsNull) {
			/** @var Df_Customer_Model_Customer|null $result */
			$result = null;
			if (!df_empty($this->getOrder()->getCustomerId())) {
				$result = Df_Customer_Model_Customer::ld($this->getOrder()->getCustomerId());
			}
			if (is_null($result)) {
				$this->_magentoCustomerIsNull = true;
			}
			else {
				df_assert($result instanceof Df_Customer_Model_Customer);
			}
			$this->_magentoCustomer = $result;
		}
		return $this->_magentoCustomer;
	}
	/** @var Df_Customer_Model_Customer|null */
	private $_magentoCustomer;
	/** @var bool */
	private $_magentoCustomerIsNull = false;

	/**
	 * @return Df_Sales_Model_Order
	 */
	private function getOrder() {
		return $this->cfg(self::PARAM__ORDER);
	}
	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->validateClass(self::PARAM__ORDER, Df_Sales_Model_Order::_CLASS);
	}
	const _CLASS = __CLASS__;
	const PARAM__ORDER = 'order';
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Export_Data_Entity_Customer
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}