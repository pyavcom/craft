<?php
class Df_1C_Model_Cml2_Registry_Attribute extends Df_Core_Model_Abstract {
	/**
	 * @param string $attributeLabel
	 * @return string
	 */
	public function generateImportedAttributeCodeByLabel($attributeLabel) {
		df_param_string($attributeLabel, 0);
		/** @var string $result */
		$result = null;
		/** @var int $counter */
		$attempt = 1;
		/** @var Df_Catalog_Model_Resource_Eav_Attribute $attribute */
		$attribute = Df_Catalog_Model_Resource_Eav_Attribute::i();
		while (true) {
			$result =
				$this->generateImportedAttributeCodeByLabelUsingSuffix(
					$attributeLabel
					,$attempt
				)
			;
			df_assert_string_not_empty($result);
			$attribute
				->loadByCode(
					df_helper()->eav()->getProductEntityTypeId()
					,$result
				)
			;
			if (1 > intval($attribute->getId())) {
				break;
			}
			$attribute->setData(array());
			$attempt++;
		};
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * @param string $attributeLabel
	 * @param int $attempt[optional]
	 * @return string
	 */
	private function generateImportedAttributeCodeByLabelUsingSuffix($attributeLabel, $attempt = 1) {
		df_param_string_not_empty($attributeLabel, 0);
		df_param_integer($attempt, 1);
		/** @var string $result */
		$result =
			substr(
				implode(
					'__'
					,array(
						'rm_1c'
						,strtr(
							df_output()->transliterate($attributeLabel)
							,array(
								'-' => '_'
							)
						)
					)
				)
				,0
				,(1 === $attempt)
				?
					Mage_Eav_Model_Entity_Attribute::ATTRIBUTE_CODE_MAX_LENGTH
				:
						Mage_Eav_Model_Entity_Attribute::ATTRIBUTE_CODE_MAX_LENGTH
					-
						(1 + mb_strlen(df_string($attempt)))
			)
		;
		if (1 < $attempt) {
			$result = implode('_', array($result, $attempt));
		}
		df_result_string_not_empty($result);
		return $result;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Registry_Attribute
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
	/**
	 * @static
	 * @return Df_1C_Model_Cml2_Registry_Attribute
	 */
	public static function s() {
		return Mage::getSingleton(self::mf());
	}
}