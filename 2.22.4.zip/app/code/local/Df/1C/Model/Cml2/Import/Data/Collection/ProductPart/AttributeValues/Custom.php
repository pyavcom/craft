<?php
class Df_1C_Model_Cml2_Import_Data_Collection_ProductPart_AttributeValues_Custom
	extends Df_1C_Model_Cml2_Import_Data_Collection {
	/**
	 * @override
	 * @param Varien_Simplexml_Element $entityAsSimpleXMLElement
	 * @return Df_1C_Model_Cml2_Import_Data_Entity
	 */
	protected function createItemFromSimpleXmlElement(Varien_Simplexml_Element $entityAsSimpleXMLElement) {
		/** @var mixed[] $elementAsArray */
		$elementAsArray = $entityAsSimpleXMLElement->asCanonicalArray();
		/**
		 * Varien_Simplexml_Element::asCanonicalArray может возвращать строку в случае,
		 * когда структура исходных данных не соответствует массиву.
		 */
		df_assert_array($elementAsArray);
		/** @var string|null $valueId */
		$valueId = df_a($elementAsArray, 'ИдЗначения');
		if (df_empty($valueId)) {
			/**
			 * В магазине sb-s.com.ua встречается такая конструкция:
			 *
	 			<ЗначенияСвойства>
					<Ид>6cc37c6d-7d15-11df-901f-00e04c595000</Ид>
					<Значение>6cc37c6e-7d15-11df-901f-00e04c595000</Значение>
				</ЗначенияСвойства>
			 *
			 * Похожую (но другую!) конструкцию встретил 11 июля 2013 года в магазине belle.com.ua:
				<ЗначенияСвойств>
					<ЗначенияСвойства>
						<Ид>dd6bfa58-d7e9-11d9-bfbc-00112f3000a2</Ид>
						<Значение>Розница</Значение>
					</ЗначенияСвойства>
				</ЗначенияСвойств>
			 *
			 * Обратите внимание, что в данном случае
			 * внутри тега «Значение» находится непосредственно значение,
			 * а не идентификатор значения, как в примере выше из магазина sb-s.com.ua.
			 *
			 * Причем соответствующее свойство описано в import.xml следующим образом:
				<Классификатор>
					(...)
					<Свойства>
						<СвойствоНоменклатуры>
							<Ид>dd6bfa58-d7e9-11d9-bfbc-00112f3000a2</Ид>
							<Наименование>Канал сбыта</Наименование>
							<Обязательное>false</Обязательное>
							<Множественное>false</Множественное>
							<ИспользованиеСвойства>true</ИспользованиеСвойства>
						</СвойствоНоменклатуры>
					</Свойства>
				</Классификатор>
			 *
			 * Обратите внимание на использование тега «СвойствоНоменклатуры»
			 * вместо стандартного тега «Свойство».
			 * Причём это происходит в типовой конфигурации
			 * «Управление торговлей для Украины» редации 2.3
			 * (редакция платформы 1С:Предприятие — 10.3)
			 */
			/** @var string $value */
			$value = df_a($elementAsArray, 'Значение');
			if (df_helper()->_1c()->cml2()->isExternalId($value)) {
				$valueId = $value;
			}
		}
		/** @var string $itemClassMf */
		$itemClassMf =
			df_empty($valueId)
			? Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom::mf()
			: Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom_Option::mf()
		;
		/** @var Df_1C_Model_Cml2_Import_Data_Entity $result */
		$result =
			df_model(
				$itemClassMf
				,array(
					Df_1C_Model_Cml2_Import_Data_Entity::PARAM__SIMPLE_XML => $entityAsSimpleXMLElement
					,Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom
						::PARAM__PRODUCT => $this->getProduct()
				)
			)
		;
		df_assert($result instanceof Df_1C_Model_Cml2_Import_Data_Entity);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom::mf();
	}

	/**
	 * @override
	 * @return string[]
	 */
	protected function getItemsXmlPathAsArray() {
		return array('ЗначенияСвойств', 'ЗначенияСвойства');
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Product
	 */
	private function getProduct() {
		return $this->cfg(self::PARAM__PRODUCT);
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->validateClass(self::PARAM__PRODUCT, Df_1C_Model_Cml2_Import_Data_Entity_Product::_CLASS);
	}
	const _CLASS = __CLASS__;
	const PARAM__PRODUCT = 'product';
	/**
	 * @static
	 * @param Varien_Simplexml_Element $element
	 * @param Df_1C_Model_Cml2_Import_Data_Entity_Product $product
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_ProductPart_AttributeValues_Custom
	 */
	public static function i(
		Varien_Simplexml_Element $element
		,Df_1C_Model_Cml2_Import_Data_Entity_Product $product
	) {
		return
			df_model(
				self::mf()
				,array(
					self::PARAM__SIMPLE_XML => $element
					,self::PARAM__PRODUCT => $product
				)
			)
		;
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}