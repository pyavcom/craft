<?php
class Df_1C_Model_Cml2_Import_Processor_Product_Part_Images
	extends Df_1C_Model_Cml2_Import_Processor_Product {
	/**
	 * @override
	 * @return Df_1C_Model_Cml2_Import_Processor
	 */
	public function process() {
		/** @var bool $needSave */
		$needSave = false;
		/** @var bool $needReload */
		$needReload = false;
		if (is_null($this->getExistingMagentoProduct())) {
			df_error(
				'Попытка импорта картинок для отсутствующего в системе товара «%s»'
				,$this->getEntityOffer()->getExternalId()
			);
		}
		df_assert(!is_null($this->getExistingMagentoProduct()));
		/** @var Df_Catalog_Model_Product $product */
		$product =
			Df_Catalog_Model_Product::i(
				$this->getExistingMagentoProduct()->getData()
			)
		;
		$product->deleteImages();
		/** @var bool $isPrimaryImage */
		$isPrimaryImage = true;
		foreach ($this->getEntityProduct()->getImages() as $image) {
			/** @var Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_Image $image */
			df_assert($image instanceof Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_Image);
			try {
				$product
					->addImageToMediaGallery(
						$image->getFilePathFull()
						,$isPrimaryImage ? Df_Catalog_Model_Product::getMediaAttributeNames() : null
						,false
						,false
					)
				;
			}
			catch (Exception $e) {
				df_log_exception($e);
				df_error(
					'При импорте товарного изображения для товара «%s» произошёл сбой: «%s».'
					,$product->getName()
					,$e->getMessage()
				);
			}
			$isPrimaryImage = false;
			df_helper()->_1c()
				->log(
					sprintf(
						'К товару «%s» добавлена картинка «%s».'
						,$product->getName()
						,$image->getFilePathRelative()
					)
				)
			;
			$needSave = true;
			/**
			 * Если после добавления к товару картинок не перезагрузить товар,
			 * то при повторном сохранении товара произойдёт исключительная ситуация
			 * (система будет пытаться повторно прикрепить те же самые картинки к товару).
			 * @todo Наверняка есть более правильное решение, чем перезагрузка товара.
			 */
			$needReload = true;
		}
		if ($needSave) {
			df_helper()->catalog()->product()->save($product, $isMassUpdate = true);
			df_helper()->_1c()
				->log(
					sprintf(
						'%s товар «%s».'
						,!is_null($this->getExistingMagentoProduct()) ? 'Обновлён' : 'Создан'
						,$product->getName()
					)
				)
			;
		}
		if ($needReload) {
			$product = df_helper()->catalog()->product()->reload($product);
		}
		if ($needSave) {
			/**
			 * Если система содержит другие магазины, кроме текущего
			 * (того, с которым сейчас выполняется обмен данными),
			 * то система, конечно, должна добавить товарное изображение
			 * только для текущего магазина.
			 * Однако в этом случае товарное изображение будет отсутствовать
			 * на витринной странице списка товаров:
			 * @link http://magento-forum.ru/topic/3783/
			 *
			 * Причиной отсутствия картиник на странице товарного изображения
			 * является недостаток (либо дефект, либо так было задумано с целью ускорения)
			 * Magento CE: если в системе несколько магазинов,
			 * и значение свойства задано только на уровне конкретного магазина,
			 * но не задано глобальное значение по умолчанию,
			 * то данное свойство не попадет в коллекцию.
			 * @see Mage_Catalog_Model_Resource_Collection_Abstract::_getLoadAttributesSelect
			 * Там используется LEFT JOIN, что и является причиной такого поведения.
			 *
			 * Хотел исправить данное поведение ядра (видимо, нужно FULL OUTER JOIN),
			 * но это показалось слишком трудоёмким.
			 * Вместо этого выбрал более простой путь:
			 * стал добавлять товарное изображение не только к текущему магазину,
			 * но и к глобальной области настроек.
			 */
			$this->addImagesToDefaultScopeIfNeeded($product);
			/**
			 * Раз уж мы добавили картинку к глобальной области настроек,
			 * то надо исключить ее показ из всех магазинов, за исключением текущего.
			 */
			$this->excludeImagesFromOtherStores($product);
		}
		df_helper()->dataflow()->registry()->products()->addEntity($product);
		return $this;
	}

	/**
	 * @param Df_Catalog_Model_Product $product
	 * @return Df_1C_Model_Cml2_Import_Processor_Product_Part_Images
	 */
	private function addImagesToDefaultScopeIfNeeded(Df_Catalog_Model_Product $product) {
		/** @var string[] $mediaAttributes */
		$mediaAttributes =
			array(
				'small_image'
				/**
				 * @link http://magento-forum.ru/topic/3941/
				 */
				,'thumbnail'
			)
		;
		/** @var Df_Catalog_Model_Product $productWithDefaultValues */
		$productWithDefaultValues = Df_Catalog_Model_Product::i();
		$productWithDefaultValues->setDataUsingMethod('store_id', Mage_Core_Model_App::ADMIN_STORE_ID);
		$productWithDefaultValues->load($product->getId());
		$productWithDefaultValues->deleteImages();
		/** @var string[] $attributesToUpdate */
		$attributesToUpdate = array();
		foreach ($mediaAttributes as $mediaAttribute) {
			/** @var string $mediaAttribute */
			if (df_empty($productWithDefaultValues->getData($mediaAttribute))) {
				$attributesToUpdate[]= $mediaAttribute;
			}
		}
		if (0 < count($attributesToUpdate)) {
			foreach ($attributesToUpdate as $mediaAttribute) {
				/** @var string $mediaAttribute */
				$productWithDefaultValues->setData($mediaAttribute, $product->getData($mediaAttribute));
			}
			df_helper()->catalog()->product()->save($productWithDefaultValues, $isMassUpdate = true);
		}
		return $this;
	}

	/**
	 * @param Df_Catalog_Model_Product $product
	 * @return Df_1C_Model_Cml2_Import_Processor_Product_Part_Images
	 */
	private function excludeImagesFromOtherStores(Df_Catalog_Model_Product $product) {
		/** @var int[] $storesToExcludeFrom */
		$storesToExcludeFrom =
			array_diff(
				$product->getStoreIds()
				,array($product->getStoreId())
			)
		;
		$storesToExcludeFrom []= Mage_Core_Model_App::ADMIN_STORE_ID;
		if (0 < count($storesToExcludeFrom)) {
			/** @var string[] $imageFileNames */
			$imageFileNames = array();
			/** @var Mage_Eav_Model_Entity_Attribute_Abstract[] $attributes */
			$attributes = $product->getTypeInstance()->getSetAttributes();
			df_assert_array($attributes);
			/** @var Mage_Eav_Model_Entity_Attribute_Abstract|null $mediaGalleryAttribute */
			$mediaGalleryAttribute = df_a($attributes, Df_Catalog_Model_Product::PARAM__MEDIA_GALLERY);
			if (!is_null($mediaGalleryAttribute)) {
				df_assert($mediaGalleryAttribute instanceof Mage_Eav_Model_Entity_Attribute_Abstract);
				/** @var Mage_Catalog_Model_Product_Attribute_Backend_Media $backend */
				$backend = $mediaGalleryAttribute->getBackend();
				df_assert($backend instanceof Mage_Catalog_Model_Product_Attribute_Backend_Media);
				if (is_array($product->getMediaGallery())) {
					$product->getMediaGalleryImages();
					/** @var array|null $images */
					$images = df_a($product->getMediaGallery(), 'images');
					if (is_array($images)) {
						foreach ($images as $image){
							/** @var string|null $fileName */
							$fileName = df_a($image, 'file');
							if (!df_empty($fileName)) {
								$imageFileNames[]= $fileName;
							}
						}
					}
				}
				if (0 < count($imageFileNames)) {
					foreach ($storesToExcludeFrom as $storeToExcludeFrom) {
						/** @var int $storeToExcludeFrom */
						/** @var $productWithScopedValues $productWithDefaultValues */
						$productWithScopedValues = Df_Catalog_Model_Product::i();
						$productWithScopedValues->setDataUsingMethod('store_id', $storeToExcludeFrom);
						$productWithScopedValues->load($product->getId());
						//$productWithScopedValues->deleteImages();
						foreach ($imageFileNames as $imageFileName) {
							$backend
								->updateImage(
									$productWithScopedValues
									,$imageFileName, array('exclude' => 1)
								)
							;
						}
						df_helper()->catalog()->product()->save($productWithScopedValues, $isMassUpdate = true);
					}
				}
			}
		}
		return $this;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Import_Processor_Product_Part_Images
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}