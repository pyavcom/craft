<?php
class Df_1C_Model_Cml2_Export_Processor_Order_Item extends Df_1C_Model_Cml2_Export_Processor {
	/**
	 * @return mixed[]
	 */
	public function getDocumentData() {
		if (!isset($this->_documentData)) {
			/** @var mixed[] $result */
			$result =
				array(
					'Ид' => $this->getProductExternalId()
					,'Наименование' => $this->getProductNameForExport()
					//$this->getProduct()->getName()
					,'БазоваяЕдиница' =>
						array(
							Df_Varien_Simplexml_Element::KEY__ATTRIBUTES =>
								array(
									'Код' => '796'
									,'НаименованиеПолное' => 'Штука'
									,'МеждународноеСокращение' => 'PCE'
								)
							,Df_Varien_Simplexml_Element::KEY__VALUE => 'шт'
						)
					,'ЦенаЗаЕдиницу' =>
						df_helper()->_1c()->formatMoney(
							$this->getOrderItemExtended()->getPrice()
						)
					,'Количество' => $this->getOrderItemExtended()->getQtyOrdered()
					,'Сумма' =>
						df_helper()->_1c()->formatMoney(
							/**
							 * getRowTotal — это без налогов и скидок
							 */
								$this->getOrderItemExtended()->getRowTotal()
							+
								$this->getOrderItemExtended()->getTaxAmount()
							-
								abs(
									$this->getOrderItemExtended()->getDiscountAmount()
								)
						)

					,'СтавкиНалогов' =>
						array(
							'СтавкаНалога' =>
								array(
									'Наименование' => 'НДС'
									,'Ставка' =>
										df_helper()->_1c()->formatMoney(
												100
											*
												$this->getOrderItemExtended()->getTaxAmount()
											/
												$this->getOrderItemExtended()->getRowTotal()
										)
								)
						)
					,'Налоги' =>
						array(
							'Налог' =>
								array(
									'Наименование' => 'НДС'

									,'УчтеноВСумме' => df_output()->convertBooleanToString(true)

									,'Сумма' =>
										df_helper()->_1c()->formatMoney(
											$this->getOrderItemExtended()->getTaxAmount()
										)
								)
						)
					,'Скидки' =>
						array(
							'Скидка' =>
								array(
									'Наименование' => 'Совокупная скидка'
									,'УчтеноВСумме' => df_output()->convertBooleanToString(true)
									,'Сумма' =>
										/**
										 * Magento хранит скидки в виде отрицательных чисел
										 */
										df_helper()->_1c()->formatMoney(
											abs(
												$this->getOrderItemExtended()->getDiscountAmount()
											)
										)
								)
						)
					,'ЗначенияРеквизитов' =>
						array(
							'ЗначениеРеквизита' =>
								array(
									array(
										'Наименование' => 'ВидНоменклатуры'
										,'Значение' => $this->getAttributeSetName()
									)
									,array(
										'Наименование' => 'ТипНоменклатуры'
										,'Значение' => 'Товар'
									)
								)
						)
				)
			;
			if ($this->isProductCreatedInMagento()) {
//				df_helper()->_1c()
//					->log(
//						'Товар создан в Magento: ' . $this->getProduct()->getName()
//					)
//				;
				/**
				 * Если товар был создан в Magento, * а не импортирован ранее из 1С:Управление торговлей, * то 1С:Управление торговлей импортирует его
				 * на основании указанной в документе-заказе информации.
				 *
				 * Поэтому постараемся здесь наиболее полно описать такие товары.
				 *
				 * К сожалению, 1С:Управление торговлей не воспринимает
				 * дополнительные характеристики таких товаров
				 * (например, мы не можем экспортировать описание товара)
				 */
				$result =
					array_merge_recursive(
						$result
						,array(
								 /*
							'Комментарий' =>
								implode(
									Df_Core_Const::T_NEW_LINE
									,array(
										implode(
											' = '
											,array(
												'Артикул'
												,$this->getProduct()->getSku()
											)
										)
										,implode(
											' = '
											,array(
												'№ строки заказа'
												,$this->getOrderItem()->getId()
											)
										)
									)
								)
									*/
							/**
							'Описание' =>
								array(
									Df_Varien_Simplexml_Element::KEY__ATTRIBUTES =>
										array(
											'ФорматHTML' => df_output()->convertBooleanToString(true)
										)
									,Df_Varien_Simplexml_Element::KEY__VALUE =>
										Df_Varien_Simplexml_Element::markAsCData(
											$this->getProduct()->getDescription()
										)
								)

							,'ЗначенияРеквизитов' =>
								array(
									'ЗначениеРеквизита' =>
										array(
											array(
												'Наименование' => 'Описание'
												,'Значение' =>
													Df_Varien_Simplexml_Element::markAsCData(
														$this->getProduct()->getDescription()
													)
											)
										)
								)
							 **/
						)
					)
				;
			}
			$this->_documentData = $result;
		}
		return $this->_documentData;
	}
	/** @var mixed[] */
	private $_documentData;

	/**
	 * @return string
	 */
	private function getAttributeSetName() {
		if (!isset($this->_attributeSetName)) {
			/** @var string $result */
			$result =
				Df_Eav_Model_Entity_Attribute_Set::ld(
					$this->getProduct()->getAttributeSetId()
				)->getAttributeSetName()
			;
			df_result_string_not_empty($result);
			$this->_attributeSetName = $result;
		}
		return $this->_attributeSetName;
	}
	/** @var string */
	private $_attributeSetName;	


	/**
	 * @return string
	 */
	private function getItemId() {
		return Df_Core_Const::T_EMPTY;
	}

	/**
	 * @return Df_Catalog_Model_Product
	 */
	private function getProduct() {
		if (!isset($this->_product)) {
			/** @var Df_Catalog_Model_Product $result */
			$result = 	
				df_helper()->_1c()->cml2()->registry()->export()->getProducts()
					->getProductById(
						intval($this->getOrderItem()->getProductId())
					)
			;
			df_assert($result instanceof Df_Catalog_Model_Product);
			$this->_product = $result;
		}
		return $this->_product;
	}
	/** @var Df_Catalog_Model_Product */
	private $_product;

	/**
	 * @return string
	 */
	private function getProductExternalId() {
		/** @var string $result */
		$result = df_nts($this->getProduct()->getData(Df_Eav_Const::ENTITY_EXTERNAL_ID));
		/**
		 * У товара может отсутствовать внешний идентификатор, если товар был создан в Magento.
		 * В таком случае мы не назначаем товару внешний идентификатор, * потому что 1С:Управление торговлей всё равно его проигнорирует
		 * и назначит свой идентификатор.
 		 */
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getProductNameForExport() {
		if (!isset($this->_productNameForExport)) {
			/** @var string $result */
			$result = $this->getProduct()->getName();
			df_assert_string($result);
			if ($this->isProductCreatedInMagento()) {
				/** @var array[] $productOptions */
				$productOptions = $this->getOrderItem()->getProductOptions();
				df_assert_array($productOptions);
				/** @var array[] $customOptions */
				$customOptions = df_a($productOptions, 'options', array());
				df_assert_array($customOptions);
				if (0 < count($customOptions)) {
					/** @var string[] $customOptionsKeyValuePairsAsText */
					$customOptionsKeyValuePairsAsText = array();
					foreach ($customOptions as $customOption) {
						/** @var string[] $customOption */
						df_assert_array($customOption);
						/** @var string $label */
						$label = df_a($customOption, 'label');
						df_assert_string($label);
						/** @var string $value */
						$value = df_a($customOption, 'value');
						df_assert_string($value);
						$customOptionsKeyValuePairsAsText[]=
							implode(' = ', array($label, $value))
						;
					}
					$result =
						sprintf(
							'%s {%s}'
							,$result
							,implode(', ', $customOptionsKeyValuePairsAsText)
						)
					;
				}
			}
			$this->_productNameForExport = $result;
		}
		return $this->_productNameForExport;
	}
	/** @var string */
	private $_productNameForExport;	


	/**
	 * @return Mage_Sales_Model_Order_Item
	 */
	private function getOrderItem() {
		return $this->cfg(self::PARAM__ORDER_ITEM);
	}

	/**
	 * @return Df_Sales_Model_Order_Item_Extended
	 */
	private function getOrderItemExtended() {
		if (!isset($this->_orderItemExtended)) {
			/** @var Df_Sales_Model_Order_Item_Extended $result */
			$result = 	
				Df_Sales_Model_Order_Item_Extended::create(
					$this->getOrderItem()
				)
			;
			df_assert($result instanceof Df_Sales_Model_Order_Item_Extended);
			$this->_orderItemExtended = $result;
		}
		return $this->_orderItemExtended;
	}
	/** @var Df_Sales_Model_Order_Item_Extended */
	private $_orderItemExtended;	


	/**
	 * @return bool
	 */
	private function isProductCreatedInMagento() {
		if (!isset($this->_productCreatedInMagento)) {
			$this->_productCreatedInMagento =
				df_empty(
					$this->getProductExternalId()
				)
			;
		}
		return $this->_productCreatedInMagento;
	}
	/** @var bool */
	private $_productCreatedInMagento;		


	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->validateClass(self::PARAM__ORDER_ITEM, 'Mage_Sales_Model_Order_Item')
		;
	}

	const _CLASS = __CLASS__;
	/**
	 * Значение 74 мы можем ставить без опаски, потому что 1С:Управление торговлей
	 * сама использует идентификаторы такой длины для вариантов настраиваемых товаров, например:
	 * b79b0fe2-c8a5-11e1-a928-4061868fc6eb#cb2b9d20-c97a-11e1-a928-4061868fc6eb
	 */
	const EXTERNAL_ID__MAX_LENGTH = 74;
	const EXTERNAL_ID__PREFIX_MAGENTO = 'magento';
	const PARAM__ORDER_ITEM = 'order_item';

	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Export_Processor_Order_Item
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}