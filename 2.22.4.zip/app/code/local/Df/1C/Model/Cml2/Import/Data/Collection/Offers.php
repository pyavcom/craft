<?php
class Df_1C_Model_Cml2_Import_Data_Collection_Offers
	extends Df_1C_Model_Cml2_Import_Data_Collection {
	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_Offer::mf();
	}

	/**
	 * @override
	 * @return string[]
	 */
	protected function getItemsXmlPathAsArray() {
		return
			array(
				Df_Core_Const::T_EMPTY
				,'КоммерческаяИнформация'
				,'ПакетПредложений'
				,'Предложения'
				,'Предложение'
			)
		;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Offers
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}