<?php
class Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom_Option
	extends Df_1C_Model_Cml2_Import_Data_Entity_ProductPart_AttributeValue_Custom {
	/**
	 * @override
	 * @return string
	 */
	public function getExternalId() {
		if (!isset($this->_externalId)) {
			/** @var string|null $result */
			$result = $this->getEntityParam('ИдЗначения');
			if (df_empty($result)) {
				/**
				 * В магазине sb-s.com.ua встречается такая конструкция:
				 *
		 			<ЗначенияСвойства>
						<Ид>6cc37c6d-7d15-11df-901f-00e04c595000</Ид>
						<Значение>6cc37c6e-7d15-11df-901f-00e04c595000</Значение>
					</ЗначенияСвойства>
				 */
				/** @var string|null $value */
				$value = $this->getEntityParam('Значение');
				if (df_helper()->_1c()->cml2()->isExternalId($value)) {
					$result = $value;
				}
			}
			df_result_string_not_empty($result);
			$this->_externalId = $result;
		}
		return $this->_externalId;
	}
	/** @var string */
	private $_externalId;	


	/**
	 * @override
	 * @return string
	 */
	public function getValue() {
		/** @var string $result */
		$result =
			is_null($this->getOption())
			?Df_Core_Const::T_EMPTY
			:$this->getOption()->getId()
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	public function getValueForDataflow() {
		/** @var string $result */
		$result =
			is_null($this->getOption())
			?Df_Core_Const::T_EMPTY
			:$this->getOption()->getData('value')
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @return Mage_Eav_Model_Entity_Attribute_Option|null
	 */
	private function getOption() {
		if (!isset($this->_option) && !$this->_optionIsNull) {
			/** @var Mage_Eav_Model_Entity_Attribute_Option|null $result */
			$result = null;
			df_assert(!is_null($this->getExternalId()));
			/** @var Df_Eav_Model_Resource_Entity_Attribute_Option_Collection $options */
			$options = Df_Eav_Model_Resource_Entity_Attribute_Option_Collection::i();
			$options->setPositionOrder('asc');
			$options->setAttributeFilter($this->getAttributeMagento()->getId());
			$options->setStoreFilter($this->getAttributeMagento()->getStoreId());
			$options->addFieldToFilter(Df_Eav_Const::ENTITY_EXTERNAL_ID, $this->getExternalId());
			if (1 > count($options)) {
				/**
				 * Из 1С:Управление торговлей в интернет-магазин передано справочное значение,
				 * отсутствующее в соответствующем справочнике интернет-магазина.
				 */
				df_helper()->_1c()->log(
					strtr(
						"Из «1С:Управление торговлей» в интернет-магазин передано "
						."значение «%value%» свойства «%attributeName%» («%attributeLabel%») "
						."для товара %productName% («%productSku%»), "
						."однако это значение не является допустимым "
						."для свойства «%attributeName%» («%attributeLabel%»).\n "
						."Такое могло произойти по причине наличия "
						."в «1С:Управление торговлей» нескольких одинаковых (дублирующих друг друга) "
						."значений для свойства «%attributeLabel%»."
						,array(
							'%value%' => $this->getExternalId()
							,'%attributeName%' => $this->getAttributeMagento()->getName()
							,'%attributeLabel%' => $this->getAttributeMagento()->getFrontendLabel()
							,'%productName%' => $this->getProduct()->getName()
							,'%productSku%' => $this->getProduct()->getSku()
						)
					)
				);
				/** @var Df_Eav_Model_Resource_Entity_Attribute_Option_Collection $optionsAll */
				$optionsAll = Df_Eav_Model_Resource_Entity_Attribute_Option_Collection::i();
				$optionsAll->setPositionOrder('asc');
				$optionsAll->setAttributeFilter($this->getAttributeMagento()->getId());
				$optionsAll->setStoreFilter($this->getAttributeMagento()->getStoreId());
				df_helper()->_1c()->log(
					strtr(
						'Допустимые значения свойства «%attributeName%» («%attributeLabel%»)'
						,array(
							'%attributeName%' => $this->getAttributeMagento()->getName()
							,'%attributeLabel%' => $this->getAttributeMagento()->getFrontendLabel()
						)
					)
				);
				foreach ($optionsAll as $option) {
					/** @var Mage_Eav_Model_Entity_Attribute_Option $option */
					df_helper()->_1c()->log(
						strtr(
							'«%optionLabel%» («%optionExternalId%»)'
							,array(
								'%optionLabel%' => $option->getData('value')
								,'%optionExternalId%' => $option->getData(Df_Eav_Const::ENTITY_EXTERNAL_ID)
							)
						)
					);
				}
			}
			else {
				$result = $options->fetchItem();
			}
			if (!is_null($result)) {
				df_assert($result instanceof Mage_Eav_Model_Entity_Attribute_Option);
			}
			else {
				$this->_optionIsNull = true;
			}
			$this->_option = $result;
		}
		return $this->_option;
	}
	/** @var Mage_Eav_Model_Entity_Attribute_Option|null */
	private $_option;
	/** @var bool */
	private $_optionIsNull = false;
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}