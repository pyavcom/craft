<?php
class Df_1C_Model_Cml2_Import_Data_Entity_Order extends Df_1C_Model_Cml2_Import_Data_Entity {
	/**
	 * @return string
	 */
	public function getIncrementId() {
		/** @var string $result */
		$result = $this->getEntityParam('Номер');
		df_result_string_not_empty($result);
		return $result;
	}

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Collection_Order_Items
	 */
	public function getItems() {
		if (!isset($this->_items)) {
			$this->_items = Df_1C_Model_Cml2_Import_Data_Collection_Order_Items::i($this->e(), $this);
		}
		return $this->_items;
	}
	/** @var Df_1C_Model_Cml2_Import_Data_Collection_Order_Items */
	private $_items;

	/**
	 * @return Df_Sales_Model_Order
	 */
	public function getOrder() {
		if (!isset($this->_order)) {
			$this->_order = Df_Sales_Model_Order::ldi($this->getIncrementId());
		}
		return $this->_order;
	}
	/** @var Df_Sales_Model_Order */
	private $_order;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}