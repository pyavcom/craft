<?php
class Df_1C_Model_Cml2_Import_Data_Entity_Attribute_Text
	extends Df_1C_Model_Cml2_Import_Data_Entity_Attribute {
	/**
	 * @override
	 * @return string
	 */
	public function getBackendModel() {
		return Df_Core_Const::T_EMPTY;
	}

	/**
	 * @override
	 * @return string
	 */
	public function getBackendType() {
		return 'varchar';
	}

	/**
	 * @override
	 * @return string
	 */
	public function getFrontendInput() {
		return 'text';
	}

	/**
	 * @override
	 * @return string
	 */
	public function getSourceModel() {
		return Df_Core_Const::T_EMPTY;
	}

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}