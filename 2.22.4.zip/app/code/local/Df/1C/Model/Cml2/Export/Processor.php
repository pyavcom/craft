<?php
class Df_1C_Model_Cml2_Export_Processor extends Df_Core_Model_Abstract {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}