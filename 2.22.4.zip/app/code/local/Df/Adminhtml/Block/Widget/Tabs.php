<?php
class Df_Adminhtml_Block_Widget_Tabs extends Mage_Adminhtml_Block_Widget_Tabs {
	/**
	 * @return string|null
	 */
	public function getTitle() {
		return $this->_getData(self::PARAM__TITLE);
	}

	/**
	 * @param string $value
	 * @return Df_Adminhtml_Block_Widget_Tabs
	 */
	public function setTitle($value) {
		$this->setData(self::PARAM__TITLE, $value);
		return $this;
	}

	const _CLASS = __CLASS__;
	const PARAM__TITLE = 'title';

	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}