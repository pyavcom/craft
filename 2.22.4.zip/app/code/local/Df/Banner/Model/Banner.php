<?php
class Df_Banner_Model_Banner extends Df_Core_Model_Abstract {
	/**
	 * @return int
	 */
	public function getDelay() {
		return intval($this->cfg(self::PARAM__DELAY));
	}

	/**
	 * @override
	 * @return Df_Banner_Model_Resource_Banner
	 */
	public function getResource() {
		return parent::getResource();
	}

	/**
	 * @return int
	 */
	public function getSizeHeight() {
		return intval($this->cfg(self::PARAM__SIZE__HEIGHT));
	}

	/**
	 * @return int
	 */
	public function getSizeWidth() {
		return intval($this->cfg(self::PARAM__SIZE__WIDTH));
	}

	/**
	 * @return string
	 */
	public function getTitle() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__TITLE);
		df_result_string($result);
		return $result;
	}

	/**
	 * @return bool
	 */
	public function isEnabled() {
		return (1 === intval($this->cfg(self::PARAM__IS_ENABLED)));
	}

	/**
	 * @return bool
	 */
	public function needShowTitle() {
		return (1 === intval($this->cfg(self::PARAM__NEED_SHOW_TITLE)));
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->_init(Df_Banner_Model_Resource_Banner::mf());
	}

	const _CLASS = __CLASS__;
	const PARAM__DELAY = 'delay';
	const PARAM__ID = 'banner_id';
	const PARAM__IS_ENABLED = 'status';
	const PARAM__NEED_SHOW_TITLE = 'show_title';
	const PARAM__SIZE__HEIGHT = 'height';
	const PARAM__SIZE__WIDTH = 'width';
	const PARAM__TITLE = 'title';

	/**
	 * @static
	 * @return Df_Banner_Model_Resource_Banner_Collection
	 */
	public static function c() {
		return Mage::getSingleton(self::mf())->getCollection();
	}
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Banner_Model_Banner
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}
	/**
	 * @static
	 * @param int|string $id
	 * @param string|null $field [optional]
	 * @return Df_Banner_Model_Banner
	 */
	public static function ld($id, $field = null) {
		return df_load(self::i(), $id, $field);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}