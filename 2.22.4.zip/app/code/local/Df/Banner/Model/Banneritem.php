<?php
class Df_Banner_Model_Banneritem extends Df_Core_Model_Abstract {
	/**
	 * @return string
	 */
	public function getContent() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__CONTENT, Df_Core_Const::T_EMPTY);
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string|null
	 */
	public function getImageFileName() {
		/** @var string|null $result */
		$result = $this->cfg(self::PARAM__IMAGE__FILE_NAME);
		if (!is_null($result)) {
			df_result_string($result);
		}
		return $result;
	}

	/**
	 * @return string|null
	 */
	public function getImageUrl() {
		/** @var string|null $result */
		$result = $this->cfg(self::PARAM__IMAGE__URL);
		if (!is_null($result)) {
			df_result_string($result);
		}
		return $result;
	}

	/**
	 * @override
	 * @return Df_Banner_Model_Resource_Banneritem
	 */
	public function getResource() {
		return parent::getResource();
	}

	/**
	 * @return string
	 */
	public function getTitle() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__TITLE);
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string|null
	 */
	public function getThumbnailFileName() {
		/** @var string|null $result */
		$result = $this->cfg(self::PARAM__THUMBNAIL__FILE_NAME);
		if (!is_null($result)) {
			df_result_string($result);
		}
		return $result;
	}

	/**
	 * @return string|null
	 */
	public function getThumbnailUrl() {
		/** @var string|null $result */
		$result = $this->cfg(self::PARAM__THUMBNAIL__URL);
		if (!is_null($result)) {
			df_result_string($result);
		}
		return $result;
	}

	/**
	 * @return string
	 */
	public function getUrl() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__URL);
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->_init(Df_Banner_Model_Resource_Banneritem::mf());
	}

	const _CLASS = __CLASS__;
	const PARAM__CONTENT = 'content';
	const PARAM__ID = 'banner_item_id';
	const PARAM__IMAGE__FILE_NAME = 'image';
	const PARAM__IMAGE__URL = 'image_url';
	const PARAM__TITLE = 'title';
	const PARAM__THUMBNAIL__FILE_NAME = 'thumb_image';
	const PARAM__THUMBNAIL__URL = 'thumb_image_url';
	const PARAM__URL = 'link_url';

	/**
	 * @static
	 * @return Df_Banner_Model_Resource_Banneritem_Collection
	 */
	public static function c() {
		return Mage::getSingleton(self::mf())->getCollection();
	}
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Banner_Model_Banneritem
	 */
	public static function i(array $parameters = array()) {
		return df_model(self::mf(), $parameters);
	}

	/**
	 * @static
	 * @param int|string $id
	 * @param string|null $field [optional]
	 * @return Df_Banner_Model_Banneritem
	 */
	public static function ld($id, $field = null) {
		return df_load(self::i(), $id, $field);
	}
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}