<?php
class Df_Banner_Model_Settings extends Df_Core_Model_Settings {
	/**
	 * @return boolean
	 */
	public function getEnabled() {
		return $this->getYesNo('df_promotion/banners/enabled');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}