<?php
class Df_Checkout_Model_Settings_Field extends Df_Core_Model_Settings {
	/**
	 * @param string $addressType
	 * @return Df_Checkout_Model_Settings_Field_Applicability
	 */
	public function getApplicabilityByAddressType($addressType) {
		df_param_string($addressType, 0);
		if (!isset($this->_applicabilityByAddressType[$addressType])) {
			$this->_applicabilityByAddressType[$addressType] =
				Df_Checkout_Model_Settings_Field_Applicability::i(
					array(
						Df_Checkout_Model_Settings_Field_Applicability
							::PARAM__ADDRESS_TYPE => $addressType
					)
				)
			;
		}
		return $this->_applicabilityByAddressType[$addressType];
	}
	/** @var Df_Checkout_Model_Settings_Field_Applicability[] */
	private $_applicabilityByAddressType;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}