<?php
class Df_Checkout_Model_Settings_Other extends Df_Core_Model_Settings {
	/**
	 * @return string
	 */
	public function getAlphabet() {
		return $this->getString('df_checkout/other/alphabet');
	}
	/**
	 * @return string
	 */
	public function getColorFailure() {
		return $this->getString('df_checkout/other/color__failure');
	}
	/**
	 * @return boolean
	 */
	public function canGetAddressFromYandexMarket() {
		return $this->getYesNo('df_checkout/other/can_get_address_from_yandex_market');
	}
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}