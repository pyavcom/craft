<?php
class Df_Checkout_Block_Frontend_Ergonomic_Address_Row extends Df_Core_Block_Abstract {
	/**
	 * @return Df_Checkout_Model_Collection_Ergonomic_Address_Field
	 */
	public function getFields() {
		if (!isset($this->_fields)) {
			$this->_fields = Df_Checkout_Model_Collection_Ergonomic_Address_Field::i();
		}
		return $this->_fields;
	}
	/** @var Df_Checkout_Model_Collection_Ergonomic_Address_Field */
	private $_fields;	


	/**
	 * @param string $fieldAsHtml
	 * @param string $fieldType
	 * @param int $ordering
	 * @param int $totalCount
	 * @return string
	 */
	public function wrapField($fieldAsHtml, $fieldType, $ordering, $totalCount) {
		/** @var string $result */
		$result =
//				$this->hasSingleField()
//			?
//				$fieldAsHtml
//			:
				Df_Core_Model_Format_Html_Tag::output(
					$fieldAsHtml
					,'div'
					,array(
						'class' =>
							df_output()->getCssClassesAsString(
								df_clean(
									array(
										'field'
										,($ordering === $totalCount)
											&&
												!$this->hasSingleField()
											?
												'df-field-last'
											:
												null
										,(1 === $ordering)
											&&
												!$this->hasSingleField()
											?
												'df-field-first'
											:
												null
										,sprintf(
											'df-field-%s'
											,$fieldType
										)
									)
								)
							)
					)
				)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @override
	 * @return string
	 */
	protected function _toHtml() {
		/** @var string $result */
		$result =
				(0 === $this->getFields()->count())
			?
				Df_Core_Const::T_EMPTY
			:
				Df_Core_Model_Format_Html_Tag::output(
					implode(
						"\n"
						,array_map(
							array($this, 'wrapField')
							,$this->getFields()->walk('toHtml')
							,$this->getFields()->walk('getType')
							,range(1, $this->getFields()->count())
							,df_array_fill(0, $this->getFields()->count(), $this->getFields()->count())
						)
					)
					,'li'
					,array(
						'class' => $this->getCssClassesAsText()
					)
				)
		;
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string
	 */
	private function getCssClassesAsText() {
		if (!isset($this->_cssClassesAsText)) {
			/** @var string $result */
			$result =
				df_output()->getCssClassesAsString(
					array(
							!$this->hasSingleField()
						?
							'fields'
						:
							'wide'
					)
				)
			;
			df_result_string($result);
			$this->_cssClassesAsText = $result;
		}
		return $this->_cssClassesAsText;
	}
	/** @var string */
	private $_cssClassesAsText;

	/**
	 * @return bool
	 */
	private function hasSingleField() {
		if (!isset($this->_singleField)) {
			$this->_singleField = (1 === $this->getFields()->count());
		}
		return $this->_singleField;
	}
	/** @var bool */
	private $_singleField;

	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}