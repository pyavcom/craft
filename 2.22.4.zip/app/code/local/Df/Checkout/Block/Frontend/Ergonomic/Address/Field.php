<?php
class Df_Checkout_Block_Frontend_Ergonomic_Address_Field extends Df_Core_Block_Template {
	/**
	 * @return string
	 */
	public function getApplicability() {
		if (!isset($this->_applicability)) {
			$this->_applicability = $this->getConfigValue('applicability');
			df_result_string($this->_applicability);
		}
		return $this->_applicability;
	}
	/** @var string */
	private $_applicability;	


	/**
	 * @return string
	 */
	public function getCssClassesAsText() {
		return df_output()->getCssClassesAsString($this->getCssClasses());
	}

	/**
	 * @return string
	 */
	public function getDomId() {
		if (!isset($this->_domId)) {
			$this->_domId = implode(':', array($this->getAddress()->getType(), $this->getType()));
		}
		return $this->_domId;
	}
	/** @var string */
	private $_domId;

	/**
	 * @return string
	 */
	public function getDomName() {
		if (!isset($this->_domName)) {
			$this->_domName = sprintf('%s[%s]', $this->getAddress()->getType(), $this->getType());
			df_result_string($this->_domName);
		}
		return $this->_domName;
	}
	/** @var string */
	private $_domName;	


	/**
	 * @return string
	 */
	public function getLabel() {
		return $this->escapeHtml(df_helper()->checkout()->__($this->_getData(self::PARAM__LABEL)));
	}

	/**
	 * @return string
	 */
	public function getLabelHtml() {
		if (!isset($this->_labelHtml)) {
			$this->_labelHtml =
				Df_Core_Model_Format_Html_Tag::output(
					df_concat(
						df_clean(
							array(
								($this->isRequired() ? '<em>*</em>' : null)
								,$this->getLabel()
							)
						)
					)
					,'label'
					,df_clean(
						array(
							'for' => $this->getDomId()
							,'class' => ($this->isRequired() ? 'required' : null)
						)
					)

				)
			;
		}
		return $this->_labelHtml;
	}
	/** @var string */
	private $_labelHtml;	

	/**
	 * @return int
	 */
	public function getOrderingInConfig() {
		return intval($this->cfg(self::PARAM__ORDERING_IN_CONFIG));
	}

	/**
	 * @return int
	 */
	public function getOrderingWeight() {
		if (!isset($this->_orderingWeight)) {
			$this->_orderingWeight = intval($this->getConfigValue('ordering'));
		}
		return $this->_orderingWeight;
	}
	/** @var int */
	private $_orderingWeight;

	/**
	 * @override
	 * @return string|null
	 */
	public function getTemplate() {
		/** @var string|null $result */
		$result =
			!$this->needToShow()
			? null
			:
				(
					/**
					 * Разработчик может указать шаблон поля в настроечном файле XML.
					 * Например:
					 *
					 * 	<customer_password>
							<template>df/checkout/ergonomic/address/field/password.phtml</template>
						</customer_password>
					 */
					$this->hasData(self::PARAM__TEMPLATE)
					? $this->_getData(self::PARAM__TEMPLATE)
					: $this->getDefaultTemplate()
				)
		;
		if (!is_null($result)) {
			df_result_string($result);
		}
		return $result;
	}

	/**
	 * public, потому что вызывается через walk
	 * @return string
	 */
	public function getType() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__TYPE);
		df_result_string($result);
		return $result;
	}

	/**
	 * @return mixed
	 */
	public function getValue() {
		return $this->getAddress()->getAddress()->getDataUsingMethod($this->getType());
	}

	/**
	 * @return bool
	 */
	public function isRequired() {
		return
			(
					Df_Checkout_Model_Config_Source_Field_Applicability::VALUE__REQUIRED
				===
					$this->getApplicability()
			)
		;
	}

	/**
	 * @override
	 * @return bool
	 */
	public function needToShow() {
		/** @var bool $result */
		$result =
				parent::needToShow()
			&&
				(
						Df_Checkout_Model_Config_Source_Field_Applicability::VALUE__NO
					!==
						$this->getApplicability()
				)
			&&
			 	$this->checkAuthenticationStatus()
		;
		return $result;
	}

	/**
	 * @return bool
	 */
	protected function checkAuthenticationStatus() {
		/** @var bool $result */
		$result =
				(self::PARAM__AUTHENTICATED__ANY === $this->getAuthenticated())
			||
				(
						df_mage()->customer()->isLoggedIn()
					&&
						(self::PARAM__AUTHENTICATED__YES === $this->getAuthenticated())
				)
			||
				(
						!df_mage()->customer()->isLoggedIn()
					&&
						(self::PARAM__AUTHENTICATED__NO === $this->getAuthenticated())
				)
		;
		return $result;
	}

	/**
	 * @return Df_Checkout_Block_Frontend_Ergonomic_Address
	 */
	protected function getAddress() {
		/** @var Df_Checkout_Block_Frontend_Ergonomic_Address $result */
		$result = $this->cfg(self::PARAM__ADDRESS);
		df_assert($result instanceof Df_Checkout_Block_Frontend_Ergonomic_Address);
		return $result;
	}

	/**
	 * Кто может видеть данное поле: авторизованные, неавторизованные или все
	 * @return string
	 */
	protected function getAuthenticated() {
		/** @var string $result */
		$result = $this->cfg(self::PARAM__AUTHENTICATED, self::PARAM__AUTHENTICATED__ANY);
		df_result_string($result);
		return $result;
	}

	/**
	 * Этот метод перекрывается в классе
	 * Df_Checkout_Block_Frontend_Ergonomic_Address_Field_Region_Dropdown
	 * @return string
	 */
	protected function getConfigShortKey() {
		/** @var string $result */
		$result = $this->getType();
		df_result_string($result);
		return $result;
	}

	/**
	 * @return string[]
	 */
	protected function getCssClasses() {
		return
			df_clean(
				array_merge(
					array($this->isRequired() ? 'required-entry' : null)
					,df_parse_csv(df_nts($this->cfg(self::PARAM__CSS_CLASSES)))
				)
			)
		;
	}

	/**
	 * @param string $paramName
	 * @return string
	 */
	private function getConfigValue($paramName) {
		df_param_string($paramName, 0);
		/** @var string $key */
		$key =
			df()->config()->implodeKey(
				array(
					sprintf(
						'df_checkout/%s_field_%s'
						,$this->getAddress()->getType()
						,$paramName
					)
					,$this->getConfigShortKey()
				)
			)
		;
		/** @var string $result */
		$result = Mage::getStoreConfig($key);
		df_assert(is_string($result), sprintf('Не могу прочитать значение настройки «%s»', $key));
		return $result;
	}

	const _CLASS = __CLASS__;
	const PARAM__ADDRESS = 'address';
	const PARAM__AUTHENTICATED = 'authenticated';
	const PARAM__AUTHENTICATED__ANY = 'any';
	const PARAM__AUTHENTICATED__NO = 'no';
	const PARAM__AUTHENTICATED__YES = 'yes';
	const PARAM__CSS_CLASSES = 'css-classes';
	const PARAM__LABEL = 'label';
	const PARAM__ORDERING_IN_CONFIG = 'ordering_in_config';
	const PARAM__TEMPLATE = 'template';
	const PARAM__TYPE = 'type';
	/**
	 * @static
	 * @return string
	 */
	public static function mf() {
		static $result; if (!isset($result)) {$result = rm_class_mf(__CLASS__);} return $result;
	}
}