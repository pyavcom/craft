tinyMCE.addI18n('en.simpleupload',{
	desc : 'Upload Image'
});
