tinyMCE.addI18n('ru.simpleupload_dlg',{
	title : 'Simple Upload for tinyMCE',
	file : 'File',
	select_image: 'Select Image',
	empty_file: 'File are Empty',
	not_valid_extension: 'File extension are not allowed',
	directory_not_writable : 'Directory not writable',
	error_moving_file : 'Error moving file!',
	max_allowed_filesize: 'Maximum allowed filesize'
});
