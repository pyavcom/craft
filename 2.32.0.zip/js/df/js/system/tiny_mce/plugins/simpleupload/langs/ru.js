tinyMCE.addI18n('ru.simpleupload',{
	desc : 'Upload Image'
});
