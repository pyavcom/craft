tinyMCE.addI18n('ru.codemagic',{
    editor_button: "Edit source code"
});