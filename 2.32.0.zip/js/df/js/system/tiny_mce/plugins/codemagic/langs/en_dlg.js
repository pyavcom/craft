tinyMCE.addI18n('en.codemagic_dlg',{
    code_title: "CodeMagic - syntax coloring and intendation",
    code_label: "Edit code",
    toggle_highlighting: "Syntax highlighting",
    toggle_autocompletion: "Auto completion",
    toggle_wraptext: "Wrap text",
    search: "Search",
    replace: "Replace",
    undo: "Undo",
    redo: "Redo",
    search_replace: "Search and Replace",
    reintendt: "Format HTML code",
    nothing_found: "Nothing found.",
    nothing_to_replace: "Nothing to replace."
});
