tinyMCE.addI18n('ru.codemagic_dlg',{
    code_title: "Редактор HTML",
    code_label: " ",
    toggle_highlighting: "подсветка синтаксиса",
    toggle_autocompletion: "автодополнение",
    toggle_wraptext: "перенос слов",
    search: "найти",
    replace: "заменить",
    undo: "отменить",
    redo: "вернуть",
    search_replace: "найти и заменить",
    reintendt: "форматировать",
    nothing_found: "ничего не найдено",
    nothing_to_replace: "нечего заменять"
});
