;(function($) { $(function() {
	'use strict';
	rm.server.license.Form
		.construct({element: $('body.df-server-admin-license-edit #edit_form')})
	;
}); })(jQuery);