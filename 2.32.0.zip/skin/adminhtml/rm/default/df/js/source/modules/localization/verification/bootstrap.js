;(function($) { $(function() {
	rm.localization.verification.FileList
		.construct(
			{
				elementSelector: '.df .df-localization .df-verification .df-files .df-files-body'
			}
		)
	;
	rm.localization.verification.FileWorkspace
		.construct(
			{
				elementSelector: '.df .df-localization .df-verification .df-fileDetails'
			}
		)
	;


}); })(jQuery);