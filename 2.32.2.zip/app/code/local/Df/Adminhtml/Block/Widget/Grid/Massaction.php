<?php
class Df_Adminhtml_Block_Widget_Grid_Massaction extends Mage_Adminhtml_Block_Widget_Grid_Container {
	const _CLASS = __CLASS__;
	const P__FORM_FIELD_NAME = 'form_field_name';
}