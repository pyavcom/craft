<?php
class Df_Catalog_Model_Dispatcher {
	/**
	 * @param Varien_Event_Observer $observer
	 * @return void
	 */
	public function rm__magento_ce_has_just_been_installed(Varien_Event_Observer $observer) {
		try {
			/**
			 * Если установка Российской сборки Magento
			 * производится одновременно с установкой Magento CE,
			 * то Df_Catalog_Model_Setup_2_23_5 почему-то не в состоянии переименовать «Default Category».
			 * Для устранения этой проблемы мы при одновременной установке
			 * Российской сборки Magento и Magento CE
			 * повторно вручную запускаем Df_Catalog_Model_Setup_2_23_5::s()->process()
			 * сразу после завершения установки Magento CE
			 * (на событие «controller_action_postdispatch_install_wizard_end»).
			 */
			Df_Catalog_Model_Setup_2_23_5::s()->process();
		}
		catch(Exception $e) {
			df_handle_entry_point_exception($e);
		}
	}
}