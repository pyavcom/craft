<?php
class Df_Alfabank_Helper_Data extends Mage_Core_Helper_Data {}