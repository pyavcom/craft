<?php
class Df_Autotrading_Helper_Data extends Mage_Core_Helper_Abstract {
	const _CLASS = __CLASS__;
}