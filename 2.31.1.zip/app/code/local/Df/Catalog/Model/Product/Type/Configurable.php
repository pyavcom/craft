<?php
class Df_Catalog_Model_Product_Type_Configurable extends Mage_Catalog_Model_Product_Type_Configurable {
	const _CLASS = __CLASS__;
	/**
	 * @static
	 * @param mixed[] $parameters [optional]
	 * @return Df_Catalog_Model_Product_Type_Configurable
	 */
	public static function i(array $parameters = array()) {return new self($parameters);}
}