<?php
class Df_Catalog_Helper_Product_Compare extends Mage_Catalog_Helper_Product_Compare {
	/**
	 * Retrieve url for adding product to compare list
	 *
	 * @param  Mage_Catalog_Model_Product $product
	 * @return  string|null
	 */
	public function getAddUrl(
		/**
		 * Мы не можем явно указать тип параметра $product, * потому что иначе интерпретатор сделает нам замечание:
		 * «Strict Notice: Declaration of Df_Catalog_Helper_Product_Compare::getAddUrl()
		 * should be compatible with that of Mage_Catalog_Helper_Product_Compare::getAddUrl()»
		 */
		$product
	) {
		df_assert($product instanceof Mage_Catalog_Model_Product);
		$result = parent::_getUrl('catalog/product_compare/add', $this->_getUrlParams($product));
		if (df_module_enabled (Df_Core_Module::TWEAKS) && df_enabled(Df_Core_Feature::TWEAKS)) {
			if (
					(
							rm_handle_presents(Df_Core_Model_Layout_Handle::CATALOG_PRODUCT_VIEW)
						&&
							df_cfg()->tweaks()->catalog()->product()->view()->needHideAddToCompare()
					)
				||
					(
							df_cfg()->tweaks()->catalog()->product()->_list()->needHideAddToCompare()
						&&
							df_h()->tweaks()->isItCatalogProductList()
					)
			) {
				$result = null;
			}

		}
		return $result;
	}

	const _CLASS = __CLASS__;
}