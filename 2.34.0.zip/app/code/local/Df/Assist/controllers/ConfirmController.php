<?php
class Df_Assist_ConfirmController extends Mage_Core_Controller_Front_Action {
	/**
	 * Платёжная система присылает сюда подтверждение приёма оплаты от покупателя.
	 * @return void
	 */
	public function indexAction() {
		Df_Assist_Model_Action_Confirm::i($this)->process();
	}
}