<?php
class Df_AvisLogistics_Model_Method_Express extends Df_AvisLogistics_Model_Method {
}