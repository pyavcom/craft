<?php

class Df_Banner_Block_Adminhtml_Banner_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs {


	/**
	 * @override
	 * @return string|null
	 */
	public function getTemplate() {


		/** @var string|null $result */
		$result =

				/**
				 * В отличие от витрины, шаблоны административной части будут отображаться
				 * даже если модуль отключен (но модуль должен быть лицензирован)
				 */
				!(df_enabled (Df_Core_Feature::BANNER))
			?
				null
			:
				parent::getTemplate()
		;


		if (!is_null ($result)) {
			df_assert_string ($result);
		}
		return $result;
	}


	/**
	 *
	 */
	public function __construct() {
		parent::__construct();
		$this->setId('df_banner_tabs');
		$this->setDestElementId('edit_form');
		$this->setTitle(df_helper()->banner()->__('Настройки'));
	}


	/**
	 * @override
	 * @return Mage_Core_Block_Abstract
	 */
	protected function _beforeToHtml() {
		$this
			->addTab (
				'form_section'
				,
				array (
					'label' => df_helper()->banner()->__('Основные')
					,
					'title' => df_helper()->banner()->__('Основные')
					,
					'content' =>
						df_block (
							Df_Banner_Block_Adminhtml_Banner_Edit_Tab_Form
								::getNameInMagentoFormat()
						)->toHtml()
					)
			)
		;
		return parent::_beforeToHtml();
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Banner_Block_Adminhtml_Banner_Edit_Tabs';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}