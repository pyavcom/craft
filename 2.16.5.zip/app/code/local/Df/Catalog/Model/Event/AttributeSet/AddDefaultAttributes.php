<?php

/**
 * Cообщение:		«df_catalog__attribute_set__add_default_attributes»
 *
 * Источник:		Df_Catalog_Model_Installer_AttributeSet::addAttributesDefault()
 * [code]
		Mage
			::dispatchEvent (
				Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes::EVENT
				,
				array (
					Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes
						::EVENT_PARAM__ATTRIBUTE_SET => $attributeSet
				)
			)
		;
 * [/code]
 */
class Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes extends Df_Core_Model_Event {

	/**
	 * @return Mage_Eav_Model_Entity_Attribute_Set
	 */
	public function getAttributeSet() {
		/** @var Mage_Eav_Model_Entity_Attribute_Set $result */
		$result = $this->getEventParam (self::EVENT_PARAM__ATTRIBUTE_SET);
		df_assert ($result instanceof Mage_Eav_Model_Entity_Attribute_Set);
		return $result;
	}
	

	/**
	 * @override
	 * @return string
	 */
	protected function getExpectedEventPrefix() {
		return self::EVENT;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Catalog_Model_Event_AttributeSet_AddDefaultAttributes';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}


	const EVENT = 'df_catalog__attribute_set__add_default_attributes';
	const EVENT_PARAM__ATTRIBUTE_SET = 'attribute_set';
}