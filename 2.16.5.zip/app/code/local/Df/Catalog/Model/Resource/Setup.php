<?php

class Df_Catalog_Model_Resource_Setup extends Mage_Catalog_Model_Resource_Eav_Mysql4_Setup {

	/**
	 * Этот метод отличается от родительского метода
	 * Mage_Eav_Model_Entity_Setup::addAttributeToSet
	 * только расширенной диагностикой
	 * (мы теперь знаем, что произошло в результате работы метода:
	 * действительно ли товарное свойство было добавлено к прикладному типу товаров,
	 * или же оно уже принадлежало этому прикладному типу,
	 * а если уже принадлежало — не сменалась ли его группа).
	 *
	 * @param mixed $entityTypeId
	 * @param mixed $setId
	 * @param mixed $groupId
	 * @param mixed $attributeId
	 * @param int $sortOrder
	 * @return string
  	 */
	public function addAttributeToSetRm (
		$entityTypeId
		,
		$setId
		,
		$groupId
		,
		$attributeId
		,
		$sortOrder=null
	) {
		/** @var string $result */
		$result = self::ADD_ATTRIBUTE_TO_SET__NOT_CHANGED;

		$entityTypeId = $this->getEntityTypeId($entityTypeId);
		$setId = $this->getAttributeSetId($entityTypeId, $setId);
		$groupId = $this->getAttributeGroupId($entityTypeId, $setId, $groupId);
		$attributeId = $this->getAttributeId($entityTypeId, $attributeId);
		$table = $this->getTable('eav/entity_attribute');

		$bind =
			array (
				'attribute_set_id' => $setId,
				'attribute_id' => $attributeId
			)
		;

		$select =
			$this->_conn->select()
				->from($table)
				->where('attribute_set_id = :attribute_set_id')
				->where('attribute_id = :attribute_id')
		;
		$row = $this->_conn->fetchRow($select, $bind);

		if ($row) {
			if ($row['attribute_group_id'] != $groupId) {
				$where = array('entity_attribute_id =?' => $row['entity_attribute_id']);
				$data  = array('attribute_group_id' => $groupId);
				$this->_conn->update($table, $data, $where);
				$result = self::ADD_ATTRIBUTE_TO_SET__CHANGED_GROUP;
			}
		}
		else {
			$data =
				array (
					'entity_type_id' => $entityTypeId,
					'attribute_set_id' => $setId,
					'attribute_group_id' => $groupId,
					'attribute_id' => $attributeId,
					'sort_order' =>
						$this->getAttributeSortOrder (
							$entityTypeId
							,
							$setId
							,
							$groupId
							,
							$sortOrder
						)
				)
			;
			$this->_conn->insert($table, $data);
			$result = self::ADD_ATTRIBUTE_TO_SET__ADDED;
		}
		df_result_string ($result);
		return $result;
	}


	const ADD_ATTRIBUTE_TO_SET__ADDED = 'added';
	const ADD_ATTRIBUTE_TO_SET__NOT_CHANGED = 'not_changed';
	const ADD_ATTRIBUTE_TO_SET__CHANGED_GROUP = 'changed_group';


	/**
	 * @return Df_Catalog_Model_Resource_Setup
	 */
	public function cleanQueryCache() {
		$this->_setupCache = array();
		return $this;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Catalog_Model_Resource_Setup';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		return 'df_catalog/setup';
	}
}

