<?php



/**
 * Form for version edit page
 *
 * @category	Df
 * @package	 Df_Cms
 *
 */

class Df_Cms_Block_Adminhtml_Cms_Page_Version_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
	/**
	 * Define customized form template
	 */
	protected function _construct()
	{
		parent::_construct();
		$this->setTemplate('df/cms/page/version/form.phtml');
	}

	/**
	 * Preparing from for version page
	 *
	 * @return Df_Cms_Block_Adminhtml_Cms_Page_Revision_Edit_Form
	 */
	protected function _prepareForm()
	{
		$form = new Varien_Data_Form(array(
				'id' => 'edit_form',
				'action' => $this->getUrl('*/*/save', array('_current' => true)),
				'method' => 'post'
			));

		$form->setUseContainer(true);

		/* @var $model Mage_Cms_Model_Page */
		$version = Mage::registry('cms_page_version');

		$config = Mage::getSingleton('df_cms/config');
		/* @var $config Df_Cms_Model_Config */

		$isOwner = $config->isCurrentUserOwner($version->getUserId());
		$isPublisher = $config->canCurrentUserPublishRevision();

		$fieldset = $form->addFieldset('version_fieldset',
			array('legend' => df_helper()->cms()->__('Version Information'),
			'class' => 'fieldset-wide'));

		$fieldset->addField('version_id', Df_Varien_Data_Form_Element_Abstract::TYPE__HIDDEN, array(
			'name'	  => 'version_id'
		));

		$fieldset->addField('page_id', Df_Varien_Data_Form_Element_Abstract::TYPE__HIDDEN, array(
			'name'	  => 'page_id'
		));

		$fieldset->addField('label', 'text', array(
			'name'	  => 'label',
			'label'	 => df_helper()->cms()->__('Version Label'),
			'disabled'  => !$isOwner,
			'required'  => true
		));

		$fieldset->addField('access_level', 'select', array(
			'label'	 => df_helper()->cms()->__('Access Level'),
			'title'	 => df_helper()->cms()->__('Access Level'),
			'name'	  => 'access_level',
			'options'   => df_helper()->cms()->getVersionAccessLevels(),
			'disabled'  => !$isOwner && !$isPublisher
		));

		if ($isPublisher) {
			$fieldset->addField('user_id', 'select', array(
				'label'	 => df_helper()->cms()->__('Owner'),
				'title'	 => df_helper()->cms()->__('Owner'),
				'name'	  => 'user_id',
				'options'   => df_helper()->cms()->getUsersArray(!$version->getUserId()),
				'required'  => !$version->getUserId()
			));
		}

		$form->setValues($version->getData());
		$this->setForm($form);
		return parent::_prepareForm();
	}
}
