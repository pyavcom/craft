<?php

class Df_Cms_Const {

	const LAYOUT_HANDLE__INDEX_INDEX = 'cms_index_index';
	const LAYOUT_HANDLE__PAGE = 'cms_page';


	const ADMIN_RESOURCE__HIERARCHY = 'cms/hierarchy';
}

