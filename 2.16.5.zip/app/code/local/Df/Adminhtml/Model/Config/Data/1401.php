<?php

/**
 * Используется методом Df_Adminhtml_Block_System_Config_Form::initFields_1_4_0_1
 */
class Df_Adminhtml_Model_Config_Data_1401 extends Df_Adminhtml_Model_Config_Data {


	/**
	 * Extend config data with additional config data by specified path
	 *
	 * @param string $path Config path prefix
	 * @param bool $full Simple config structure or not
	 * @param array $oldConfig Config data to extend
	 * @return array
	 */
	public function extendConfig ($path, $full = true, $oldConfig = array()) {
		$extended = $this->_getPathConfig($path, $full);
		if (is_array($oldConfig) && !empty($oldConfig)) {
			return $oldConfig + $extended;
		}
		return $extended;
	}


	/**
	 * Return formatted config data for specified path prefix
	 *
	 * @param string $path Config path prefix
	 * @param bool $full Simple config structure or not
	 * @return array
	 */
	protected function _getPathConfig($path, $full = true) {
		$configDataCollection = Mage::getModel('core/config_data')
			->getCollection()
			->addScopeFilter($this->getScope(), $this->getScopeId(), $path);

		$config = array();
		foreach ($configDataCollection as $data) {
			if ($full) {
				$config[$data->getPath()] = array(
					'path'	  => $data->getPath(),
					'value'	 => $data->getValue(),
					'config_id' => $data->getConfigId()
				);
			}
			else {
				$config[$data->getPath()] = $data->getValue();
			}
		}
		return $config;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Adminhtml_Model_Config_Data_1401';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}

}


