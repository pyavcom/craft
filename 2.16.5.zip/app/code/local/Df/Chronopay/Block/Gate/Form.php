<?php

class Df_Chronopay_Block_Gate_Form extends Mage_Payment_Block_Form_Cc {

	/**
	 * @override
	 * @return string
	 */
	public function getArea() {
		return Df_Core_Const_Design_Area::FRONTEND;
	}


	/**
	 * @override
	 * @return string
	 */
	public function getTemplate() {
		return self::TEMPLATE;
	}


	const TEMPLATE = 'df/chronopay/gate/form.phtml';


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Chronopay_Block_Gate_Form';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}