<?php

class Df_Chronopay_Block_Gate_Failure extends Mage_Core_Block_Template
{
}