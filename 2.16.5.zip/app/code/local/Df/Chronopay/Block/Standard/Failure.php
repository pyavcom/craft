<?php

class Df_Chronopay_Block_Standard_Failure extends Mage_Core_Block_Template
{
}