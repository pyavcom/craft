<?php

class Df_Chronopay_Block_Standard_Form extends Mage_Payment_Block_Form {

	/**
	 * @override
	 * @return string
	 */
	public function getArea() {
		return Df_Core_Const_Design_Area::FRONTEND;
	}


	/**
	 * @return string
	 */
	public function getDescription() {

		/** @var string $result */
		$result =
			df_convert_null_to_empty_string (
				Mage::getStoreConfig ('df_payment/chronopay_standard/description')
			)
		;

		df_result_string ($result);
		return $result;
	}


	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this->setTemplate(self::DF_TEMPLATE);
	}


	const DF_TEMPLATE = 'df/chronopay/standard/form.phtml';

}