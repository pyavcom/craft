<?php

class Df_Checkout_Const_Field {

	const CITY = 'city';
	const COMPANY = 'company';
	const CONFIRM_PASSWORD = 'confirm_password';
	const COUNTRY = 'country';
	const CUSTOMER_PASSWORD = 'customer_password';
	const EMAIL = 'email';
	const FAX = 'fax';
	const FIRSTNAME = 'firstname';
	const LASTNAME = 'lastname';
	const MIDDLENAME = 'middlename';
	const POSTCODE = 'postcode';
	const REGION = 'region';
	const STREET = 'street';
	const TELEPHONE = 'telephone';

}


