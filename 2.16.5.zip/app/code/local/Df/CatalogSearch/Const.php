<?php

class Df_CatalogSearch_Const {

	const LAYOUT_HANDLE__RESULT_INDEX = 'catalogsearch_result_index';

}

