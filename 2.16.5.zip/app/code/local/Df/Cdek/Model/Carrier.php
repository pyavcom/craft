<?php

class Df_Cdek_Model_Carrier extends Df_Shipping_Model_Carrier {


	/**
	 * @override
	 * @return string
	 */
	public function getRmId() {
		return self::RM__ID;
	}


	/**
	 * @override
	 * @return bool
	 */
	public function isTrackingAvailable() {
		return true;
	}


	/**
	 * Если модуль предоставляет несколько способов доставки,
	 * нужно ли показывать сообщения о сбоях недоступных способов, если есть доступные?
	 *
	 * @override
	 * @return bool
	 */
	public function needShowInvalidMethodMessagesIfValidMethodExists() {
		return false;
	}


	/**
	 * @return string
	 */
	protected function getConfigClassServiceMf() {
		return Df_Cdek_Model_Config_Area_Service::getNameInMagentoFormat();
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getRmConfigClassMf() {
		return Df_Cdek_Model_Config_Facade::getNameInMagentoFormat();
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getRmFeatureCode() {
 		return Df_Core_Feature::CDEK;
	}





	const RM__ID = 'cdek';


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Cdek_Model_Carrier';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}

}


