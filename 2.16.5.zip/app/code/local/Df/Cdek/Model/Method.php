<?php

abstract class Df_Cdek_Model_Method extends Df_Shipping_Model_Method {


	/**
	 * @abstract
	 * @return bool
	 */
	abstract protected function needDeliverToHome();


	/**
	 * @override
	 * @return float
	 */
	public function getCost() {

		if (!isset ($this->_cost)) {

			if (0 === $this->getCostInRoubles()) {
				$this->throwExceptionInvalidDestination();
			}

			/** @var float $result */
			$result =
				df_helper()->directory()->currency()->convertFromRoublesToBase (
					$this->getCostInRoubles()
				)
			;

			df_assert_float ($result);

			$this->_cost = $result;
		}

		df_result_float ($this->_cost);
		return $this->_cost;

	}
	/** @var float */
	private $_cost;


	/**
	 * @override
	 * @return string
	 */
	public function getMethodTitle() {

		/** @var string $result */
		$result =
			sprintf (
				'%s (%s): %s'
				,
				parent::getMethodTitle()
				,
				df_array_first (
					df_a (
						self::$services
						,
						$this->getApi()->getServiceId()
					)
				)
				,
				$this->formatTimeOfDelivery (
					$timeOfDeliveryMin = $this->getApi()->getDeliveryTimeMin()
					,
					$timeOfDeliveryMax = $this->getApi()->getDeliveryTimeMax()
				)
			)
		;

		df_result_string ($result);
		return $result;
	}


	/**
	 * @override
	 * @return bool
	 */
	public function isApplicable() {

		/** @var bool $result */
		$result =
				(!df_empty ($this->getRequest()->getOriginCity()))
			&&
				(!df_empty ($this->getRequest()->getDestinationCity()))
			&&
				(!df_empty ($this->getLocationIdOrigin()))
			&&
				(!df_empty ($this->getLocationIdDestination()))
		;

		df_result_boolean ($result);
		return $result;
	}


	/**
	 * @override
	 * @param string|null $locationName
	 * @return int|null
	 */
	protected function getLocationIdByName ($locationName) {
		return
			Df_Cdek_Model_Request_Location::getLocationIdByName (
				$locationName
			)
		;
	}


	/**
	 * @return Df_Cdek_Model_Config_Facade
	 */
	protected function getRmConfig() {

		/** @var Df_Cdek_Model_Config_Facade $result */
		$result = parent::getRmConfig();

		df_assert ($result instanceof Df_Cdek_Model_Config_Facade);
		return $result;
	}


	/**
	 * @return Df_Cdek_Model_Request_Rate
	 */
	private function getApi() {
	
		if (!isset ($this->_api)) {
	
			/** @var Df_Cdek_Model_Request_Rate $result */
			$result = 	
				df_model (
					Df_Cdek_Model_Request_Rate::getNameInMagentoFormat()
					,
					array (
						Df_Cdek_Model_Request_Rate::PARAM__POST_PARAMS => $this->getPostParams()
					)
				)
			;
	
			df_assert ($result instanceof Df_Cdek_Model_Request_Rate);
	
			$this->_api = $result;
		}
	
		df_assert ($this->_api instanceof Df_Cdek_Model_Request_Rate);
	
		return $this->_api;
	}
	/** @var Df_Cdek_Model_Request_Rate */
	private $_api;	


	/**
	 * @return float
	 */
	private function getCostInRoubles() {

		/** @var float $result */
		$result = $this->getApi()->getRate();

		df_result_float ($result);
		return $result;
	}


	/**
	 * @return int
	 */
	private function getDeliveryType() {

		/** @var int $result */
		$result = null;

		if ($this->getRmConfig()->service()->needGetCargoFromTheShopStore()) {
			$result =
					$this->needDeliverToHome()
				?
					1
				:
					2
			;
		}
		else {
			$result =
					$this->needDeliverToHome()
				?
					3
				:
					4
			;
		}

		df_result_integer ($result);
		return $result;
	}


	/**
	 * @return array
	 */
	private function getPostParams() {

		/** @var array $result */
		$result =
			array (
				'senderCityId' => $this->getLocationIdOrigin()
				,
				'receiverCityId' => $this->getLocationIdDestination()
//				,
//				'modeId' => $this->getDeliveryType()
				,
				'tariffList' => $this->getServices ($this->getDeliveryType())
				,
				'goods' => $this->getQuoteItemsDescriptionForShippingService()
			)
		;


		if (
				!df_empty ($this->getRmConfig()->service()->getShopId())
			&&
				!df_empty ($this->getRmConfig()->service()->getShopPassword())
		) {
			/** @var $dateAsString */
			$dateAsString = Zend_Date::now()->toString ('yyyy-MM-dd');
			df_assert_string ($dateAsString);

			$result =
				array_merge (
					$result
					,
					array (
						'authLogin' => $this->getRmConfig()->service()->getShopId()
						,
						'secure' =>
							md5 (
								implode (
									'&'
									,
									array (
										$dateAsString
										,
										$this->getRmConfig()->service()->getShopPassword()
									)
								)
							)
						,
						'dateExecute' => $dateAsString
					)
				)
			;
		}

		df_result_array ($result);
		return $result;
	}


	/**
	 * @return array
	 */
	private function getQuoteItemsDescriptionForShippingService() {

		/** @var array $result */
		$result = array();

		foreach ($this->getRequest()->getQuoteItemsSimple() as $quoteItem) {
			/** @var Mage_Sales_Model_Quote_Item $quoteItem */
			df_assert ($quoteItem instanceof Mage_Sales_Model_Quote_Item);


			/** @var Df_Sales_Model_Quote_Item_Extended $quoteItemExtended */
			$quoteItemExtended =
				Df_Sales_Model_Quote_Item_Extended::create (
					$quoteItem
				)
			;

			df_assert ($quoteItemExtended instanceof Df_Sales_Model_Quote_Item_Extended);


			/** @var Mage_Catalog_Model_Product $product */
			$product = $quoteItem->getProduct();

			df_assert ($product instanceof Mage_Catalog_Model_Product);


			/** @var array $productDimensionsWithSystemLabels */
			$productDimensionsWithSystemLabels =
				$this->getRequest()->getProductDimensions ($product)
			;

			df_assert_array ($productDimensionsWithSystemLabels);


			/** @var array $productEntry */
			$productEntry =
				array_merge (
					df_array_combine (
						array (
							'width'
							,
							'height'
							,
							'length'
						)
						,
						array_map (
							'ceil'
							,
							array_map (
								array (df()->units()->length(), 'convertToCentimetres')
								,
								array (
									df_a (
										$productDimensionsWithSystemLabels
										,
										Df_Catalog_Model_Product::PARAM__WIDTH
									)
									,
									df_a (
										$productDimensionsWithSystemLabels
										,
										Df_Catalog_Model_Product::PARAM__HEIGHT
									)
									,
									df_a (
										$productDimensionsWithSystemLabels
										,
										Df_Catalog_Model_Product::PARAM__LENGTH
									)
								)
							)
						)
					)
					,
					array (
						'weight' =>
							df()->units()->weight()->convertToKilogrammes (
								/**
								 * Здесь нужен вес именно товара, а не строки заказа
								 */
								floatval (
										df_empty ($product->getWeight())
									?
										df_cfg()->shipping()->product()->getDefaultWeight()
									:
										$product->getWeight()
								)
							)
					)
				)
			;

			df_assert_array ($productEntry);


			for ($productIndex = 0; $productIndex < $quoteItemExtended->getQty(); $productIndex++) {
				$result []= $productEntry;
			}

		}

		df_result_array ($result);
		return $result;
	}


	/**
	 * @param int $deliveryType
	 * @return array
	 */
	private function getServices ($deliveryType) {

		df_param_integer ($deliveryType, 0);

		/** @var array $result */
		$result = array();

		/** @var int $priority */
		$priority = 1;

		foreach (self::$services as $serviceId => $serviceData) {
			/** @var int $serviceId */
			df_assert_integer ($serviceId);

			/** @var array $serviceData */
			df_assert_array ($serviceData);

			/** @var int $currentDeliveryType */
			$currentDeliveryType = df_array_last ($serviceData);
			df_assert_integer ($currentDeliveryType);

			if ($deliveryType === $currentDeliveryType) {
				$result []=
					array (
						'priority' => $priority++
						,
						'id' => $serviceId
					)
				;
			}

		}

		df_result_array ($result);
		return $result;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Cdek_Model_Method';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}


	/**
	 * @var array
	 */
	private static $services =
		array (
			1 => array ('Экспресс лайт дверь-дверь', 1)
			,3 => array ('Супер-экспресс до 18', 1)
			,4 => array ('Рассылка', 1)
			,5 => array ('Экономичный экспресс склад-склад', 4)
			,7 => array ('Международный экспресс документы', 1)
			,8 => array ('Международный экспресс грузы', 1)
			,10 => array ('Экспресс лайт склад-склад', 4)
			,11 => array ('Экспресс лайт склад-дверь', 3)
			,12 => array ('Экспресс лайт дверь-склад', 2)
			,15 => array ('Экспресс тяжеловесы склад-склад', 4)
			,16 => array ('Экспресс тяжеловесы склад-дверь', 3)
			,17 => array ('Экспресс тяжеловесы дверь-склад', 2)
			,18 => array ('Экспресс тяжеловесы дверь-дверь', 1)
			,57 => array ('Супер-экспресс до 9', 1)
			,58 => array ('Супер-экспресс до 10', 1)
			,59 => array ('Супер-экспресс до 12', 1)
			,60 => array ('Супер-экспресс до 14', 1)
			,61 => array ('Супер-экспресс до 16', 1)
			,62 => array ('Магистральный экспресс склад-склад', 4)
			,63 => array ('Магистральный супер-экспресс склад-склад', 4)
			,66 => array ('Блиц-экспресс 01', 1)
			,67 => array ('Блиц-экспресс 02', 1)
			,68 => array ('Блиц-экспресс 03', 1)
			,69 => array ('Блиц-экспресс 04', 1)
			,70 => array ('Блиц-экспресс 05', 1)
			,71 => array ('Блиц-экспресс 06', 1)
			,72 => array ('Блиц-экспресс 07', 1)
			,73 => array ('Блиц-экспресс 08', 1)
			,74 => array ('Блиц-экспресс 09', 1)
			,75 => array ('Блиц-экспресс 10', 1)
			,76 => array ('Блиц-экспресс 11', 1)
			,77 => array ('Блиц-экспресс 12', 1)
			,78 => array ('Блиц-экспресс 13', 1)
			,79 => array ('Блиц-экспресс 14', 1)
			,80 => array ('Блиц-экспресс 15', 1)
			,81 => array ('Блиц-экспресс 16', 1)
			,82 => array ('Блиц-экспресс 17', 1)
			,83 => array ('Блиц-экспресс 18', 1)
			,84 => array ('Блиц-экспресс 19', 1)
			,85 => array ('Блиц-экспресс 20', 1)
			,86 => array ('Блиц-экспресс 21', 1)
			,87 => array ('Блиц-экспресс 22', 1)
			,88 => array ('Блиц-экспресс 23', 1)
			,89 => array ('Блиц-экспресс 24', 1)
			,136 => array ('Посылка склад-склад', 4)
			,137 => array ('Посылка склад-дверь', 3)
			,138 => array ('Посылка дверь-склад', 2)
			,139 => array ('Посылка дверь-дверь', 1)
			,140 => array ('Возврат склад-склад', 4)
			,141 => array ('Возврат склад-дверь', 3)
			,142 => array ('Возврат дверь-склад', 2)
		)
	;

}


