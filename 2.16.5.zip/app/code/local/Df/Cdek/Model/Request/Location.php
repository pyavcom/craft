<?php

class Df_Cdek_Model_Request_Location extends Df_Cdek_Model_Request {


	/**
	 * @return int
	 */
	public function getLocationId() {

		/** @var int $result */
		$result =
			df_a (
				$this->getResponseAsAssocArray()
				,
				$this->normalizeLocationName (
					$this->getLocationName()
				)
			)
		;


		if (is_null ($result)) {
			df_error (
				sprintf (
					'Служба доставки СДЭК не знает о населённом пункте «%s»'
					,
					$this->getLocationName()
				)
			);
		}


		df_result_integer ($result);
		return $result;
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getQueryParams() {
		return
			array (
				'q' => $this->getLocationName()
			)
		;
	}


	/**
	 * @return string
	 */
	private function getLocationName() {
		return $this->cfg (self::PARAM__LOCATION_NAME);
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getQueryPath() {
		return '/city/getListByTerm/jsonp.php';
	}


	/**
	 * @return array
	 */
	private function getResponseAsAssocArray() {

		if (!isset ($this->_responseAsAssocArray)) {

			/** @var array $responseAsArray */
			$responseAsArray =
				json_decode (
					df_trim ($this->getResponseAsText(), '()')
					,
					$assoc = true
				)
			;

			df_assert_array ($responseAsArray);


			/** @var array $locations */
			$locations = df_a ($responseAsArray, 'geonames');

			df_assert_array ($locations);


			/** @var array $result */
			$result = array();


			foreach ($locations as $location) {

				/** @var array $location */
				df_assert_array ($location);


				/** @var int $locationId */
				$locationId = intval (df_a ($location, 'id'));

				df_assert_integer ($locationId);


				/** @var string $locationName */
				$locationName = df_a ($location, 'name');

				df_assert_string ($locationName);


				$result [$this->normalizeLocationName($locationName)] = $locationId;
			}


			df_assert_array ($result);

			$this->_responseAsAssocArray = $result;
		}


		df_result_array ($this->_responseAsAssocArray);
		return $this->_responseAsAssocArray;
	}
	/** @var array */
	private $_responseAsAssocArray;


	/**
	 * @param string $locationName
	 * @return string
	 */
	private function normalizeLocationName ($locationName) {

		df_param_string ($locationName, 0);

		/** @var string $result */
		$result =
			mb_strtoupper (
				df_trim (
					/**
					 * СДЭК может вернуть название населенного пункта в формате
					 * «Киев, Киевская обл., Украина»
					 */
					df_array_first (
						explode (
							','
							,
							$locationName
						)
					)
				)
			)
		;

		df_result_string ($result);
		return $result;
	}


	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
		$this
			->addValidator (self::PARAM__LOCATION_NAME, new Df_Zf_Validate_String())
		;
	}



	const PARAM__LOCATION_NAME = 'location_name';


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Cdek_Model_Request_Location';
	}


	/**
	 * @param string $locationName
	 * @return int
	 */
	public static function getLocationIdByName ($locationName) {

		/** @var Df_Cdek_Model_Request_Location $api */
		$api =
			df_model (
				self::getNameInMagentoFormat()
				,
				array (
					self::PARAM__LOCATION_NAME => $locationName
				)
			)
		;

		df_assert ($api instanceof Df_Cdek_Model_Request_Location);

		/** @var int $result */
		$result = $api->getLocationId();

		df_result_integer ($result);
		return $result;
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}

}


