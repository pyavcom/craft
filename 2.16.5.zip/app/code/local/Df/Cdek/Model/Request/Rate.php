<?php

class Df_Cdek_Model_Request_Rate extends Df_Cdek_Model_Request {


	/**
	 * @return int
	 */
	public function getDeliveryTimeMax() {

		$this->responseFailureDetect();

		/** @var int $result */
		$result = intval (df_a ($this->getResponseSuccessData(), 'deliveryPeriodMax'));

		df_result_integer ($result);
		return $result;
	}


	/**
	 * @return int
	 */
	public function getDeliveryTimeMin() {

		$this->responseFailureDetect();

		/** @var int $result */
		$result = intval (df_a ($this->getResponseSuccessData(), 'deliveryPeriodMin'));

		df_result_integer ($result);
		return $result;
	}


	/**
	 * @return float
	 */
	public function getRate() {

		$this->responseFailureDetect();

		/** @var float $result */
		$result = floatval (df_a ($this->getResponseSuccessData(), 'price'));

		df_result_float ($result);
		return $result;
	}


	/**
	 * @return int
	 */
	public function getServiceId() {

		$this->responseFailureDetect();

		/** @var int $result */
		$result = intval (df_a ($this->getResponseSuccessData(), 'tariffId'));

		df_result_integer ($result);
		return $result;
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getPostRawData() {
		return
			json_encode (
				array_merge (
					array (
						'version' => '1.0'
					)
					,
					$this->getPostParameters()
				)
			)
		;
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getQueryPath() {
		return '/calculator/calculate_price_by_json.php';
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getRequestMethod() {
		return Zend_Http_Client::POST;
	}


	/**
	 *@override
	 * @return bool
	 */
	protected function needLogNonExceptionErrors() {
		return false;
	}


	/**
	 * @override
	 * @return Df_Shipping_Model_Request
	 */
	protected function responseFailureDetect() {

		parent::responseFailureDetect();

		/** @var array|null $errors */
		$errors = df_a ($this->getResponseAsArray(), 'error');

		if (!is_null ($errors))  {

			df_assert_array ($errors);
			df_assert_between (count ($errors), 1);

			/** @var string[] $messages */
			$messages = array();

			foreach ($errors as $error) {
				/** @var array $error */
				df_assert_array ($error);

				/** @var string $message */
				$message = df_a ($error, 'text');
				df_assert_string ($message);

				$messages []= $message;
			}

			$this
				->responseFailureHandle (
					implode (
						"\n"
						,
						$messages
					)
				)
			;
		}
		return $this;
	}


	/**
	 * @return array
	 */
	private function getResponseAsArray() {

		if (!isset ($this->_responseAsArray)) {

			/** @var array $result */
			$result =
				json_decode (
					$this->getResponseAsText()
					,
					$assoc = true
				)
			;

			df_assert_array ($result);

			$this->_responseAsArray = $result;
		}


		df_result_array ($this->_responseAsArray);
		return $this->_responseAsArray;
	}
	/** @var array */
	private $_responseAsArray;


	/**
	 * @override
	 * @return string
	 */
	public function getResponseAsText() {
	
		if (!isset ($this->_responseAsText)) {
	
			/** @var string $result */
			$result =
				/**
				 * Сервер СДЭК может давать сбой:
				 * Notice: Undefined variable: data in /var/www/api/calculator/library_calculate_price/CalculateDelivery.php on line 202
				 */
				preg_replace (
					"#Notice:[^\n]+\n#"
					,
					Df_Core_Const::T_EMPTY
					,
					parent::getResponseAsText()
				)
			;
	
			df_assert_string ($result);
	
			$this->_responseAsText = $result;
		}
	
		df_result_string ($this->_responseAsText);
	
		return $this->_responseAsText;
	}
	/** @var string */
	private $_responseAsText;	


	/**
	 * @return array
	 */
	private function getResponseSuccessData() {

		/** @var array $result */
		$result =
			df_a (
				$this->getResponseAsArray()
				,
				'result'
			)
		;

		df_result_array ($result);
		return $result;
	}


	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Cdek_Model_Request_Rate';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}

}


