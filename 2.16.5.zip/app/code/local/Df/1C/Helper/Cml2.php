<?php

class Df_1C_Helper_Cml2 extends Mage_Core_Helper_Abstract {

	/**
	 * @return Df_1C_Helper_Cml2_AttributeSet
	 */
	public function attributeSet() {
		return Mage::helper (Df_1C_Helper_Cml2_AttributeSet::getNameInMagentoFormat());
	}


	/**
	 * @param string $currencyCodeInMagentoFormat
	 * @return string
	 */
	public function convertCurrencyCodeTo1CFormat ($currencyCodeInMagentoFormat) {

		df_assert_string ($currencyCodeInMagentoFormat, 0);

		$result =
			df_a (
				df_cfg()->_1c()->general()->getCurrencyCodesMapFromMagentoTo1C()
				,
				$currencyCodeInMagentoFormat
				,
				$currencyCodeInMagentoFormat
			)
		;

		df_result_string ($result);
		return $result;
	}


	/**
	 * @param string $currencyCodeIn1CFormat
	 * @return string
	 */
	public function convertCurrencyCodeToMagentoFormat ($currencyCodeIn1CFormat) {

		df_assert_string ($currencyCodeIn1CFormat, 0);

		/** @var $codeNormalized $result */
		$codeNormalized =
			df_helper()->_1c()->cml2()->normalizeNonStandardCurrencyCode (
				$currencyCodeIn1CFormat
			)
		;

		df_assert_string ($codeNormalized);

		$result =
			df_a (
				array_merge (
					array (
						'РУБ' => 'RUB'
						,
						'ГРН' => 'UAH'
					)
					,
					df_cfg()->_1c()->general()->getCurrencyCodesMapFrom1CToMagento()
				)
				,
				$codeNormalized
				,
				$codeNormalized
			)
		;

		df_result_string ($result);
		return $result;
	}

	
	/**
	 * @return Mage_Core_Model_Store
	 */
	public function getStoreProcessed() {
		if (!isset ($this->_storeProcessed)) {
			/** @var Df_Core_Model_ActionHelper_StoreProcessed $helper */
			$helper =
				df_model (
					Df_Core_Model_ActionHelper_StoreProcessed::getNameInMagentoFormat()
					,
					array (
						Df_Core_Model_ActionHelper_StoreProcessed::PARAM__MODULE_NAME =>
							'1С:Управление торговлей'
						,
						Df_Core_Model_ActionHelper_StoreProcessed::PARAM__URL_EXAMPLE =>
							'http://example.ru/df-1c/cml2/index/store-view/<системное имя витрины>/'
					)
				)
			;
			df_assert ($helper instanceof Df_Core_Model_ActionHelper_StoreProcessed);

			/** @var Mage_Core_Model_Store $result */
			$result = $helper->getStoreProcessed();
			df_assert ($result instanceof Mage_Core_Model_Store);
			$this->_storeProcessed = $result;
		}
		return $this->_storeProcessed;
	}
	/** @var Mage_Core_Model_Store */
	private $_storeProcessed;	


	/**
	 * @param $string
	 * @return bool
	 */
	public function isExternalId ($string) {
		/** @var bool $result */
		/**
		 * пример внешнего идентификатора: 6cc37c6d-7d15-11df-901f-00e04c595000
		 */
		$result =
				(36 === strlen ($string))
			&&
				(5 === count (explode ('-', $string)))
		;
		df_result_boolean ($result);
		return $result;
	}


	/**
	 * @return bool
	 */
	public function isItCml2Processing() {

		if (!isset ($this->_itCml2Processing)) {

			/** @var bool $result */
			$result =
					class_exists ('Df_1C_Cml2Controller', $autoload = false)
				&&
					(df()->state()->getController() instanceof Df_1C_Cml2Controller)
			;

			df_assert_boolean ($result);

			$this->_itCml2Processing = $result;
		}

		df_result_boolean ($this->_itCml2Processing);
		return $this->_itCml2Processing;
	}
	/** @var bool */
	private $_itCml2Processing;


	/**
	 * @param string $nonStandardCurrencyCode
	 * @return string
	 */
	public function normalizeNonStandardCurrencyCode ($nonStandardCurrencyCode) {

		df_param_string ($nonStandardCurrencyCode, 0);

		/** @var string $result */
		$result =
			mb_substr (
				df_trim (
					mb_strtoupper (
						$nonStandardCurrencyCode
					)
					,
					' .'
				)
				,
				0
				,
				3
			)
		;

		df_result_string ($result);
		return $result;
	}

	/**
	 * @return Df_1C_Helper_Cml2_Registry
	 */
	public function registry() {
		return Mage::helper (Df_1C_Helper_Cml2_Registry::getNameInMagentoFormat());
	}


	/**
	 * @param string $path
	 * @param string $value
	 * @return Df_1C_Helper_Cml2
	 */
	public function setStoreProcessedConfigValue ($path, $value) {

		Mage::getConfig()
			->saveConfig (
				$path
				,
				$value
				,
				$scope = 'stores'
				,
				$scopeId = $this->getStoreProcessed()->getId()
			)
		;

		Mage::app()->getStore()
			->setConfig (
				$path
				,
				$value
			)
		;
		return $this;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Helper_Cml2';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}