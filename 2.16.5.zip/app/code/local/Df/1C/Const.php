<?php

class Df_1C_Const {

	const PRODUCT_ATTRIBUTE_GROUP_NAME = '1С';

}

