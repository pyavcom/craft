<?php

class Df_1C_Model_Dispatcher extends Df_Core_Model_Abstract {

	/**
	 * @param Varien_Event_Observer $observer
	 * @return void
	 */
	public function df_catalog__attribute_set__group_added (
		Varien_Event_Observer $observer
	) {
		try {
			/** @var Df_Catalog_Model_Event_AttributeSet_GroupAdded $event */
			$event =
				df_event (
					Df_Catalog_Model_Event_AttributeSet_GroupAdded::getNameInMagentoFormat()
					,
					$observer
				)
			;
			df_assert ($event instanceof Df_Catalog_Model_Event_AttributeSet_GroupAdded);

			if (df_helper()->_1c()->cml2()->isItCml2Processing()) {
				df_helper()->_1c()
					->log (
						sprintf (
							'Добавили к прикладному типу товаров «%s» группу свойств «%s»'
							,
							$event->getAttributeSet()->getDataUsingMethod (
								Df_Eav_Model_Entity_Attribute_Set::PARAM__NAME
							)
							,
							$event->getGroupName()
						)
					)
				;
			}
		}
		catch (Exception $e) {
			df_handle_entry_point_exception ($e);
		}
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Model_Dispatcher';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}