<?php

abstract class Df_1C_Model_Cml2_Import_Processor_Product extends Df_1C_Model_Cml2_Import_Processor {

	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Offer|Df_1C_Model_Cml2_Import_Data_Entity
	 */
	protected function getEntityOffer() {
		/** @var Df_1C_Model_Cml2_Import_Data_Entity_Offer $result */
		$result = $this->getEntity();
		df_assert ($result instanceof Df_1C_Model_Cml2_Import_Data_Entity_Offer);
		return $result;
	}


	/**
	 * @return Df_1C_Model_Cml2_Import_Data_Entity_Product|Df_1C_Model_Cml2_Import_Data_Entity
	 */
	protected function getEntityProduct() {
		/** @var Df_1C_Model_Cml2_Import_Data_Entity_Product $result */
		$result = $this->getEntityOffer()->getEntityProduct();
		df_assert ($result instanceof Df_1C_Model_Cml2_Import_Data_Entity_Product);

		/**
		 * Инициализируем как следует прикладной тип.
		 * Этот вызов был добавлен в версии 2.16.2
		 * для устранения дефекта отключенности опции used_in_product_listing
		 * для внешнего идентификатора,
		 * что приводило к незагрузке внешнего идентификатора в коллекцию
		 *
		 * После этого код создания внешнего идентификатора был поправлен
		 * (used_in_product_listing = 1 в методе
		 * Df_1C_Helper_Cml2_AttributeSet::addExternalIdToAttributeSet),
		 * а $result->getAttributeSet() гарантирует его вызов.
		 */
		$result->getAttributeSet();
		return $result;
	}


	/**
	 * @return Mage_Catalog_Model_Product|null
	 */
	protected function getExistingMagentoProduct() {
		/**
		 * Быстро и грязно добиваемся вызова метода getEntityProduct
		 * до исполнения кода метода getExistingMagentoProduct,
		 * чтобы getEntityProduct занёс товар в реестр, если товара ещё там нет.
		 */
		$this->getEntityProduct();

		/** @var Mage_Catalog_Model_Product|null $result */
		$result =
			df_helper()->dataflow()->registry()->products()->findByExternalId (
				$this->getEntityOffer()->getExternalId()
			)
		;
		if (!is_null ($result)) {
			df_assert ($result instanceof Mage_Catalog_Model_Product);
		}
		return $result;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Model_Cml2_Import_Processor_Product';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}

}


