<?php

class Df_1C_Model_Cml2_Import_Data_Entity_ReferenceListPart_Item
	extends Df_1C_Model_Cml2_Import_Data_Entity {


	/**
	 * @override
	 * @return string
	 */
	public function getExternalId() {

		/** @var string $result */
		$result =
			$this->getEntityParam (

				/**
				 * 1С:Управление торговлей 10.2 + дополнение от Битрикса:
				 *
					<Свойство>
						<Ид>b79b0fdd-c8a5-11e1-a928-4061868fc6eb</Ид>
						<Наименование>Производитель</Наименование>
						<ТипыЗначений>
							<ТипЗначений>
								<Тип>Справочник</Тип>
								<Описание>Значения свойств объектов</Описание>
								<ВариантыЗначений>
									<ВариантЗначения>
										<Ид>b79b0fde-c8a5-11e1-a928-4061868fc6eb</Ид>
										<Значение>Sony</Значение>
									</ВариантЗначения>
									<ВариантЗначения>
										<Ид>65fa6244-c8af-11e1-a928-4061868fc6eb</Ид>
										<Значение>Pentax</Значение>
									</ВариантЗначения>
								</ВариантыЗначений>
							</ТипЗначений>
						</ТипыЗначений>
					</Свойство>
				 */
				'Ид'

				/**
				 * 1С:Управление торговлей 11:
				 *
					<Свойство>
						<Ид>69a1a785-f26f-11e1-990a-000c292511ad</Ид>
						<Наименование>Разрешение</Наименование>
						<ТипЗначений>Справочник</ТипЗначений>
						<ВариантыЗначений>
							<Справочник>
								<ИдЗначения>69a1a786-f26f-11e1-990a-000c292511ad</ИдЗначения>
								<Значение>HD Ready</Значение>
							</Справочник>
							<Справочник>
								<ИдЗначения>69a1a787-f26f-11e1-990a-000c292511ad</ИдЗначения>
								<Значение>Full HD</Значение>
							</Справочник>
						</ВариантыЗначений>
					</Свойство>
				 */
				,
				$this->getEntityParam ('ИдЗначения')
			)
		;

		df_result_string ($result);
		return $result;
	}


	/**
	 * @override
	 * @return string
	 */
	public function getName() {

		/** @var string $result */
		$result = $this->getEntityParam ('Значение');

		df_result_string ($result);
		return $result;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Model_Cml2_Import_Data_Entity_ReferenceListPart_Item';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}

