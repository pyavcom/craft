<?php

class Df_1C_Model_Cml2_Action_Login extends Df_1C_Model_Cml2_Action {

	/**
	 * @override
	 * @return Df_1C_Model_Cml2_Action_Login
	 * @throws Exception
	 */
	protected function processInternal() {
		try {
			/** @var string $userName */
			/** @var string $password */
			list ($userName, $password) =
				df_mage()->core()->httpHelper()->authValidate()
			;
			if (df_empty ($userName)) {
				df_error (
					'Администратор пытается авторизоваться с пустым системным именем, что недопустимо.'
				);
			}

			if (df_empty ($password)) {
				df_error (
					'Администратор «%s» пытается авторизоваться с пустым паролем, что недопустимо.'
					,
					$userName
				);
			}
			$this->getSession()
				->start (
					$sessionName = null
				)
			;
			/** @var Mage_Api_Model_User $apiUser */
			$apiUser =
				$this->getSession()
					->login (
						$userName
						,
						$password
					)
			;

			if (!($apiUser instanceof Mage_Api_Model_User)) {
				df_error (
					'Авторизация не удалась: неверно системное имя «%s», либо пароль к нему.'
					,
					$userName
				);
			}

			if (1 !== intval ($apiUser->getIsActive())) {
				df_error (
					'Администратор «%s» не допущен к работе'
					,
					$userName
				);
			}

			if (!$this->getSession()->isAllowed('rm/_1c')) {
				df_error (
					"Администратор «%s»
					не допущен к обмену данными между Magento и 1С: Управление торговлей.
					\nДля допуска администратора к данной работе
					наделите администратора должностью, которая обладает полномочием
					«Российская сборка» → «1С: Управление торговлей»."
					,
					$userName
				);
			}

			$this
				->setResponseBodyAsArrayOfStrings (
					array (
						'success'
						,
						self::SESSION_NAME
						,
						$this->getSession()->getSessionId()
						,
						Df_Core_Const::T_EMPTY
					)
				)
			;
		}

		catch (Exception $e) {
			df_log_exception ($e);
			$this->getResponse()
				->setHeader (
					$name = 'HTTP/1.1'
					,
					$value = '401 Unauthorized'
				)
			;
			throw $e;
		}
		return $this;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Model_Cml2_Action_Login';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}