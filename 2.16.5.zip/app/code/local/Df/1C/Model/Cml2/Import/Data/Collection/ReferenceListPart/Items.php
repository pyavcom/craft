<?php

class Df_1C_Model_Cml2_Import_Data_Collection_ReferenceListPart_Items
	extends Df_1C_Model_Cml2_Import_Data_Collection {


	/**
	 * @override
	 * @return Varien_Simplexml_Element[]
	 */
	protected function getImportEntitiesAsSimpleXMLElementArray() {

		if (!isset ($this->_importEntitiesAsSimpleXMLElementArray)) {

			/** @var Varien_Simplexml_Element[] $result */
			$result = parent::getImportEntitiesAsSimpleXMLElementArray();
			df_assert_array ($result);

			if (0 === count ($result)) {
				$result =
					$this->getSimpleXmlElement()->xpath (
						implode (
							Df_Core_Const::T_XPATH_SEPARATOR
							,
							$this->getItemsXmlPathAsArray2()
						)
					)
				;
			}


			$this->_importEntitiesAsSimpleXMLElementArray = $result;
		}


		df_result_array ($this->_importEntitiesAsSimpleXMLElementArray);
		return $this->_importEntitiesAsSimpleXMLElementArray;

	}
	/** @var Varien_Simplexml_Element[] */
	private $_importEntitiesAsSimpleXMLElementArray;


	/**
	 * @override
	 * @return string
	 */
	protected function getItemClassMf() {
		return Df_1C_Model_Cml2_Import_Data_Entity_ReferenceListPart_Item::getNameInMagentoFormat();
	}


	/**
	 * @override
	 * @return array
	 */
	protected function getItemsXmlPathAsArray() {
		return
			/**
			 * 1С:Управление торговлей 10.2 + дополнение от Битрикса:
			 *
				<Свойство>
					<Ид>b79b0fdd-c8a5-11e1-a928-4061868fc6eb</Ид>
					<Наименование>Производитель</Наименование>
					<ТипыЗначений>
						<ТипЗначений>
							<Тип>Справочник</Тип>
							<Описание>Значения свойств объектов</Описание>
							<ВариантыЗначений>
								<ВариантЗначения>
									<Ид>b79b0fde-c8a5-11e1-a928-4061868fc6eb</Ид>
									<Значение>Sony</Значение>
								</ВариантЗначения>
								<ВариантЗначения>
									<Ид>65fa6244-c8af-11e1-a928-4061868fc6eb</Ид>
									<Значение>Pentax</Значение>
								</ВариантЗначения>
							</ВариантыЗначений>
						</ТипЗначений>
					</ТипыЗначений>
				</Свойство>
			 */
			array (
				'ТипыЗначений'
				,
				'ТипЗначений'
				,
				'ВариантыЗначений'
				,
				'ВариантЗначения'
			)
		;
	}


	/**
	 * @return array
	 */
	private function getItemsXmlPathAsArray2() {
		return
			/**
			 * 1С:Управление торговлей 11:
			 *
				<Свойство>
					<Ид>69a1a785-f26f-11e1-990a-000c292511ad</Ид>
					<Наименование>Разрешение</Наименование>
					<ТипЗначений>Справочник</ТипЗначений>
					<ВариантыЗначений>
						<Справочник>
							<ИдЗначения>69a1a786-f26f-11e1-990a-000c292511ad</ИдЗначения>
							<Значение>HD Ready</Значение>
						</Справочник>
						<Справочник>
							<ИдЗначения>69a1a787-f26f-11e1-990a-000c292511ad</ИдЗначения>
							<Значение>Full HD</Значение>
						</Справочник>
					</ВариантыЗначений>
				</Свойство>
			 */
			array (
				'ВариантыЗначений'
				,
				'Справочник'
			)
		;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Model_Cml2_Import_Data_Collection_ReferenceListPart_Items';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}


