<?php

abstract class Df_1C_Model_Cml2_Import_Data_Entity_Attribute
	extends Df_1C_Model_Cml2_Import_Data_Entity {


	/**
	 * @param string $valueAsString
	 * @return string
	 */
	public function convertValueToMagentoFormat ($valueAsString) {
		return $valueAsString;
	}


	/**
	 * @return string
	 */
	public function getBackendModel() {
		return Df_Core_Const::T_EMPTY;
	}


	/**
	 * @return string
	 */
	public function getBackendType() {
		return Df_Core_Const::T_EMPTY;
	}


	/**
	 * @return string
	 */
	public function getFrontendInput() {
		return Df_Core_Const::T_EMPTY;
	}


	/**
	 * @return string
	 */
	public function getSourceModel() {
		return Df_Core_Const::T_EMPTY;
	}


	/**
	 * @return string
	 */
	public function getExternalTypeName() {
	
		if (!isset ($this->_externalTypeName)) {
	
			/** @var string $result */
			$result = 
				self::getExternalTypeNameStatic (
					$this->getSimpleXmlElement()
				)
			;
	
			df_assert_string ($result);
	
			$this->_externalTypeName = $result;
		}
	
	
		df_result_string ($this->_externalTypeName);
	
		return $this->_externalTypeName;
	}
	/** @var string */
	private $_externalTypeName;


	/**
	 * @param Varien_Simplexml_Element $entityAsSimpleXMLElement
	 * @return string
	 */
	public static function getExternalTypeNameStatic (
		Varien_Simplexml_Element $entityAsSimpleXMLElement
	) {
		/**
		 * 1С:Управление торговлей 10.2 + дополнение от Битрикса:
		 *
			<Свойство>
				<Ид>b79b0fdd-c8a5-11e1-a928-4061868fc6eb</Ид>
				<Наименование>Производитель</Наименование>
				<ТипыЗначений>
					<ТипЗначений>
						<Тип>Справочник</Тип>
						<Описание>Значения свойств объектов</Описание>
						<ВариантыЗначений>
							<ВариантЗначения>
								<Ид>b79b0fde-c8a5-11e1-a928-4061868fc6eb</Ид>
								<Значение>Sony</Значение>
							</ВариантЗначения>
							<ВариантЗначения>
								<Ид>65fa6244-c8af-11e1-a928-4061868fc6eb</Ид>
								<Значение>Pentax</Значение>
							</ВариантЗначения>
						</ВариантыЗначений>
					</ТипЗначений>
				</ТипыЗначений>
			</Свойство>
		 */


		/** @var SimpleXMLElement[]|bool $externalTypeNames */
		$externalTypeNames =
			$entityAsSimpleXMLElement->xpath ('ТипыЗначений/ТипЗначений/Тип')
		;

		df_assert_array ($externalTypeNames);

		if (0 === count ($externalTypeNames)) {
			/**
			 * 1С:Управление торговлей 11,
			 * Управление торговлей для Украины 2.3.18.1:
			 *
				<Свойство>
					<Ид>69a1a785-f26f-11e1-990a-000c292511ad</Ид>
					<Наименование>Разрешение</Наименование>
					<ТипЗначений>Справочник</ТипЗначений>
					<ВариантыЗначений>
						<Справочник>
							<ИдЗначения>69a1a786-f26f-11e1-990a-000c292511ad</ИдЗначения>
							<Значение>HD Ready</Значение>
						</Справочник>
						<Справочник>
							<ИдЗначения>69a1a787-f26f-11e1-990a-000c292511ad</ИдЗначения>
							<Значение>Full HD</Значение>
						</Справочник>
					</ВариантыЗначений>
				</Свойство>
			 */

			$externalTypeNames =
				$entityAsSimpleXMLElement->xpath ('ТипЗначений')
			;

			df_assert_array ($externalTypeNames);

		}

		/** @var string $result */
		$result =
				(0 === count ($externalTypeNames))
			?
				/**
				 * Заметил, что в Управление торговлей для Украины 2.3.18.1
				 * в информационной базе магазина sb-s.com.ua для одного свойства,
				 * которое в 1С настроено как булево, при выгрузке система не указывает тип значений.
				 * Выгружается оно системой вот так:
				 *
					<Свойство>
						<Ид>65ab3c04-88d2-11df-8003-00e04c595000</Ид>
						<Наименование>Публиковать</Наименование>
						<ДляТоваров>true</ДляТоваров>
					</Свойство>
				 */
				'Булево'
			:
				(string)(df_a ($externalTypeNames, 0))
		;

		/** @var string $result */
		$result =
			(string)(df_a ($externalTypeNames, 0))
		;

		df_result_string ($result);
		return $result;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Model_Cml2_Import_Data_Entity_Attribute';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}

