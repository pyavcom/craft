<?php

class Df_1C_TestController extends Mage_Core_Controller_Front_Action {


	/**
	 * @return void
	 */
	public function indexAction() {

		/** @var Mage_Sales_Model_Resource_Order_Collection|Mage_Sales_Model_Mysql4_Order_Collection $orders */
		$orders =
			Mage::getResourceModel (
				'sales/order_collection'
			)
		;

		df_helper()->sales()->assert()->orderCollection ($orders);


		foreach ($orders as $order) {

			/** @var Mage_Sales_Model_Order $order */
			df_assert ($order instanceof Mage_Sales_Model_Order);

			foreach ($order->getItemsCollection() as $item) {

				/** @var Mage_Sales_Model_Order_Item $item */
				df_assert ($item instanceof Mage_Sales_Model_Order_Item);


				/** @var Mage_Catalog_Model_Product $product */
				$product = $item->getProduct();

				df_assert ($product instanceof Mage_Catalog_Model_Product);


				/** @var string|null $externalId */
				$externalId = $product->getData (Df_Eav_Const::ENTITY_EXTERNAL_ID);

				Mage::log (
					sprintf (
						sprintf (
							'%s: %s'
							,
							$product->getName()
							,
							$externalId
						)
					)
				);
			}
		}



		$this
			->getResponse()
			->setHeader (
				$name = Df_Core_Const::HTTP_HEADER__CONTENT_TYPE
				,
				$value = Df_Core_Const::CONTENT_TYPE__TEXT__UTF_8
				,
				$replace = false
			)
			->setBody (
				''
				//print_r ($source->getAllOptions(false), $return = true)
			)
		;

	}


	/**
	 * @return void
	 */
	public function test2Action() {

		try {


			/** @var Df_Catalog_Model_Product $product */
			$product = df_model (Df_Catalog_Model_Product::getNameInMagentoFormat());

			$product->load (4);


			$description =
				Df_Varien_Simplexml_Element::markAsCData (
					df_convert_null_to_empty_string (
						$product->getDescription()
					)
				)
			;

			/** @var string $pattern */
			$pattern = "#\[\[([\s\S]*)\]\]#mu";

			/** @var string[] $matches */
			$matches = array();
			if (1 === preg_match($pattern, $description, $matches)) {
				df_assert_array($matches);
				$description = $matches[1];
			}

			$this
				->getResponse()
				->setHeader (
					$name = Df_Core_Const::HTTP_HEADER__CONTENT_TYPE
					,
					$value = Df_Core_Const::CONTENT_TYPE__TEXT__UTF_8
					,
					$replace = false
				)
				->setBody (
					$description
				)
			;
		}
		catch (Exception $e) {
			df_handle_entry_point_exception ($e, true);
		}
	}




}


