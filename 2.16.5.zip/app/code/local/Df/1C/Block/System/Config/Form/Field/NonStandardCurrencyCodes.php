<?php

class Df_1C_Block_System_Config_Form_Field_NonStandardCurrencyCodes
	extends Df_Adminhtml_Block_System_Config_Form_Field_Array_Abstract {

	/**
	 * @override
	 */
	public function __construct() {
		$this
			->addColumn (
				self::COLUMN__NON_STANDARD
				,
				array (
					'label' => 'код'
					,
					'style' => 'width:3em'
				)
			)
		;
		/**
		 * @var array[] $currencies
			Элемент массива:
			array (
				'label' => $name,
				'value' => $code,
			)
		 */
		$currencies = Mage::app()->getLocale()->getOptionCurrencies();
		df_assert_array ($currencies);

		$this
			->addColumn (
				self::COLUMN__STANDARD
				,
				new Varien_Object (
					array (
						'label' => 'валюта'
						,
						'style' => 'width:120px'
						,
						'renderer' =>
							df_block (
								Df_Adminhtml_Block_Widget_Grid_Column_Renderer_Select::getNameInMagentoFormat()
							)
						,
						'options' =>
							array_combine (
								df_column ($currencies, 'value')
								,
								df_column ($currencies, 'label')
							)
					)
				)
			)
		;
		$this->_addAfter = false;
		$this->_addButtonLabel = 'добавить...';
		parent::__construct();
	}

	const COLUMN__NON_STANDARD = 'non_standard_code';
	const COLUMN__STANDARD = 'standard_code';

	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_1C_Block_System_Config_Form_Field_NonStandardCurrencyCodes';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}