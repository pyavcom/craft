<?php

class Df_CatalogInventory_Const {



}
