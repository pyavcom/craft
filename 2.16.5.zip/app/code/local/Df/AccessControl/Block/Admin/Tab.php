<?php

class Df_AccessControl_Block_Admin_Tab
	extends Mage_Adminhtml_Block_Widget_Form
	implements Mage_Adminhtml_Block_Widget_Tab_Interface {


	/**
	 * Can show tab in tabs
	 *
	 * @return boolean
	 */
	public function canShowTab() {
		return true;
	}


	/**
	 * @override
	 * @return string
	 */
	public function getTabLabel() {
		return self::LABEL;
	}


	/**
	 * @override
	 * @return string
	 */
	public function getTabTitle() {
		return $this->getTabLabel();
	}


	/**
	 * @override
	 * @return string|null
	 */
	public function getTemplate() {

		/** @var string|null $result */
		$result =
				!(
						df_enabled (Df_Core_Feature::ACCESS_CONTROL)
					&&
						df_cfg()->admin()->access_control()->getEnabled()
				)
			?
				null
			:
				self::TEMPLATE

		;

		if (!is_null($result)) {
			df_result_string ($result);
		}
		return $result;
	}


	/**
	 * @override
	 * @return boolean
	 */
	public function isHidden() {
		return false;
	}


	/**
	 * @return bool
	 */
	public function isModuleEnabled() {

		/** @var bool $result */
		$result = $this->getRole()->isModuleEnabled();

		df_result_boolean ($result);
	
		return $result;
	}


	/**
	 * @return string
	 */
	public function renderCategoryTree() {
		/** @var Df_AccessControl_Block_Admin_Tab_Tree $block */
		$block =
			df_block (
				Df_AccessControl_Block_Admin_Tab_Tree::getNameInMagentoFormat()
			)
		;
		df_assert ($block instanceof Df_AccessControl_Block_Admin_Tab_Tree);

		/** @var string $result */
		$result =
			$block->toHtml()
		;
		df_result_string ($result);
		return $result;
	}


	/**
	 * @return string
	 */
	public function renderStoreSwitcher() {

		/** @var Mage_Adminhtml_Block_Store_Switcher $block */
		$block =
			df_block (
				'adminhtml/store_switcher'
			)
		;
		df_assert ($block instanceof Mage_Adminhtml_Block_Store_Switcher);

		$block->setTemplate ('store/switcher/enhanced.phtml');

		/** @var string $result */
		$result =
			$block->toHtml()
		;
		df_result_string ($result);
		return $result;
	}


	/**
	 * @return Df_AccessControl_Model_Role
	 */
	private function getRole() {

		if (!isset ($this->_role)) {

			/** @var Df_AccessControl_Model_Role $result */
			$result =
				df_model (
					Df_AccessControl_Model_Role::getNameInMagentoFormat()
				)
			;
			df_assert ($result instanceof Df_AccessControl_Model_Role);

			$result->load ($this->getRoleId());
			df_assert ($result instanceof Df_AccessControl_Model_Role);

			$this->_role = $result;
		}


		df_assert ($this->_role instanceof Df_AccessControl_Model_Role);
		return $this->_role;

	}
	/** @var Df_AccessControl_Model_Role */
	private $_role;


	/**
	 * @return int|null
	 */
	private function getRoleId() {

		/** @var int|null $result */
		$result =
			df_request ('rid')
		;

		if (!is_null($result)) {
			df_result_integer ($result);
		}
		return $result;
	}


	const LABEL = 'Доступ к товарным разделам';
	const TEMPLATE = 'df/access_control/tab.phtml';


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_AccessControl_Block_Admin_Tab';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}

}

