<?php

/** @var $this Df_Client_Model_Resource_Setup */

$this->startSetup();

$this->install_1_0_0();

$this->endSetup();


