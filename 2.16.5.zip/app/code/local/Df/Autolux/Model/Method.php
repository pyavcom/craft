<?php

abstract class Df_Autolux_Model_Method extends Df_Shipping_Model_Method {

	/**
	 * @abstract
	 * @return bool
	 */
	abstract protected function needDeliverToHome();

	/**
	 * @override
	 * @return float
	 */
	public function getCost() {
		if (!isset ($this->_cost)) {
			if (0 === $this->getCostInHryvnias()) {
				$this->throwExceptionCalculateFailure();
			}
			/** @var float $result */
			$result =
				df_helper()->directory()->currency()->convertFromHryvniasToBase (
					$this->getCostInHryvnias()
				)
			;
			df_result_float ($result);
			$this->_cost = $result;
		}
		return $this->_cost;
	}
	/** @var float */
	private $_cost;


	/**
	 * @override
	 * @return bool
	 */
	public function isApplicable() {
		/** @var bool $result */
		$result =
				(
						Df_Directory_Helper_Country::ISO_2_CODE__UKRAINE
					===
						$this->getRequest()->getOriginCountryId()
				)
			&&
				(
						Df_Directory_Helper_Country::ISO_2_CODE__UKRAINE
					===
						$this->getRequest()->getDestinationCountryId()
				)
			&&
				(!df_empty ($this->getRequest()->getOriginCity()))
			&&
				(!df_empty ($this->getRequest()->getDestinationCity()))
			&&
				(!df_empty ($this->getLocationIdOrigin()))
			&&
				(!df_empty ($this->getLocationIdDestination()))
		;
		return $result;
	}


	/**
	 * @override
	 * @return array
	 */
	protected function getLocations() {
		return Df_Autolux_Model_Request_Locations::i()->getLocations();
	}


	/**
	 * @return Df_Autolux_Model_Request_Rate
	 */
	private function getApi() {
		if (!isset ($this->_api)) {
			/** @var Df_Autolux_Model_Request_Rate $result */
			$result = 	
				df_model (
					Df_Autolux_Model_Request_Rate::getNameInMagentoFormat()
					,
					array (
						Df_Autolux_Model_Request_Rate::PARAM__QUERY_PARAMS => $this->getQueryParams()
					)
				)
			;
			df_assert ($result instanceof Df_Autolux_Model_Request_Rate);
			$this->_api = $result;
		}
		return $this->_api;
	}
	/** @var Df_Autolux_Model_Request_Rate */
	private $_api;	


	/**
	 * @return float
	 */
	private function getCostInHryvnias() {
		/** @var float $result */
		$result =
				$this->getCostInsurance();
			+
				$this->getRatePrimary()
		;
		if ($this->needDeliverToHome()) {
			$result += 50;
		}
		if ($this->getRmConfig()->service()->needGetCargoFromTheShopStore()) {
			$result += 50;
		}
		/**
		 * Стоимость отправки оплаты за груз составляет 14 грн. и 1% от суммы.
		 */
		$result += (14 + (0.01 * $result));
		return $result;
	}


	/**
	 * @return float
	 */
	private function getCostInsurance() {
		/** @var float $result */
		$result =
			max (
				1
				,
					0.01
				*
					df_helper()->directory()->currency()->convertFromBaseToHryvnias (
						$this->getRequest()->getDeclaredValue()
					)
			)
		;
		return $result;
	}


	/**
	 * @return array
	 */
	private function getQueryParams() {
		return
			array (
				'arrival' => $this->getLocationIdDestination()
				,
				'departure' => $this->getLocationIdOrigin()
			)
		;
	}


	/**
	 * @return float
	 */
	private function getRatePrimary() {
		/** @var float $rateByWeight */
		$rateByWeight =
			max (
				1
				,
					$this->getApi()->getFactorWeight()
				*
					$this->getRequest()->getWeightInKilogrammes()
			)
		;

		/** @var float $rateByVolume */
		$rateByVolume =
			max (
				1
				,
					$this->getApi()->getFactorVolume()
				*
					$this->getRequest()->getVolumeInCubicMetres()
			)
		;

		/** @var float $result */
		$result =
			ceil (
				max (
					$rateByWeight
					,
					$rateByVolume
				)
			)
		;
		df_result_float ($result);
		return $result;
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Autolux_Model_Method';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}