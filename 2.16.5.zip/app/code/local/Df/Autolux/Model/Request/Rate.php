<?php

class Df_Autolux_Model_Request_Rate extends Df_Autolux_Model_Request {

	/**
	 * @return float
	 */
	public function getFactorVolume() {
		/** @var float $result */
		$result = floatval (df_a ($this->getResponseAsAssocArray(), 'volume'));
		return $result;
	}


	/**
	 * @return float
	 */
	public function getFactorWeight() {
		/** @var float $result */
		$result = floatval (df_a ($this->getResponseAsAssocArray(), 'weight'));
		return $result;
	}


	/**
	 * @override
	 * @return string
	 */
	protected function getQueryPath() {
		return '/Autolux/inc/Pages/PatternStd/img/rates.php';
	}


	/**
	 * @return mixed[]
	 */
	private function getResponseAsAssocArray() {
		if (!isset ($this->_responseAsAssocArray)) {
			/** @var mixed[] $result */
			$result =
				json_decode (
					preg_replace('/\x{EF}\x{BB}\x{BF}/','', $this->getResponseAsText())
					,
					$assoc = true
				)
			;
			df_result_array ($result);
			$this->_responseAsAssocArray = $result;
		}
		return $this->_responseAsAssocArray;
	}
	/** @var mixed[] */
	private $_responseAsAssocArray;


	/**
	 * @override
	 * @return void
	 */
	protected function _construct() {
		parent::_construct();
	}


	/**
	 * @static
	 * @return string
	 */
	public static function getClass() {
		return 'Df_Autolux_Model_Request_Rate';
	}


	/**
	 * Например, для класса Df_SalesRule_Model_Event_Validator_Process
	 * метод должен вернуть: «df_sales_rule/event_validator_process»
	 *
	 * @static
	 * @return string
	 */
	public static function getNameInMagentoFormat() {
		/** @var string $result */
		static $result;
		if (!isset ($result)) {
			$result = df()->reflection()->getModelNameInMagentoFormat (self::getClass());
		}
		return $result;
	}
}