<?php

class Df_Autolux_TestController extends Mage_Core_Controller_Front_Action {

	/**
	 * @return void
	 */
	public function indexAction() {
		try {
			$this
				->getResponse()
				->setHeader (
					$name = Df_Core_Const::HTTP_HEADER__CONTENT_TYPE
					,
					$value = Df_Core_Const::CONTENT_TYPE__TEXT__UTF_8
					,
					$replace = false
				)
				->setBody (
					print_r (
						Df_Autolux_Model_Request_Locations::i()->getLocations()
						,
						true
					)
				)
			;
		}
		catch (Exception $e) {
			df_handle_entry_point_exception ($e, false);
			echo $e->getMessage();
		}
	}
}